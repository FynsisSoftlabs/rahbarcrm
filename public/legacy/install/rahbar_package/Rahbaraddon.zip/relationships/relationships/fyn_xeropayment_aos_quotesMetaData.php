<?php
// created: 2017-05-26 12:08:54
$dictionary["fyn_xeropayment_aos_quotes"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'fyn_xeropayment_aos_quotes' => 
    array (
      'lhs_module' => 'AOS_Quotes',
      'lhs_table' => 'aos_quotes',
      'lhs_key' => 'id',
      'rhs_module' => 'FYN_Xeropayment',
      'rhs_table' => 'fyn_xeropayment',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'fyn_xeropayment_aos_quotes_c',
      'join_key_lhs' => 'fyn_xeropayment_aos_quotesaos_quotes_ida',
      'join_key_rhs' => 'fyn_xeropayment_aos_quotesfyn_xeropayment_idb',
    ),
  ),
  'table' => 'fyn_xeropayment_aos_quotes_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'fyn_xeropayment_aos_quotesaos_quotes_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'fyn_xeropayment_aos_quotesfyn_xeropayment_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'fyn_xeropayment_aos_quotesspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'fyn_xeropayment_aos_quotes_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'fyn_xeropayment_aos_quotesaos_quotes_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'fyn_xeropayment_aos_quotes_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'fyn_xeropayment_aos_quotesfyn_xeropayment_idb',
      ),
    ),
  ),
);