<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.list.php');

class FYN_XeroCreditNoteViewList extends ViewList
{
 	public function preDisplay()
 	{

 		parent::preDisplay();
 		$this->lv->targetList = false;
        $this->lv->delete = false;
        $this->lv->multiSelect = false;
        $this->lv->quickViewLinks = false;
 	}
}
