<?php
$module_name = 'FYN_XeroCreditNote';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'XERO_CREDITNOTEID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_XERO_CREDITNOTEID',
    'width' => '10%',
    'default' => true,
  ),
  'XERO_APPLIEDAMOUNT' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_XERO_APPLIEDAMOUNT',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'XERO_CREDITTYPE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_XERO_CREDITTYPE',
    'width' => '10%',
    'default' => true,
  ),
  'XERO_STATUS' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_XERO_STATUS',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
);
?>
