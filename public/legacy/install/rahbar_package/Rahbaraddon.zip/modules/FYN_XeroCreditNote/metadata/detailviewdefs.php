<?php
$module_name = 'FYN_XeroCreditNote';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 'assigned_user_name',
        ),
        1 => 
        array (
          0 => 'description',
          1 => 
          array (
            'name' => 'fyn_xerocreditnote_aos_quotes_name',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'xero_appliedamount',
            'label' => 'LBL_XERO_APPLIEDAMOUNT',
          ),
          1 => 
          array (
            'name' => 'xero_creditnoteid',
            'label' => 'LBL_XERO_CREDITNOTEID',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'xero_status',
            'studio' => 'visible',
            'label' => 'LBL_XERO_STATUS',
          ),
          1 => 
          array (
            'name' => 'xero_credittype',
            'studio' => 'visible',
            'label' => 'LBL_XERO_CREDITTYPE',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'xero_currencycode',
            'label' => 'LBL_XERO_CURRENCYCODE',
          ),
          1 => 
          array (
            'name' => 'xero_currencyrate',
            'label' => 'LBL_XERO_CURRENCYRATE',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'xero_lineamounttypes',
            'label' => 'LBL_XERO_LINEAMOUNTTYPES',
          ),
          1 => 
          array (
            'name' => 'xero_reference',
            'label' => 'LBL_XERO_REFERENCE',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'xero_creditnotenumber',
            'label' => 'LBL_XERO_CREDITNOTENUMBER',
          ),
          1 => 
          array (
            'name' => 'xero_creditnotesdate',
            'label' => 'LBL_XERO_CREDITNOTESDATE',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'xero_isreconciled',
            'label' => 'LBL_XERO_ISRECONCILED',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
?>
