<?php
$module_name = 'FYN_XeroCreditNote';
$viewdefs [$module_name] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 'assigned_user_name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'xero_creditnoteid',
            'label' => 'LBL_XERO_CREDITNOTEID',
          ),
          1 => 
          array (
            'name' => 'xero_status',
            'studio' => 'visible',
            'label' => 'LBL_XERO_STATUS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'xero_credittype',
            'studio' => 'visible',
            'label' => 'LBL_XERO_CREDITTYPE',
          ),
          1 => 
          array (
            'name' => 'xero_creditnotenumber',
            'label' => 'LBL_XERO_CREDITNOTENUMBER',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'xero_appliedamount',
            'label' => 'LBL_XERO_APPLIEDAMOUNT',
          ),
          1 => 
          array (
            'name' => 'xero_creditnotesdate',
            'label' => 'LBL_XERO_CREDITNOTESDATE',
          ),
        ),
      ),
    ),
  ),
);
?>
