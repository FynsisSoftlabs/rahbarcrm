$(document).ready(function(){
    var fyn_xero_status = $('#fyn_xero_status').val();
    if(fyn_xero_status=='AUTHORISED'){
            
    }else{
        // $('#quote_fynxeropayment_create_button').hide();
        // $('#quote_fynxerocreditnote_create_button').hide();
    }
});