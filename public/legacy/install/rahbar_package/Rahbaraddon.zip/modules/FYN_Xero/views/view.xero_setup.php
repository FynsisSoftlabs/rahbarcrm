<?php if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/SugarView.php');

class ViewXero_Setup extends SugarView
{
    public function preDisplay()
    {
        global $current_user, $app_strings;

        if (!is_admin($current_user)) sugar_die($app_strings['ERR_NOT_ADMIN']);
    }
    public function display()
    {
		global $sugar_config;
		global $current_user, $app_strings;


			 require_once('modules/Xero/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('Xero',$current_user->id);
        if($validate_license !== true) {
          //  echo '< h2>< p class="error">Xero is no longer active</p></h2>< p class="error">'.$validate_license.'</p>';

    //functionality may be altered here in response to the key failing to validate
            echo '<script> alert("License Expired.") </script>';
            exit();
         }

		
		
        // get MC key if it exists
		ClsFYNXero::getXeroAPIDetails();
		$FYNAPIDetails = ClsFYNXero::$fynGetAPIDetails;
        $no_error = true;
		
		$xero_connection = false;
		if(strlen($FYNAPIDetails['fynconsumer_key'])>0){
			$response = ClsFYNXero::checkxeroApiConnection();
			if ($response['success'] === true)	
				$xero_connection = true;
		}
		
		$errors = array(); 
		if(isset($_GET['xstatus'])){
			if ($response['success'] !== true)
			{
				$errors[] = 'Your API credentials has been saved successfully, but could not connect with Xero. Please review the credentials and update again.<br /> '.$response['message'];
				$no_error = false;
			}else{
				if($_GET['xstatus']=='Y')
					$this->ss->assign('success','Your API credentials has been saved and connected successfully!!!');
				else
					$errors[] = $_GET['message'];
			}
		}else{
			if ($response['success'] !== true)
			{
				//$errors[] = 'Your API credentials has been saved successfully, but getting some error to connect with Xero. Please review detail and update again.<br /> '.$response['message'];
				$no_error = false;
			}
		}
		
        $this->ss->assign('errors',$errors);
        $this->ss->assign('fynconsumer_key', $FYNAPIDetails['fynconsumer_key']);
		$this->ss->assign('fynconsumer_secret', $FYNAPIDetails['fynconsumer_secret']);
		$this->ss->assign('fynpublic_key', $FYNAPIDetails['fynpublic_key']);
		$this->ss->assign('fynprivate_key', $FYNAPIDetails['fynprivate_key']);
		$this->ss->assign('no_error', $no_error);
		$this->ss->assign('xero_connection', $xero_connection);
		
        $this->ss->assign('active_step','xero_setup');
        
        $this->ss->display('modules/FYN_Xero/tpls/xero_setup.tpl');
    }
}
