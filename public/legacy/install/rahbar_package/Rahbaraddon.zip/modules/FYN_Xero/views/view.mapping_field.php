<?php if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/SugarView.php');

class ViewMapping_Field extends SugarView
{
    public function preDisplay()
    {
        global $current_user, $app_strings;

        if (!is_admin($current_user)) sugar_die($app_strings['ERR_NOT_ADMIN']);
    }
    public function display()
    {
		global $app_list_strings;
		global $current_user, $app_strings, $sugar_config;


			 require_once('modules/Xero/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('Xero',$current_user->id);
        if($validate_license !== true) {
          //  echo '< h2>< p class="error">Xero is no longer active</p></h2>< p class="error">'.$validate_license.'</p>';

    //functionality may be altered here in response to the key failing to validate
            echo '<script> alert("License Expired.") </script>';
            exit();
         }

		
        		
		$errors = array();
		if(isset($_GET['xstatus'])){
			if($_GET['xstatus']=='Y')
				$this->ss->assign('success',$_GET['message']);
			else
				$errors[] = $_GET['message'];
		}/*else{
			if ($response['success'] !== true)
			{
				$errors[] = 'Xero Connection is not establish: '.$response['message'];
			}
		}*/
        $this->ss->assign('errors',$errors);
		
		## Field Mapping Xero Fetched
		$cached_mappings = ClsFYNXero::GetMappingField('Accounts');
		
		## Account Fields
		$bean_account = BeanFactory::getBean('Accounts');
		$field_options_acc = self::get_importable_field($bean_account);
		
		## Contact Fields
		$bean_contact = BeanFactory::getBean('Contacts');
		$field_options_con = self::get_importable_field($bean_contact);
		
		#echo '<pre>';
		#print_r($cached_mappings);exit;
		$display_list = '';
		$lp = 0;
		## START Foreach for Mapping with Xero field Mapped
		foreach($cached_mappings as $type=>$cached_mapping)
		{
			## START Field Mapping Array with Sugar & Xero Field Name
			foreach($cached_mapping as $sugar_field_name=>$mergeVarsArr)
			{
				$xero_field_type = '';
				$xero_field_nm = $mergeVarsArr['mapping']['xero_name'];
				$xero_field_label = $mergeVarsArr['mapping']['xero_label'];
				
				if($mergeVarsArr['mapping']['no_field_mapping']===true)
					continue;
				
				if($mergeVarsArr['type']=='Addresses'){
					$xero_field_nm = $mergeVarsArr['AddressType'].'_'.$mergeVarsArr['mapping']['xero_name'];
					$xero_field_label = $mergeVarsArr['AddressType'].'_'.$mergeVarsArr['mapping']['xero_label'];
					$xero_field_type = $mergeVarsArr['AddressType'];
				}
				else if($mergeVarsArr['type']=='Phones'){
					$xero_field_nm = $mergeVarsArr['PhoneType'].'_'.$mergeVarsArr['mapping']['xero_name'];
					$xero_field_type = $mergeVarsArr['PhoneType'];
				}
				
				if($lp%10==0){
					$display_list .= '<tr class="fynHeadL"><th>Sync</th>
					<th style="text-align: left;">Xero Field Name</th><th style="text-align: left;">Account</th><th></th><th style="text-align: left;">Contact</th></tr><tr><td style="height:10px"></td></tr>';
				}
				
				$data_type = '';
				if($xero_field_nm != 'ContactID'){
					$m_data_type = $mergeVarsArr['data_type'];
					if($mergeVarsArr['data_type']=='Varchar')
						$m_data_type = 'Textbox';
					$data_type = '<br />(<font style="font-size:9px">'.$m_data_type.'</font>)';
				}
				$syncAPI = '<img src="modules/FYN_Xero/tpls/images/single-directional.png" />';
				if($mergeVarsArr['SyncAPI'])
					$syncAPI = '<img src="modules/FYN_Xero/tpls/images/bi-directional.png" />';
					
				$display_list .= '<tr><td style="text-align: center; width: 85px;">'.$syncAPI.'</td>
				<td style="text-align: left;">'.$xero_field_label.$data_type.'<input type="hidden" name="xero_field[]" id="xero_field_'.$xero_field_nm.'" value="'.$mergeVarsArr['mapping']['xero_name'].'"><input type="hidden" name="xero_field_type[]" value="'.$xero_field_type.'"></td>';
				
				$display_list .= '<td style="">
				<input type="radio" name="xero_check1['.$xero_field_nm.']" id="xero_check1_'.$xero_field_nm.'" data_attr="'.$xero_field_nm.'" modulenm="Accounts" class="chkbox"';
				if($type=='Accounts') $display_list .= 'checked';
				$display_list .= ' value="Y" /> ';
				
				$display_list .= '<select name="xero_Accounts[]" id="xero_Accounts_'.$xero_field_nm.'" data_attr="'.$xero_field_nm.'" class="selectbox"><option value="">--None--</option>';
				if($xero_field_nm=='EmailAddress'){
					$display_list .= '<option value="email1"';
					if($sugar_field_name=='email1' && $type=='Accounts')
						$display_list .= ' selected ';
					$display_list .= '>Email Address</option>';
				}else{
					foreach($field_options_acc as $field_name=>$name){
						$display_list .= '<option value="'.$field_name.'"';
						if($sugar_field_name==$field_name && $type=='Accounts')
							$display_list .= ' selected ';
						$display_list .= '>'.$name.'</option>';
					}
				}
				$display_list .= '</select><div class="err_module" id="error_xero_Accounts_'.$xero_field_nm.'" style="display:none">Please select Field.</div></td>';
				$display_list .= '<td style="text-align: center; width: 100px;"></td>';
				$display_list .= '<td style="" valign="middle">
				<input type="radio" name="xero_check2['.$xero_field_nm.']" id="xero_check2_'.$xero_field_nm.'" data_attr="'.$xero_field_nm.'" modulenm="Contacts" class="chkbox"';
				if($type=='Contacts') $display_list .= 'checked';
				$display_list .= ' value="Y" /> ';
				$display_list .= '<select name="xero_Contacts[]" id="xero_Contacts_'.$xero_field_nm.'" data_attr="'.$xero_field_nm.'"class="selectbox"><option value="">--None--</option>';
				if($xero_field_nm=='EmailAddress'){
					$display_list .= '<option value="email1"';
					if($sugar_field_name=='email1' && $type=='Contacts')
						$display_list .= ' selected ';
					$display_list .= '>Email Address</option>';
				}else{
					foreach($field_options_con as $field_name=>$name){
						$display_list .= '<option value="'.$field_name.'"';
						if($sugar_field_name==$field_name && $type=='Contacts')
							$display_list .= ' selected ';
						$display_list .= '>'.$name.'</option>';
					}
				}
				$display_list .= '</select><div class="err_module" id="error_xero_Contacts_'.$xero_field_nm.'" style="display:none">Please select Field.</div></td>';
				
				
				$display_list .= '</tr>';
				$display_list .= '<tr><td style="height:10px"></td></tr>';
				$lp++;
			}
			## END Field Mapping Array with Sugar & Xero Field Name
		}
		## END Foreach for Mapping with Xero field Mapped
		$display_list .= '<tr><td>&nbsp;</td></tr><tr><td colspan="4"><input type="submit" class="FYN_button" value="Save SugarXero field map" onclick="return mapping_field_lists();" > &nbsp;&nbsp; <input type="submit" class="FYN_button" value="Reset Field" onclick="return fnreset_field();" ></td></tr></tbody>';
		
		$this->ss->assign('Account_field_mapping',$display_list);
        $this->ss->assign('active_step','mapping_field');
        $this->ss->display('modules/FYN_Xero/tpls/mapping_field.tpl');
    }
	
	## START Get Importable Field 
	function get_importable_field($object){
		global $moduleStrings;
		$fields  = $object->get_importable_fields();
		$field_options = array(); 
		$not_array = array('id', 'date_entered', 'deleted', 'date_modified', 'email1', 'email_addresses_non_primary', 'email_opt_out', 'invalid_email', 'modified_user_id', 'created_by', 'converted', 'full_name', 'ticker_symbol', 'portal_name', 'portal_app');
		foreach ( $fields as $fieldname => $properties ) {
			if(in_array($fieldname, $not_array))
				continue;
			if($properties['type']=='relate')
				continue;
			#print_r($properties);echo "<br>";
			// get field name
			if (!empty($moduleStrings['LBL_EXPORT_'.strtoupper($fieldname)]) )
			{
				 $displayname = str_replace(":","", $moduleStrings['LBL_EXPORT_'.strtoupper($fieldname)] );
			}
			else if (!empty ($properties['vname']))
			{
				$displayname = str_replace(":","",translate($properties['vname'] ,$object->module_dir));
			}
			else
				$displayname = str_replace(":","",translate($properties['name'] ,$object->module_dir));
			
			$field_options[$fieldname] = $displayname;
		}
		return $field_options;
	}
	## END Get Importable Field
}
