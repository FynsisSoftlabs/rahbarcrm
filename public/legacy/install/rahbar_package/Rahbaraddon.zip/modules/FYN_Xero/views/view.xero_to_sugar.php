<?php if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/SugarView.php');

class ViewXero_To_Sugar extends SugarView
{
    public function preDisplay()
    {
        global $current_user, $app_strings;

        if (!is_admin($current_user)) sugar_die($app_strings['ERR_NOT_ADMIN']);
    }
    public function display()
    {
		global $app_list_strings;
		global $current_user, $app_strings;


	    require_once('modules/Xero/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('Xero',$current_user->id);
        if($validate_license !== true) {
          //  echo '< h2>< p class="error">Xero is no longer active</p></h2>< p class="error">'.$validate_license.'</p>';

    //functionality may be altered here in response to the key failing to validate
            echo '<script> alert("License Expired.") </script>';
            exit();
         }

		
        $response = ClsFYNXero::checkxeroApiConnection();
		
		$errors = array();
		if(isset($_GET['xstatus'])){
			if($_GET['xstatus']=='Y')
				$this->ss->assign('success',$_GET['message']);
			else
				$errors[] = $_GET['message'];
		}
        $this->ss->assign('errors',$errors);
        
		$modified_date_list = array();
		foreach($app_list_strings['xero_modified_date_list'] as $key=>$val)
		{
			$modified_date_list[] = array('value'=>$key, 'text'=>$val);
		}
		
		$this->ss->assign('modified_date_list',$modified_date_list);

        $this->ss->assign('active_step','XerotoSugar');
        
        $this->ss->display('modules/FYN_Xero/tpls/xero_to_sugar.tpl');
    }
}
