<?php if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/Controller/SugarController.php');
require_once('modules/FYN_Xero/Classes/FYN_Xero.php');

class FYN_XeroController extends SugarController
{
    function action_listview($errors=array())
    {
		$this->view_object_map['errors'] = $errors;
        $this->view = 'xero_setup';
		
		$queryParams = array(
		'module' => 'FYN_Xero',
		'action' => 'XeroSetup',
		'xstatus' => 'Y',
		'message' => ''
		);
		 
		SugarApplication::redirect('index.php?' . http_build_query($queryParams));
		exit;
    }
    
    function action_editview($errors=array())
    {
        $this->view_object_map['errors'] = $errors;
        $this->view = 'xero_setup';
        
        $queryParams = array(
        'module' => 'FYN_Xero',
        'action' => 'XeroSetup',
        'xstatus' => 'Y',
        'message' => ''
        );
         
        SugarApplication::redirect('index.php?' . http_build_query($queryParams));
        exit;
    }
    
    function action_xerosetup($errors=array())
    {
		$this->view_object_map['errors'] = $errors;
        $this->view = 'xero_setup';
    }
	
	function action_xerosetupsave($errors=array())
    {
               
		require_once('modules/Administration/Administration.php');
        $Administration = new Administration();
		$Administration->retrieveSettings('fyn_xero');
		$fyn_webhook_key = $Administration->settings['fynxero_fyn_webhook_key'];
		$Administration->saveSetting('fynxero', 'fynconsumer_key', trim($_REQUEST['fynconsumer_key']));
		$Administration->saveSetting('fynxero', 'fynconsumer_secret', trim($_REQUEST['fynconsumer_secret']));
		$Administration->saveSetting('fynxero', 'fynpublic_key', trim($_REQUEST['fynpublic_key']));
		$Administration->saveSetting('fynxero', 'fynprivate_key', trim($_REQUEST['fynprivate_key']));
		if(empty($fyn_webhook_key)){
			$Administration->saveSetting('fynxero', 'fyn_webhook_key', time());
		}
		
		$queryParams = array(
		'module' => 'FYN_Xero',
		'action' => 'XeroSetup',
		'xstatus' => 'Y',
		'message' => 'Successfully Saved!!!'
		);
		 
		SugarApplication::redirect('index.php?' . http_build_query($queryParams));
		exit;
    }
    
    ## START Global Google Apps Settings
    function action_globalappssettings($errors=array())
    {
        $this->view_object_map['errors'] = $errors;
        $this->view = 'globalappssettings';
    }
    ## END Global Google Apps Settings
    
    ## START Global Google Apps Settings Saved Data
    function action_globalappssettings_Save()
    {echo "No Save";exit;
        $appsSetting = array();
        $appsSetting['xero_contact_sync'] = 1;
        $appsSetting['xero_to_sugar_contact'] = 1;
        $appsSetting['sugar_to_xero_contact'] = $_REQUEST["sugar_to_xero_contact"];
        $appsSetting['xero_inventory_sync'] = 1;
        $appsSetting['xero_to_sugar_inventory'] = 1;
        $appsSetting['sugar_to_xero_inventory'] = $_REQUEST["sugar_to_xero_inventory"];
        $appsSetting['xero_invoice_sync'] = 1;
        $appsSetting['xero_to_sugar_invoice'] = 1;
        $appsSetting['sugar_to_xero_invoice'] = $_REQUEST["sugar_to_xero_invoice"];
        
        $jsonApps = base64_encode(serialize($appsSetting));
        
        require_once('modules/Administration/Administration.php');
        $Administration = new Administration();
        $Administration->retrieveSettings('fyn_xeroapps');
        $Administration->saveSetting('fyn_xeroapps', 'global_setting', $jsonApps);
        
        $queryParams = array(
        'module' => 'FYN_Xero',
        'action' => 'globalappssettings',
        'xstatus' => 'Y',
        'message' => 'Successfully Saved'
        );
         
        SugarApplication::redirect('index.php?' . http_build_query($queryParams));
        exit;
    }
    ## END Global Google Apps Settings Saved Data
	
	function action_mapping_field($errors=array())
    {
        $this->view_object_map['errors'] = $errors;
        $this->view = 'mapping_field';
    }
	
	function action_mapping_fieldsave($errors=array())
    {
        
		require_once('modules/Administration/Administration.php');
        // mclists_to_sync selected to sync
		#echo '<pre>'; 		print_r($_REQUEST); exit;
		if($_REQUEST['reset_field']==='1'){
			$qry = "DELETE FROM `config` WHERE `category` = 'fyn_xero' AND `name` = 'Accounts'";
			$GLOBALS['db']->query($qry, true);
			$queryParams = array(
			'module' => 'FYN_Xero',
			'action' => 'mapping_field',
			'xstatus' => 'Y',
			'message' => 'Default field map has been set successfully.'
			);
			 
			SugarApplication::redirect('index.php?' . http_build_query($queryParams));
			exit;
		}
		
		if (empty($_REQUEST['xero_field']))
        {
            return $this->action_mapping_field(array('Issue with something no data pass.'));
        }
		
		## Field Mapping Xero Fetched
		##$cached_mappings = ClsFYNXero::GetMappingField('Accounts');
		$cached_mappings = ClsFYNXero::$default_mappings['Accounts'];

		$tmp_value = array(); $field_set = false;
		foreach($_REQUEST['xero_field'] as $key=>$fieldnm)
		{
			$field_type = $_REQUEST['xero_field_type'][$key];
			
			foreach($cached_mappings as $type=>$cached_mapping)
			{
				foreach($cached_mapping as $sugar_field_name=>$mergeVarsArr)
				{
					if(!empty($field_type)){
						if($mergeVarsArr['type'] == 'Addresses'){
							if($mergeVarsArr['AddressType'] != $field_type)
								continue;
						}else if($mergeVarsArr['type'] == 'Phones'){
							if($mergeVarsArr['PhoneType'] != $field_type)
								continue;
						}
					}
					
					if($mergeVarsArr['mapping']['xero_name']==$fieldnm)
					{
						$tmpfieldnm = $fieldnm;
						if(!empty($field_type))
							$tmpfieldnm = $field_type."_".$fieldnm;
						
						if($_REQUEST['xero_check1'][$tmpfieldnm]=='Y'){
							$arr = array();
							foreach($mergeVarsArr as $k=>$v){
								if($k=='mapping'){
									$arr[$k]['sugarcrm_name'] = $_REQUEST['xero_Accounts'][$key];
									$arr[$k]['xero_name'] = $v['xero_name'];
									$arr[$k]['xero_label'] = $v['xero_label'];
								}else{
									$arr[$k] = $v;
								}
							}
							$tmp_value['Accounts'][$_REQUEST['xero_Accounts'][$key]] = $arr;
						}else if($_REQUEST['xero_check2'][$tmpfieldnm]=='Y'){
							$arr = array();
							foreach($mergeVarsArr as $k=>$v){
								if($k=='mapping'){
									$arr[$k]['sugarcrm_name'] = $_REQUEST['xero_Contacts'][$key];
									$arr[$k]['xero_name'] = $v['xero_name'];
									$arr[$k]['xero_label'] = $v['xero_label'];
								}else{
									$arr[$k] = $v;
								}
							}
							$tmp_value['Contacts'][$_REQUEST['xero_Contacts'][$key]] = $arr;
							if($fieldnm=='PhoneNumber'){
							#echo $_REQUEST['xero_Contacts'][$key];
							#print_r($tmp_value);
							#exit;
							}
						}else{
							$tmp_value[$type][$fieldnm] = $mergeVarsArr;
						}
						if($fieldnm=='PhoneNumber'){
						#echo $_REQUEST['xero_Contacts'][$key];
						#print_r($tmp_value);
						#exit;
						}
					}
				}
			}
		}
		foreach($cached_mappings as $type=>$cached_mapping)
		{
			foreach($cached_mapping as $sugar_field_name=>$mergeVarsArr)
			{
				if($mergeVarsArr['mapping']['no_field_mapping']===true)
				{
					$tmp_value[$type][$sugar_field_name] = $mergeVarsArr;
				}
			}
		}
		#echo '<pre>'; 		print_r($tmp_value);		exit;
		$administration = new Administration();
		$administration->saveSetting('fyn_xero', 'Accounts', base64_encode(serialize($tmp_value)));
		
		$queryParams = array(
		'module' => 'FYN_Xero',
		'action' => 'mapping_field',
		'xstatus' => 'Y',
		'message' => 'Field mapping has been saved successfully!!!'
		);
		 
		SugarApplication::redirect('index.php?' . http_build_query($queryParams));
		exit;
    }
	
	function action_xerotosugar($errors=array())
    {
        $this->view_object_map['errors'] = $errors;
        $this->view = 'xero_to_sugar';
    }
	
	function action_xerotosugarsync()
    {
        
        // clickaction 
        if (empty($_REQUEST['clickaction']))
        {
            return $this->action_xerotosugacrm(array('Cant Recognise button click'));
        }

		if($_REQUEST['clickaction']=='taxrate'){		
	        $response = ClsFYNXero::Generate_TaxRate_List();
			$status = 'N';
			if ($response['success'] === true)
				$status = 'Y';
			$queryParams = array(
			'module' => 'FYN_Xero',
			'action' => 'XerotoSugar',
			'xstatus' => $status,
			'message' => $response['message']
			);
			 
			SugarApplication::redirect('index.php?' . http_build_query($queryParams));
			exit;
		}else if($_REQUEST['clickaction']=='accountinglist'){		
	        $response = ClsFYNXero::Generate_Account_List();
			$status = 'N';
			if ($response['success'] === true)
				$status = 'Y';
			$queryParams = array(
			'module' => 'FYN_Xero',
			'action' => 'XerotoSugar',
			'xstatus' => $status,
			'message' => $response['message']
			);
			 
			SugarApplication::redirect('index.php?' . http_build_query($queryParams));
			exit;
		}else if($_REQUEST['clickaction']=='currencies'){		
	        $response = ClsFYNXero::Generate_Currency_List();
			$status = 'N';
			if ($response['success'] === true)
				$status = 'Y';
			$queryParams = array(
			'module' => 'FYN_Xero',
			'action' => 'XerotoSugar',
			'xstatus' => $status,
			'message' => $response['message']
			);
			 
			SugarApplication::redirect('index.php?' . http_build_query($queryParams));
			exit;
		}
        
		$queryParams = array(
		'module' => 'FYN_Xero',
		'action' => 'XerotoSugar',
		);
		 
		SugarApplication::redirect('index.php?' . http_build_query($queryParams));
		exit;
    }
	
	function action_inventrylisttosugar($errors=array())
    {
        $this->view_object_map['errors'] = $errors;
        $this->view = 'Inventrylist_to_Sugar';
    }
	
	function action_inventrylisttosugarsync()
    {
        
        // clickaction 
        if (empty($_REQUEST['clickaction']))
        {
            return $this->action_xerotosugacrm(array('Not Recognise button click'));
        }

		if($_REQUEST['clickaction']=='inventrylist'){
			require_once('modules/FYN_Xero/Classes/XerotoSugarCRM.php');		
			$clsXero_To_SguarCRM = new clsXero_To_SguarCRM();
			$response = $clsXero_To_SguarCRM->sync_Product_List($_REQUEST['inventry_all'], $_REQUEST['modified_date'], 'N', $last_date);
			$status = 'N';
			if ($response['success'] === true)
				$status = 'Y';
			$queryParams = array(
			'module' => 'FYN_Xero',
			'action' => 'InventrylisttoSugar',
			'xstatus' => $status,
			'message' => $response['message']
			);
			 
			SugarApplication::redirect('index.php?' . http_build_query($queryParams));
			exit;
		}
        
		$queryParams = array(
		'module' => 'FYN_Xero',
		'action' => 'InventrylisttoSugar',
		);
		 
		SugarApplication::redirect('index.php?' . http_build_query($queryParams));
		exit;
    }
	
	function action_contactslisttosugar($errors=array())
    {
        $this->view_object_map['errors'] = $errors;
        $this->view = 'Contactslist_to_Sugar';
    }
	
	function action_contactslisttosugarsync()
    {
        
        // clickaction 
        if (empty($_REQUEST['clickaction']))
        {
            return $this->action_xerotosugacrm(array('Not Recognise button click'));
        }

		if($_REQUEST['clickaction']=='sugaraccountlist'){
			require_once('modules/FYN_Xero/Classes/XerotoSugarCRM.php');		
			$clsXero_To_SguarCRM = new clsXero_To_SguarCRM();
			$response = $clsXero_To_SguarCRM->sync_Suite_Account_List($_REQUEST['account_all'], $_REQUEST['account_modified_date'], 'N', $last_date);
			$status = 'N';
			if ($response['success'] === true)
				$status = 'Y';
			$queryParams = array(
			'module' => 'FYN_Xero',
			'action' => 'ContactslisttoSugar',
			'xstatus' => $status,
			'message' => $response['message']
			);
			 
			SugarApplication::redirect('index.php?' . http_build_query($queryParams));
			exit;
		}
		
        
		$queryParams = array(
		'module' => 'FYN_Xero',
		'action' => 'ContactslisttoSugar',
		);
		 
		SugarApplication::redirect('index.php?' . http_build_query($queryParams));
		exit;
    }
	
	function action_inovicelisttosugar($errors=array())
    {
        $this->view_object_map['errors'] = $errors;
        $this->view = 'Inovicelist_to_Sugar';
    }
	
	function action_inovicelisttosugarsync()
    {
        
        // clickaction 
        if (empty($_REQUEST['clickaction']))
        {
            return $this->action_xerotosugacrm(array('Cant Recognise button click'));
        }

		if($_REQUEST['clickaction']=='sugarquotelist'){
			require_once('modules/FYN_Xero/Classes/XerotoSugarCRM.php');		
			$clsXero_To_SguarCRM = new clsXero_To_SguarCRM();
			$response = $clsXero_To_SguarCRM->sync_CRM_Quote_List($_REQUEST['invoice_all'], $_REQUEST['invoice_modified_date'], 'N', $last_date);
			$status = 'N';
			if ($response['success'] === true)
				$status = 'Y';
			$queryParams = array(
			'module' => 'FYN_Xero',
			'action' => 'InovicelisttoSugar',
			'xstatus' => $status,
			'message' => $response['message']
			);
			 
			SugarApplication::redirect('index.php?' . http_build_query($queryParams));
			exit;
		}
		
        
		$queryParams = array(
		'module' => 'FYN_Xero',
		'action' => 'InovicelisttoSugar',
		);
		 
		SugarApplication::redirect('index.php?' . http_build_query($queryParams));
		exit;
    }
	
}