<?php
if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');

require_once("modules/FYN_Xero/Classes/FYN_Xero.php");

class CLS_FYN_XeroHook {
	## START Proudct Tempate Add or Update Product Item
	function Add_product_xero(&$bean, $event, $arguments){
		global $db, $sugar_config;
		 
		if(ClsFYNXero::$webhooks_call)
			return true;
		
        
         
        
		$syc_xero = false;
		$cached_mappings = ClsFYNXero::GetMappingField($bean->module_dir);
		$field_options = ClsFYNXero::get_importable_field($bean);
		foreach($field_options as $value=>$name){
			if($cached_mappings['fields'][$value]['mapping']['sugarcrm_name']==$value){
				if($bean->$value != $bean->fetched_row[$value])
					$syc_xero = true;
			}
		}

		if(!$syc_xero)
			return true;
	
		$field_mapping = array(); $field_mapping_pur = array(); $field_mapping_sales = array();
		foreach($field_options as $value=>$name){
			if($cached_mappings['fields'][$value]['mapping']['sugarcrm_name']==$value){
				if($cached_mappings['fields'][$value]['type']=="PurchaseDetails")
					$field_mapping_pur[$cached_mappings['fields'][$value]['mapping']['xero_name']] = $bean->$value;	
				else if($cached_mappings['fields'][$value]['type']=="SalesDetails")
					$field_mapping_sales[$cached_mappings['fields'][$value]['mapping']['xero_name']] = $bean->$value;
				else
					$field_mapping[$cached_mappings['fields'][$value]['mapping']['xero_name']] = $bean->$value;
			}
		}
		
		## Sync Product Template Item to Xero Item
		if(!empty($bean->fyn_xero_itemid))
		{
			$new_item = array(
				array(
					"ItemID" => $bean->fyn_xero_itemid,
					"Code" => $field_mapping['Code'],
					"Description" => $field_mapping['Description'],
					"PurchaseDetails" => array(
						"UnitPrice" => $field_mapping_pur['UnitPrice'],
						"AccountCode" => $field_mapping_pur['AccountCode'],
						"TaxType" => $field_mapping_pur['TaxType'],
					),
					"SalesDetails" => array(
						"UnitPrice" => $field_mapping_sales['UnitPrice'],
						"AccountCode" => $field_mapping_sales['AccountCode'],
						"TaxType" => $field_mapping_sales['TaxType'],
					),
				)
			);
		}else{
			$new_item = array(
				array(
					"Code" => $field_mapping['Code'],
					"Description" => $field_mapping['Description'],
					"PurchaseDetails" => array(
						"UnitPrice" => $field_mapping_pur['UnitPrice'],
						"AccountCode" => $field_mapping_pur['AccountCode'],
						"TaxType" => $field_mapping_pur['TaxType'],
					),
					"SalesDetails" => array(
						"UnitPrice" => $field_mapping_sales['UnitPrice'],
						"AccountCode" => $field_mapping_sales['AccountCode'],
						"TaxType" => $field_mapping_sales['TaxType'],
					),
				)
			);
		} 
        
        ## Delete All Record Previous Sync
        $qry_del = "DELETE FROM fyn_xero WHERE fyn_module_id = '".$bean->id."'";
        $GLOBALS['db']->query($qry_del);
        
		## Save Record for Cron Fire - Sync with Xero
		$FYN_Xero = new FYN_Xero();
		$FYN_Xero->name = 'ProductItemsAdd';
		$FYN_Xero->fyn_module_name = $bean->module_dir;
		$FYN_Xero->fyn_module_id = $bean->id;
		$FYN_Xero->description = base64_encode(serialize($new_item));
		$FYN_Xero->save();
	}
	## END Proudct Tempate Add or Update Product Item

	## START Sugar Account Add or Update Xero Contact Update or Add
	function Add_account_xero(&$bean, $event, $arguments){
		global $db, $sugar_config;
		## Webhooks Call OR Xero to SugarCRM Sync
		if(ClsFYNXero::$webhooks_call)
			return true;
		
               
		$syc_xero = false;
		$cached_mappings = ClsFYNXero::GetMappingField('Accounts');
		$field_options = ClsFYNXero::get_importable_field($bean);
		foreach($field_options as $value=>$name){
			if($cached_mappings['Accounts'][$value]['mapping']['sugarcrm_name']==$value){
				if($bean->$value != $bean->fetched_row[$value])
					$syc_xero = true;
			}
		}

		if(!$syc_xero)
			return true;
	
		$field_mapping = array(); $field_mapping_pur = array(); $field_mapping_sales = array();
		foreach($field_options as $value=>$name){
			if($cached_mappings['Accounts'][$value]['mapping']['sugarcrm_name']==$value){
				if($cached_mappings['Accounts'][$value]['type']=="Addresses")
					$field_mapping["Addresses"][$cached_mappings['Accounts'][$value]['AddressType']][$cached_mappings['Accounts'][$value]['mapping']['xero_name']] = $bean->$value;	
				else if($cached_mappings['Accounts'][$value]['type']=="Phones")
					$field_mapping['Phones'][$cached_mappings['Accounts'][$value]['PhoneType']][$cached_mappings['Accounts'][$value]['mapping']['xero_name']] = $bean->$value;
				else if($cached_mappings['Accounts'][$value]['type']=="Balances")
					$field_mapping['Balances'][$cached_mappings['Accounts'][$value]['BalanceType']][$cached_mappings['Accounts'][$value]['mapping']['xero_name']] = $bean->$value;
				else if($cached_mappings['Accounts'][$value]['type']=="BatchPayments")
					$field_mapping['BatchPayments'][$cached_mappings['Accounts'][$value]['BatchType']][$cached_mappings['Accounts'][$value]['mapping']['xero_name']] = $bean->$value;
				else if($cached_mappings['Accounts'][$value]['type']=="PaymentTerms")
					$field_mapping['PaymentTerms'][$cached_mappings['Accounts'][$value]['PaymentType']][$cached_mappings['Accounts'][$value]['mapping']['xero_name']] = $bean->$value;
				else
					$field_mapping[$cached_mappings['Accounts'][$value]['mapping']['xero_name']] = $bean->$value;
			}else if($cached_mappings['Accounts']['email1']['mapping']['sugarcrm_name']=='email1'){
				$field_mapping['EmailAddress'] = $bean->email1;
			}
		}
		## START Account Related Primary Person Contact
		if(!empty($bean->primary_contact_id) || $bean->primary_contact_id != $bean->fetched_row['primary_contact_id'])
		{
			$bean_contact = BeanFactory::getBean('Contacts', $bean->primary_contact_id);
			$field_options = ClsFYNXero::get_importable_field($bean_contact);
			foreach($field_options as $value=>$name){
				if($cached_mappings['Contacts'][$value]['mapping']['sugarcrm_name']==$value){
					if($cached_mappings['Contacts'][$value]['type']=="Addresses")
						$field_mapping["Addresses"][$cached_mappings['Contacts'][$value]['AddressType']][$cached_mappings['Contacts'][$value]['mapping']['xero_name']] = $bean_contact->$value;	
					else if($cached_mappings['Contacts'][$value]['type']=="Phones")
						$field_mapping['Phones'][$cached_mappings['Contacts'][$value]['PhoneType']][$cached_mappings['Contacts'][$value]['mapping']['xero_name']] = $bean_contact->$value;
					else if($cached_mappings['Contacts'][$value]['type']=="Balances")
						$field_mapping['Balances'][$cached_mappings['Contacts'][$value]['BalanceType']][$cached_mappings['Contacts'][$value]['mapping']['xero_name']] = $bean_contact->$value;
					else
						$field_mapping[$cached_mappings['Contacts'][$value]['mapping']['xero_name']] = $bean_contact->$value;
				}else if($cached_mappings['Contacts']['email1']['mapping']['sugarcrm_name']=='email1'){
					$field_mapping['EmailAddress'] = $bean_contact->email1;
				}
			}
		}
		## END Account Related Primary Person Contact
		
		#echo '<pre>';
		#print_r($field_mapping);
		#exit;
		
		## START XERO ADDRESS Array Created
		$Addresses = array();
		foreach($field_mapping["Addresses"] as $key=>$address)
		{
			$vcode = explode(chr(13), $address['AddressLine1']);
			$addressline1 = array(); $addlp = 1;
			foreach($vcode as $addline){
				$addressline1['AddressLine'.$addlp] = trim($addline);
				$addlp++;
			}
			$tmpAddresses = array('AddressType' => $key, 'City' => $address['City'], 'Region' => $address['Region'], 'PostalCode' => $address['PostalCode'], 'Country' => $address['Country'], 'AttentionTo' => $address['AttentionTo']);
			
			$Addresses['Address'][] = array_merge($tmpAddresses, $addressline1);
		}
		## END XERO ADDRESS Array Created
		
		## START XERO PHONES Array Created
		$Phones = array();
		foreach($field_mapping["Phones"] as $key=>$Phone)
		{
			$Phones['Phone'][] = array('PhoneType' => $key, 'PhoneNumber' => $Phone['PhoneNumber'], 'PhoneAreaCode' => $Phone['PhoneAreaCode'], 'PhoneCountryCode' => $Phone['PhoneCountryCode']);
		}
		## END XERO PHONES Array Created
		
		## START XERO Balances Array Created
		$Balances = array();
		foreach($field_mapping["Balances"] as $key=>$Balance)
		{
			$Balances[$key] = array('Outstanding' => $Balance['Outstanding'], 'Overdue' => $Balance['Overdue']);
		}
		## END XERO Balances Array Created
		
		## START XERO Balances Array Created
		$BatchPayments = array();
		foreach($field_mapping["BatchPayments"] as $key=>$BatchPay)
		{
			$BatchPayments = array('BankAccountNumber' => $BatchPay['BankAccountNumber'], 'BankAccountName' => $BatchPay['BankAccountName'], 'Details' => $BatchPay['Details']);
		}
		## END XERO Balances Array Created
		
		## START XERO Balances Array Created
		$PaymentTerms = array();
		foreach($field_mapping["PaymentTerms"] as $key=>$PaymentTer)
		{
			$PaymentTerms[$key] = array('Day' => $PaymentTer['Day'], 'Type' => $PaymentTer['Type']);
		}
		## END XERO Balances Array Created
		#echo '<pre>';
		#print_r($PaymentTerms);
		#exit;
		
		## Sync Sugar Account to Xero Contact
		if(!empty($bean->fyn_xero_contactid))
		{
			$new_item = array(
				array(
					"ContactID" => $bean->fyn_xero_contactid,
					"AccountNumber" => $field_mapping['AccountNumber'],
					"Name" => $field_mapping['Name'],
					"FirstName" => $field_mapping['FirstName'],
                    "LastName" => $field_mapping['LastName'],
					"EmailAddress" => $field_mapping['EmailAddress'],
					"SkypeUserName" => $field_mapping['SkypeUserName'],
					"TaxNumber" => $field_mapping['TaxNumber'],
					"AccountsReceivableTaxType" => $field_mapping['AccountsReceivableTaxType'],
					"AccountsPayableTaxType" => $field_mapping['AccountsPayableTaxType'],
					"DefaultCurrency" => $field_mapping['DefaultCurrency'],
					"PurchasesDefaultAccountCode" => $field_mapping['PurchasesDefaultAccountCode'],
					"SalesDefaultAccountCode" => $field_mapping['SalesDefaultAccountCode'],
					"Addresses" => $Addresses,
					"Phones" => $Phones,
				)
			);
		}else{
			$new_item = array(
				array(
					"AccountNumber" => $field_mapping['AccountNumber'],
					"Name" => $field_mapping['Name'],
					"FirstName" => $field_mapping['FirstName'],
                    "LastName" => $field_mapping['LastName'],
					"EmailAddress" => $field_mapping['EmailAddress'],
					"SkypeUserName" => $field_mapping['SkypeUserName'],
					"TaxNumber" => $field_mapping['TaxNumber'],
					"AccountsReceivableTaxType" => $field_mapping['AccountsReceivableTaxType'],
					"AccountsPayableTaxType" => $field_mapping['AccountsPayableTaxType'],
					"DefaultCurrency" => $field_mapping['DefaultCurrency'],
					"PurchasesDefaultAccountCode" => $field_mapping['PurchasesDefaultAccountCode'],
					"SalesDefaultAccountCode" => $field_mapping['SalesDefaultAccountCode'],
					"Addresses" => $Addresses,
					"Phones" => $Phones,
				)
			);
		} 
		#print_r($new_item);
		#exit;
		## Delete All Record Previous Sync
        $qry_del = "DELETE FROM fyn_xero WHERE id = '".$bean->id."'";
        $GLOBALS['db']->query($qry_del);
        
		## Save Record for Cron Fire - Sync with Xero
		$FYN_Xero = new FYN_Xero();
		$FYN_Xero->name = 'ContactListAdd';
		$FYN_Xero->fyn_module_name = $bean->module_dir;
		$FYN_Xero->fyn_module_id = $bean->id;
		$FYN_Xero->description = base64_encode(serialize($new_item));
		$FYN_Xero->save();
	}
	## END Sugar Account Add or Update Xero Contact Update or Add
	
	## START Sugar Contact Add or Update Xero Contact Primary Person Details 
	function Add_Contact_xero(&$bean, $event, $arguments){
		global $db, $sugar_config;
		
		
		## Webhooks Call OR Xero to SugarCRM Sync
		if(ClsFYNXero::$webhooks_call){
			return true;
		}
		
		
		
		              
		$syc_xero = false;
		$cached_mappings = ClsFYNXero::GetMappingField('Accounts');
		$field_options = ClsFYNXero::get_importable_field($bean);
		foreach($field_options as $value=>$name){
			if($cached_mappings['Contacts'][$value]['mapping']['sugarcrm_name']==$value){
				if($bean->$value != $bean->fetched_row[$value])
					$syc_xero = true;
			}
		}

		if(!$syc_xero)
			return true;
			
	
		$bean_account = BeanFactory::getBean('Accounts');
		$bean_account->retrieve_by_string_fields(array('primary_contact_id' => $bean->id ));
		if(empty($bean_account->id) || empty($bean_account->fyn_xero_contactid))
			return true;
			
		///isssssssssssssssssss
		$field_options_acc = ClsFYNXero::get_importable_field($bean_account);
		$field_mapping = array(); $field_mapping_pur = array(); $field_mapping_sales = array();
		foreach($field_options_acc as $value=>$name){
			if($cached_mappings['Accounts'][$value]['mapping']['sugarcrm_name']==$value){
				if($cached_mappings['Accounts'][$value]['type']=="Addresses")
					$field_mapping["Addresses"][$cached_mappings['Accounts'][$value]['AddressType']][$cached_mappings['Accounts'][$value]['mapping']['xero_name']] = $bean_account->$value;	
				else if($cached_mappings['Accounts'][$value]['type']=="Phones")
					$field_mapping['Phones'][$cached_mappings['Accounts'][$value]['PhoneType']][$cached_mappings['Accounts'][$value]['mapping']['xero_name']] = $bean_account->$value;
				else
					$field_mapping[$cached_mappings['Accounts'][$value]['mapping']['xero_name']] = $bean_account->$value;
			}else if($cached_mappings['Accounts']['email1']['mapping']['sugarcrm_name']=='email1'){
				$field_mapping['EmailAddress'] = $bean_account->email1;
			}
		}
		
		foreach($field_options as $value=>$name){
			if($cached_mappings['Contacts'][$value]['mapping']['sugarcrm_name']==$value){
				if($cached_mappings['Contacts'][$value]['type']=="Addresses")
					$field_mapping["Addresses"][$cached_mappings['Contacts'][$value]['AddressType']][$cached_mappings['Contacts'][$value]['mapping']['xero_name']] = $bean->$value;	
				else if($cached_mappings['Contacts'][$value]['type']=="Phones")
					$field_mapping['Phones'][$cached_mappings['Contacts'][$value]['PhoneType']][$cached_mappings['Contacts'][$value]['mapping']['xero_name']] = $bean->$value;
				else
					$field_mapping[$cached_mappings['Contacts'][$value]['mapping']['xero_name']] = $bean->$value;
			}else if($cached_mappings['Contacts']['email1']['mapping']['sugarcrm_name']=='email1'){
				$field_mapping['EmailAddress'] = $bean->email1;
			}
		}
				
		
		
		#echo '<pre>';
		#print_r($field_mapping);
		#exit;
		
		## START XERO ADDRESS Array Created
		$Addresses = array();
		foreach($field_mapping["Addresses"] as $key=>$address)
		{
			$vcode = explode(chr(13), $address['AddressLine1']);
			$addressline1 = array(); $addlp = 1;
			foreach($vcode as $addline){
				$addressline1['AddressLine'.$addlp] = trim($addline);
				$addlp++;
			}
			$tmpAddresses = array('AddressType' => $key, 'City' => $address['City'], 'Region' => $address['Region'], 'PostalCode' => $address['PostalCode'], 'Country' => $address['Country'], 'AttentionTo' => $address['AttentionTo']);
			
			$Addresses['Address'][] = array_merge($tmpAddresses, $addressline1);
		}
		## END XERO ADDRESS Array Created
		
		## START XERO PHONES Array Created
		$Phones = array();
		foreach($field_mapping["Phones"] as $key=>$Phone)
		{
			$Phones['Phone'][] = array('PhoneType' => $key, 'PhoneNumber' => $Phone['PhoneNumber'], 'PhoneAreaCode' => $Phone['PhoneAreaCode'], 'PhoneCountryCode' => $Phone['PhoneCountryCode']);
		}
		## END XERO PHONES Array Created
		
		#echo '<pre>';
		#print_r($PaymentTerms);
		#exit;
		
		## Sync Sugar Account to Xero Contact
		$new_item = array(
			array(
				"ContactID" => $bean_account->fyn_xero_contactid,
				"AccountNumber" => $field_mapping['AccountNumber'],
				"Name" => $field_mapping['Name'],
				"FirstName" => $field_mapping['FirstName'],
				"LastName" => $field_mapping['LastName'],
				"EmailAddress" => $field_mapping['EmailAddress'],
				"SkypeUserName" => $field_mapping['SkypeUserName'],
				"TaxNumber" => $field_mapping['TaxNumber'],
				"AccountsReceivableTaxType" => $field_mapping['AccountsReceivableTaxType'],
				"AccountsPayableTaxType" => $field_mapping['AccountsPayableTaxType'],
				"Addresses" => $Addresses,
				"Phones" => $Phones,
			)
		);
		 
		## Delete All Record Previous Sync
        $qry_del = "DELETE FROM fyn_xero WHERE fyn_module_id = '".$bean->id."'";
        $GLOBALS['db']->query($qry_del);
        
		## Save Record for Cron Fire - Sync with Xero
		$FYN_Xero = new FYN_Xero();
		$FYN_Xero->name = 'ContactListAdd';
		$FYN_Xero->fyn_module_name = $bean->module_dir;
		$FYN_Xero->fyn_module_id = $bean->id;
		$FYN_Xero->description = base64_encode(serialize($new_item));
		$FYN_Xero->save();
	}
	## END Sugar Contact Add or Update Xero Contact Primary Person Details 
	
	## START Sugar Quote Add or Update Xero Invoice/Bills Update or Add
	function Add_Quote_xero(&$bean, $event, $arguments){
		global $db, $sugar_config;
        if($bean->object_name != 'AOS_Quotes') return true;
		## Webhooks Call OR Xero to SugarCRM Sync
		if(ClsFYNXero::$webhooks_call)
			return true;
		
               
		if($bean->fyn_xero_status=='DELETED')
			return true;
		
		$bean_account = BeanFactory::getBean('Accounts', $bean->billing_account_id);
		$field_mapping_account = array();
		$field_mapping_account['Contact']['ContactID'] = $bean_account->fyn_xero_contactid;
		$field_mapping_account['Contact']['Name'] = $bean_account->name;
		
		$cached_mappings = ClsFYNXero::GetMappingField('AOS_Quotes');
		$field_options = ClsFYNXero::get_importable_field($bean);
	
		$field_mapping = array();
		foreach($field_options as $value=>$name){
			if($cached_mappings['AOS_Quotes'][$value]['readonly'])
				continue;
			if($cached_mappings['AOS_Quotes'][$value]['mapping']['sugarcrm_name']==$value){
			    if($value == 'fyn_xero_currencycode'){
			        require_once('modules/Currencies/ListCurrency.php');
                    $currency = new ListCurrency();
                    $currency->lookupCurrencies();
                    foreach($currency->list as $currencyList)
                    {
                        if($currencyList->id == $bean->currency_id)
                            $field_mapping[$cached_mappings['AOS_Quotes'][$value]['mapping']['xero_name']] = $currencyList->iso4217;   
                    }
			    }else{
				    $field_mapping[$cached_mappings['AOS_Quotes'][$value]['mapping']['xero_name']] = $bean->$value;
                }
			}
		}
		
		$sql = "SELECT pg.id, pg.group_id FROM aos_products_quotes pg LEFT JOIN aos_line_item_groups lig ON pg.group_id = lig.id WHERE pg.parent_type = '".$bean->object_name."' AND pg.parent_id = '".$bean->id."' AND pg.deleted = 0 ORDER BY lig.number ASC, pg.number ASC";
        $results = $db->query($sql);
        $num_row = $db->getRowCount($results);
        $LineItems = array();
		if($num_row > 0 )
		{
			    
			#$product_bundle = $product_bundle_list[0];
			#$bundle_list = $product_bundle->get_product_bundle_line_items();
			
			## START Lineitems Field Mapping Fetch
			$bean_product = BeanFactory::getBean('AOS_Products_Quotes');
			$field_options = ClsFYNXero::get_importable_field($bean_product);
			$field_mapping_lineitem = array();
			## END Lineitems Field Mapping Fetch
			
            $line_pp = 0;
			while ($row = $db->fetchByAssoc($results)) {
			    $line_item = new AOS_Products_Quotes();
                $line_item->retrieve($row['id']);
                #if ($line_item->object_name == "Product") 
                {
					foreach($field_options as $value=>$name){
						if($bean->fyn_xero_type!='ACCREC' && $cached_mappings['AOS_Products_Quotes'][$value]['mapping']['xero_name']=='DiscountRate')
							continue;
						if($cached_mappings['AOS_Products_Quotes'][$value]['mapping']['sugarcrm_name']==$value){
							$key = $cached_mappings['AOS_Products_Quotes'][$value]['mapping']['xero_name'];
							if($key=='ItemCode'){
								if(!empty($line_item->product_id))
								    $field_mapping_lineitem[$line_pp][$key] = $line_item->$value;
							}else if($key=='DiscountRate'){
							    if(!empty($line_item->$value))
                                    $field_mapping_lineitem[$line_pp][$key] = $line_item->$value;
							}else if($key == 'UnitAmount123'){
							    $field_mapping_lineitem[$line_pp][$key] = $line_item->product_unit_price;
							}else if($key === 'LineAmount'){
							    
							}else{
							    $field_mapping_lineitem[$line_pp][$key] = $line_item->$value;
							}
						}
					}
					$line_pp++;
				}
			}
			
		}
		if($line_pp<=0)
			return true;
		#echo '<pre>';
		#print_r($field_mapping_lineitem);
		#exit;
		
		## Sync Sugar Account to Xero Contact
		if(!empty($bean->fyn_xero_invoiceid))
		{
			$t1 = array();
			$t1['InvoiceID'] = $bean->fyn_xero_invoiceid;
			$t2 = array();
            
			if(count($field_mapping_lineitem)>1)
			     $t2['LineItems']['LineItem'] = $field_mapping_lineitem;
			else
			     $t2['LineItems']['LineItem'] = $field_mapping_lineitem[0];
                 
			$final_item = array_merge($field_mapping_account, $t1, $field_mapping, $t2);
			$new_item = array($final_item);
		}else{
			$t2 = array();
			if(count($field_mapping_lineitem)>1)
			     $t2['LineItems']['LineItem'] = $field_mapping_lineitem;
			else
			     $t2['LineItems']['LineItem'] = $field_mapping_lineitem[0];
            
			$final_item = array_merge($field_mapping_account, $field_mapping, $t2);
			$new_item = array($final_item);
		} 
		#echo '<pre>';
		#print_r($new_item);
		#exit;
		## Delete All Record Previous Sync
        $qry_del = "DELETE FROM fyn_xero WHERE fyn_module_id = '".$bean->id."'";
        $GLOBALS['db']->query($qry_del);
        
		## Save Record for Cron Fire - Sync with Xero
		$FYN_Xero = new FYN_Xero();
		$FYN_Xero->name = 'QuoteListAdd';
		$FYN_Xero->fyn_module_name = $bean->module_dir;
		$FYN_Xero->fyn_module_id = $bean->id;
		$FYN_Xero->description = base64_encode(serialize($new_item));
		$FYN_Xero->save();
	}
	## END Sugar Account Add or Update Xero Contact Update or Add	
	
	## START Sugar Quote After UI Frame JS Call
	function ShowHideSubpanel($event, $arguments){
		if((!isset($_REQUEST['sugar_body_only']) || $_REQUEST['sugar_body_only'] != true) && $_REQUEST['action'] != 'modulelistmenu' && $_REQUEST['action'] != "favorites" && $_REQUEST['action'] != 'Popup' && (!isset($_REQUEST['to_pdf']) || empty($_REQUEST['to_pdf']) || $_REQUEST['to_pdf'] != true) && empty($_REQUEST['to_csv']) && $_REQUEST['action'] != 'Login' && ($_REQUEST['module'] == 'AOS_Quotes' && $_REQUEST['action'] == 'DetailView'))
		{      
		 // echo '<script src="modules/FYN_Xero/quote_general.js" type="text/javascript"></script>';
		}
	}
	
	## START Sugar Quote List Page Display
	function get_Quote_List(&$bean, $event, $arguments){
		global $db, $sugar_config;
		
		if(!empty($bean->fyn_xero_invoiceid))
			$bean->fyn_xero_invoiceid = '<img src="modules/FYN_Xero/tpls/images/green-check-icon.png" />';
		else
			$bean->fyn_xero_invoiceid = '<img src="modules/FYN_Xero/tpls/images/red-check-icon.png" />';
		
	}
	
}

?>