{literal}
<script type="text/javascript">
function dtShowHide(ele, id){
	if(ele.checked==true){
		$('#'+id).hide();
	}else{
		$('#'+id).show();
	}
}
function clicktosavebtn()
{
	if(confirm('Are you sure you want to sync data Xero to SuiteCRM.'))
	{
		$('#FYN_AjaxWaiting').show();
		return true;
	}
	return false;
}
</script>
{/literal}
<form method='post' id='frm_settings' action='index.php'>
<div id="divxero" style="height:100%; width:100%; overflow: hidden;">
<div id="divheader" style="float: left; width:15%;">{include file="modules/FYN_Xero/tpls/top.tpl"}</div>
<div id="divdetails" style="float: left; width:85%;">
<table cellpadding="0" cellspacing="0" border="0" class="FYN_content_table" width="100%">
	<input type="hidden" name="module" value="FYN_Xero" />
    <input type="hidden" name="action" value="contactslisttosugarsync" />
    <input type='hidden' name='clickaction' id="clickaction" value='sugaraccountlist' /> 
    <input type='hidden' name='option' value='save'/> 
    {if count($errors)>0 OR count($success)>0}
    <tr>
        <td colspan="2">
            {foreach from=$errors key=error_key item=error_message}
                <p class="FYN_error_msg">{$error_message}</p>
            {/foreach}
            {foreach from=$success key=success_key item=success_message}
                <p class="FYN_success_msg">{$success_message}</p>
            {/foreach}
        </td>
    </tr>
    {/if}
    <tr height="20"><td colspan="2"></td></tr>
    <tr>
        <td>
        <div style="padding-bottom:10px"><h3>Click on "Sync Account List" to fetch Xero Contact and Synchronize with SuiteCRM Accounts and Contacts.
Xero main contact will be added to SuiteCRM Account module and Xero related person of contact will be added to SuiteCRM Contacts module.</h3></div>
        <div style="padding-bottom:10px; height:22px;">
        	<div style="float:left;padding:0 10px 0 0">All Data Sync: <input type="hidden" name="account_all" value="N" /><input type="checkbox" name="account_all" value="Y" onchange="dtShowHide(this, 'account_modified_dt')" /></div>
        	<div style="float:left;" id="account_modified_dt">Modified After Date: 
            <select name="account_modified_date">
            {foreach from=$modified_date_list item=date_list}
            	<option value="{$date_list.value}">{$date_list.text}</option>
            {/foreach}</select></div>
        </div>
        <br clear="all" />
        <div><input type="submit" class='FYN_button' value="Sync Account List" onclick="return clicktosavebtn()" /></div>
        </td>
    </tr>
    <tr height="20"><td colspan="2"></td></tr>
    <tr height="15">
	  	<td colspan="2" >
        </td>
	</tr>
</table>
</div>
</form>
<div id="FYN_AjaxWaiting" style="display:none" align="center">
<div class="FYN_spinner"><img width="100" height="100" src="modules/FYN_Xero/tpls/images/progress.gif"></img></div>
<div style="margin-left:10px;">Please Wait...</div>
</div>