{literal}
<script type="text/javascript">
function clicktosavebtn(action)
{
	if(confirm('Are you sure you want to sync data Xero to SuiteCRM.'))
	{
		$('#clickaction').val(action);
		$('#FYN_AjaxWaiting').show();
		return true;
	}
	return false;
}
</script>
{/literal}
<form method='post' id='frm_settings' action='index.php'>

<div id="divxero" style="height:100%; width:100%; overflow: hidden;">
<div id="divheader" style="float: left; width:15%;">{include file="modules/FYN_Xero/tpls/top.tpl"}</div>
<div id="divdetails" style="float: left; width:85%;">

<table cellpadding="0" cellspacing="0" border="0" class="FYN_content_table" width="100%">
	<input type="hidden" name="module" value="FYN_Xero" />
    <input type="hidden" name="action" value="xerotosugarsync" />
    <input type='hidden' name='clickaction' id="clickaction" value='' /> 
    <input type='hidden' name='option' value='save'/> 
    {if count($errors)>0 OR count($success)>0}
    <tr>
        <td colspan="2">
            {foreach from=$errors key=error_key item=error_message}
                <p class="FYN_error_msg">{$error_message}</p>
            {/foreach}
            {foreach from=$success key=success_key item=success_message}
                <p class="FYN_success_msg">{$success_message}</p>
            {/foreach}
        </td>
    </tr>
    {/if}
    <tr>
        <td>
        <h3>Click on "Fetch Tax Rate List" to fetch Tax Rate from Xero and Synchronize with SuiteCRM dropdown "Xero Taxes".</h3> <input type="submit" class='FYN_button' value="Fetch Tax Rate List" onclick="return clicktosavebtn('taxrate')" />
        </td>
	</tr>
    <tr height="20"><td colspan="2"></td></tr>
    <tr>
        <td>
        <h3>Click on "Fetch Accounting List" to fetch accounting list from Xero and Synchronize with SuiteCRM dropdown Accounting list.</h3> <input type="submit" class='FYN_button' value="Fetch Accounting List"  onclick="return clicktosavebtn('accountinglist')" />
        </td>
    </tr>
    <tr height="20"><td colspan="2"></td></tr>
    <tr>
        <td>
        <h3>Click on "Fetch Currencies List" to fetch currencies from Xero and Synchronize with SuiteCRM xero_currencies_list.</h3> <input type="submit" class='FYN_button' value="Fetch Currencies List" onclick="return clicktosavebtn('currencies')" />
        </td>
    </tr>
    <tr height="20"><td colspan="2"></td></tr>
    
    <tr height="15">
	  	<td colspan="2" >
        </td>
	</tr>
</table>
</div>
</form>
<div id="FYN_AjaxWaiting" style="display:none" align="center">
<div class="FYN_spinner"><img width="100" height="100" src="modules/FYN_Xero/tpls/images/progress.gif"></img></div>
<div style="margin-left:10px;">Please Wait...</div>
</div>