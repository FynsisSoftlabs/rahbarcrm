{literal}
<script type="text/javascript">
$(document).ready(function(){
    
	$( ".chkbox" ).focus(function() {
		$(this).prop('val', this.checked);
	});
	$(".chkbox").change(function(){
		if(this.checked==false){
			$(this).prop('checked', true);
		}else{
			if($(this).attr('modulenm')=='Contacts'){
				var tmp = $(this).attr('data_attr');
				$('#xero_check1_'+tmp).prop('checked', false);
				$('#xero_Accounts_'+tmp).val('');
			}else{
				var tmp = $(this).attr('data_attr');
				$('#xero_check2_'+tmp).prop('checked', false);
				$('#xero_Contacts_'+tmp).val('');
			}
			
		}
    });
});
function mapping_field_lists(){
	var returnval = true;
	$('.err_module').hide();
	$( ".chkbox" ).each(function( index ) {
		if(this.checked==true){
			if($(this).attr('modulenm')=='Contacts'){
				var tmp = $(this).attr('data_attr');
				if($('#xero_Contacts_'+tmp).val().length==0)
				{
					$('#error_xero_Contacts_'+tmp).show();
					returnval = false;
				}
			}else{
				var tmp = $(this).attr('data_attr');
				if($('#xero_Accounts_'+tmp).val().length==0)
				{	
					$('#error_xero_Accounts_'+tmp).show();
					returnval = false;
				}
			}
		}
	});
	if(returnval)
	{
		if(confirm('Are you sure to save this changes? You cannot revert back with your previous map settings.'))
		{
			$('#FYN_AjaxWaiting').show();
			return true;
		}
	}
	return returnval;
}
function fnreset_field(){
	if(confirm('Are you sure to reset all field mapping with default settings?\nYou will lose all mapped field setting which you had done before.'))
	{
		$('#FYN_AjaxWaiting').show();
		$('#reset_field').val('1');
		return true;
	}
	return false;
}
</script>
{/literal}
<form action="index.php" method="POST">

<div id="divxero" style="height:100%; width:100%; overflow: hidden;">
<div id="divheader" style="float: left; width:15%;">{include file="modules/FYN_Xero/tpls/top.tpl"}</div>
<div id="divdetails" style="float: left; width:85%;">
    
<input type="hidden" name="module" value="FYN_Xero">
<input type="hidden" name="action" value="mapping_fieldsave">
<input type="hidden" name="reset_field" id="reset_field" value="0">
<table cellpadding="0" cellspacing="0" border="0" class="FYN_content_table" width="100%">
	{if count($errors)>0 OR count($success)>0}
    <tr>
        <td colspan="2">
            {foreach from=$errors key=error_key item=error_message}
                <p class="FYN_error_msg">{$error_message}</p>
            {/foreach}
            {foreach from=$success key=success_key item=success_message}
                <p class="FYN_success_msg">{$success_message}</p>
            {/foreach}
        </td>
    </tr>
    {/if}
    <tr>
        <td colspan="2" >
        <div class="FYN_description">
        <p>Map Xero contact fields with either SuiteCRM Account or Contact module. <br />Each Xero contact field must be mapped with either SuiteCRM Contact or Account module.</p>
        </div>
        </td>
    </tr>
    <tr>
    <td colspan="2" >
        <table class="list-table" border="0" cellpadding="2" cellspacing="0" width="100%">
        {$Account_field_mapping}
        </table>
    </td>
    </tr>
	<tr height="15">
    <td colspan="2" ></td>
    </tr>
</table>
</div>
</form>
<div id="FYN_AjaxWaiting" style="display:none" align="center">
<div class="FYN_spinner"><img width="100" height="100" src="modules/FYN_Xero/tpls/images/progress.gif"></img></div>
<div style="margin-left:10px;">Please Wait...</div>
</div>