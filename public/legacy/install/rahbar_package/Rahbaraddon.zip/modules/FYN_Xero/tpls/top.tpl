<link rel="stylesheet" type="text/css" href="modules/FYN_Xero/tpls/fynxero.css">
<br />
<table cellpadding="0" cellspacing="0" border="0" align="center" style="width: 100%;">
  <tr>
  	<td class="FYN_table_head" >
  	<h3 class="FYN_table_head_title"> 
  		<a  {if $active_step == "xero_setup"}class="active"{/if} href="index.php?module=FYN_Xero&action=XeroSetup">Xero API Settings</a>  
  	</h3></td>
  </tr>
 <!--  <tr>
  	<td class="FYN_table_head">
  	<h3 class="FYN_table_head_title"> 
  		<a {if $active_step == "mapping_field"}class="active"{/if}  href="index.php?module=FYN_Xero&action=mapping_field">Map Module Fields</a>
  	</h3></td>
  </tr> -->
   <tr>
  	<td class="FYN_table_head">
  	<h3 class="FYN_table_head_title"> 
  		<a {if $active_step == "XerotoSugar"}class="active"{/if}  href="index.php?module=FYN_Xero&action=XerotoSugar">Xero >> SuiteCRM</a>
  	</h3></td>
  </tr>
   <tr>
  	<td class="FYN_table_head">
  	<h3 class="FYN_table_head_title"> 
 	   	<a {if $active_step == "InventrylisttoSugar"}class="active"{/if}  href="index.php?module=FYN_Xero&action=InventrylisttoSugar">Inventory List >> SuiteCRM</a>
  	</h3></td>
  </tr>
   <tr>
  	<td class="FYN_table_head">
  	<h3 class="FYN_table_head_title"> 
  		 <a {if $active_step == "ContactslisttoSugar"}class="active"{/if}  href="index.php?module=FYN_Xero&action=ContactslisttoSugar">Contacts List >> SuiteCRM</a>
  	</h3></td>
  </tr>
  <tr>
  	<td class="FYN_table_head">
  	<h3 class="FYN_table_head_title"> 
  		<a {if $active_step == "InovicelisttoSugar"}class="active"{/if}  href="index.php?module=FYN_Xero&action=InovicelisttoSugar">Invoice List >> SuiteCRM</a> 
  	</h3></td>
  </tr>
</table>