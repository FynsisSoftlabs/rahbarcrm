{literal} 
<script type="text/javascript">
save_settings = function () {
	$('.err_module').hide();
	var not_error = true;
	if($('#fynconsumer_key').val().length<=0){
		$('#error_fynconsumer_key').show();
		not_error = false;
	}
	
	if($('#fynconsumer_secret').val().length<=0){
		$('#error_fynconsumer_secret').show();
		not_error = false;
	}
	
	if($('#fynpublic_key').val().length<=0){
		$('#error_fynpublic_key').show();
		not_error = false;
	}
	
	if($('#fynprivate_key').val().length<=0){
		$('#error_fynprivate_key').show();
		not_error = false;
	}
	
	if(not_error)
	{
		$('#FYN_AjaxWaiting').show();
	}
	return not_error;
};
function show_hide_key()
{
	$('#generate_public_key').toggle();
}
</script> 
{/literal}

 <form method='post' id='frm_settings' action='index.php'>
 
 
 	<div id="divxero" style="height:100%; width:100%; overflow: hidden;">
    <div id="divheader" style="float: left; width:15%;">{include file="modules/FYN_Xero/tpls/top.tpl"}</div>
    <div id="divdetails" style="float: left; width:85%;">
		 <table cellpadding="0" cellspacing="0" border="0" class="FYN_content_table" width="100%">
		 
		  <input type="hidden" name="module" value="FYN_Xero">
		  <input type="hidden" name="action" value="xerosetupsave">
		  <input type='hidden' name='option' value='save'/> 
		  {if count($errors)>0 OR count($success)>0}
		    <tr>
		        <td colspan="2">
		            {foreach from=$errors key=error_key item=error_message}
		                <p class="FYN_error_msg">{$error_message}</p>
		            {/foreach}
		            {foreach from=$success key=success_key item=success_message}
		                <p class="FYN_success_msg">{$success_message}</p>
		            {/foreach}
		        </td>
		    </tr>
		    {/if}
		  <tr>
		  	<td colspan="2">
		    	<!-- <a href="#" onclick="show_hide_key();return false;" style="padding: 7px 10px 7px 10px; background:#A4A4A4; text-decoration: none; color: #ffffff; box-shadow: 5px 0 5px -5px #333, -5px 0 5px -5px #333;">Generate a public/private key pair</a> -->
		        <table cellpadding="0" cellspacing="0" border="0" width="100%" id="generate_public_key" style="display:none; margin-top:10px;">
		          <tr>
		            <td width="150" valign="top">Public Key:</td>
		            <td><textarea rows="6" cols="100">-----BEGIN CERTIFICATE-----
		MIIEATCCA2qgAwIBAgIJAIbyw62JolHvMA0GCSqGSIb3DQEBBQUAMIGyMQswCQYD
		VQQGEwJJTjEQMA4GA1UECBMHR3VqYXJhdDESMBAGA1UEBxMJQWhtZWRhYmFkMSUw
		IwYDVQQKExxPZmZzaG9yZSBFdm9sdXRpb24gUHZ0LiBMdGQuMRQwEgYDVQQLEwtE
		ZXZlbG9wbWVudDEPMA0GA1UEAxMGUGFyZXNoMS8wLQYJKoZIhvcNAQkBFiBvZmZz
		aG9yZWV2b2x1dGlvbnRlc3QxQGdtYWlsLmNvbTAeFw0xNTA0MTMwNjI4MjhaFw0y
		MDA0MTEwNjI4MjhaMIGyMQswCQYDVQQGEwJJTjEQMA4GA1UECBMHR3VqYXJhdDES
		MBAGA1UEBxMJQWhtZWRhYmFkMSUwIwYDVQQKExxPZmZzaG9yZSBFdm9sdXRpb24g
		UHZ0LiBMdGQuMRQwEgYDVQQLEwtEZXZlbG9wbWVudDEPMA0GA1UEAxMGUGFyZXNo
		MS8wLQYJKoZIhvcNAQkBFiBvZmZzaG9yZWV2b2x1dGlvbnRlc3QxQGdtYWlsLmNv
		bTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAr+tkvMIAT70MHanLKHDZSEgv
		zuWWAkVi8cXqv8yADd8kqrLbdRgn3gDm0wmqcIBI6/jCrcfyeh8ipzjrVrjV34ir
		v+bluJ+gwsqyGMyEpm2nhX98iTISShQymKZ4rciR7gaGWljA8Ee9slEqeCbSB7XH
		sLzKZhhY0JUeyicDGt8CAwEAAaOCARswggEXMB0GA1UdDgQWBBT8m112NihOmRx3
		MYQAaOYsUViivjCB5wYDVR0jBIHfMIHcgBT8m112NihOmRx3MYQAaOYsUViivqGB
		uKSBtTCBsjELMAkGA1UEBhMCSU4xEDAOBgNVBAgTB0d1amFyYXQxEjAQBgNVBAcT
		CUFobWVkYWJhZDElMCMGA1UEChMcT2Zmc2hvcmUgRXZvbHV0aW9uIFB2dC4gTHRk
		LjEUMBIGA1UECxMLRGV2ZWxvcG1lbnQxDzANBgNVBAMTBlBhcmVzaDEvMC0GCSqG
		SIb3DQEJARYgb2Zmc2hvcmVldm9sdXRpb250ZXN0MUBnbWFpbC5jb22CCQCG8sOt
		iaJR7zAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBAGMeJuBbECISCkVg
		818MMnLn//eRnbpqGWgjsGFaHgSe27oJuYuu69aeKT7ngoIVQaBwCzgXxq/Knhie
		rz3T7+q4YTPua+tPqiP95bhzzuxTHAXDaSpeauoyyKTJX5Sda9U/oVxF70IUlA3f
		VeQdmoQTS/4OBLTrK08c4dePL1W4
		-----END CERTIFICATE-----</textarea>
		            </td>
		          </tr>
		          <tr><td colspan="2" height="10"></td></tr>
		          <tr>
		            <td width="150" valign="top">Private Key:</td>
		            <td><textarea rows="6" cols="100">-----BEGIN RSA PRIVATE KEY-----
		MIICXAIBAAKBgQCv62S8wgBPvQwdqcsocNlISC/O5ZYCRWLxxeq/zIAN3ySqstt1
		GCfeAObTCapwgEjr+MKtx/J6HyKnOOtWuNXfiKu/5uW4n6DCyrIYzISmbaeFf3yJ
		MhJKFDKYpnityJHuBoZaWMDwR72yUSp4JtIHtcewvMpmGFjQlR7KJwMa3wIDAQAB
		AoGBAI7mc+ow3Pfo5RKjfnfXU2k32j4CmRw3KOykjNBIWizqemp+523ytU/NA7Oi
		QmUokBO++sUXioxRBmE4B1NmybN00w+VpzdepWQy69DokntrD/L42JKXZg898UsT
		xtRS0Tz1J8Pqdaemz7b55VSDX1SPFKszDClHYn3jLOzt4XaBAkEA5zjTq+zbON5Y
		iwHw7Z5AMa0dhvyLw99LL7XtnbBnwjhnVGA222H/mnBufW8uN3uWgB556XPEjmgH
		CTI08FGOTwJBAMLFcHzM6GAtZ/8salN8pRFlCSg0iInzy7BMsNt+ZBnAG6kHLyec
		+4ELfdUYh20Y95f8JRyDBijreOeuah0PlnECQBBsYeSRU1TrviBJiAJoviiJIlLH
		N2o3PxDpfDI6KHSMKxK8LslQYaZnnAF+1yqLtbnt8DzbwzdWPkGx9j6nnFMCQA6G
		21Tzk4FY4aDOlz+S1FzvxDcTc/uWC2Mi1S4Jxz2Ebou01XeG5dtCGCiEo9UnP5A+
		ZiYyP4tdxK7C+3cfaoECQBbf4T3FczvXU6ERl7LXvHQ4v/1f6jVpSF5KXSc1ufXJ
		oiu3zUCvb46AKBdKDpyAR3Ic4vYL7S7U/b885WnycJY=
		-----END RSA PRIVATE KEY-----</textarea>
		        	<br />
		            <a href="http://app.xero.com/Application/Add" target="_blank">Click Here to Create Xero API Application</a>
		            </td>
		          </tr>
		          <tr height="20"><td colspan="2"></td></tr>
		        </table>
		    </td>	
		  </tr>
		  <tr><td colspan="2" height="10"></td></tr>
		  <tr>
		  	<td colspan="2" >
		      <div class="FYN_description" {if $no_error !== true}style="background-color:#c88888; color:#fff" {/if}>
		    	 {if $xero_connection === true}
		          <p>Xero Connection: <img src="modules/FYN_Xero/tpls/images/green-check-icon.png"> Success</p>
		          {else}
		          <p>Xero Connection: <img src="modules/FYN_Xero/tpls/images/red-check-icon.png"> Error</p>
		          {/if}
		      </div>
		    </td>
		  </tr>	
		  <tr>
		  	<td width="150">Consumer Key:</td>
		    <td><input type="text" id="fynconsumer_key" name="fynconsumer_key" value="{$fynconsumer_key}" class="span8 FYN_inpu_box" size="50"  />
		    	<span class="err_module" id="error_fynconsumer_key" style="display:none">Please Enter Consumer Key.</span>
		    </td>
		  </tr>
		  <tr><td colspan="2" height="10"></td></tr>
		  <tr>
		  	<td width="150">Consumer Secret:</td>
		    <td><input type="text" id="fynconsumer_secret" name="fynconsumer_secret" value="{$fynconsumer_secret}" class="span8 FYN_inpu_box" size="50"  />
		    <span class="err_module" id="error_fynconsumer_secret" style="display:none">Please Enter Consumer Secret.</span>
		    </td>
		  </tr>
		  <tr><td colspan="2" height="10"></td></tr>
		  <tr>
		  	<td width="150" valign="top">Public Key:</td>
		    <td><textarea id="fynpublic_key" name="fynpublic_key" rows="6" cols="100">{$fynpublic_key}</textarea>
		    <span class="err_module" id="error_fynpublic_key" style="display:none">Please Enter Public Key.</span>
		    </td>
		  </tr>
		  <tr><td colspan="2" height="10"></td></tr>
		  <tr>
		  	<td width="150" valign="top">Private Key:</td>
		    <td><textarea id="fynprivate_key" name="fynprivate_key" rows="6" cols="100">{$fynprivate_key}</textarea>
		    <span class="err_module" id="error_fynprivate_key" style="display:none">Please Enter Private Key.</span>
		    </td>
		  </tr>
		  <tr><td colspan="2" height="10"></td></tr>
		  <tr>
		  	<td width="100"></td>
		    <td style="padding-left: 10px;"><input type='submit' class='button FYN_button' value='Connect to Xero' onclick='return save_settings();' >
		    </td>
		  </tr>
		  <tr height="15">
		    <td colspan="2">
		    	<div id='response_text'></div>
		    </td>
		  </tr>
		  
		  <tr height="20"><td colspan="2"></td></tr>
		</table>
    </div>
     
</div>
 
 
 

 </form>
<div id="FYN_AjaxWaiting" style="display:none" align="center">
<div class="FYN_spinner"><img width="100" height="100" src="modules/FYN_Xero/tpls/images/progress.gif"></img></div>
<div style="margin-left:10px;">Please Wait...</div>
</div>