<?php
$job_strings[] = 'fyn_crmtoxero_cronjob';
$job_strings[] = 'fyn_xeroto_inventry_cronjob';
$job_strings[] = 'fyn_xeroto_Account_cronjob';
$job_strings[] = 'fyn_xeroto_Quote_cronjob';

require_once('modules/FYN_Xero/Classes/XerotoSugarCRM.php');

## START Sugar to Xero Cron Run
function fyn_crmtoxero_cronjob()
{
	global $db, $sugar_config;
    
    $GLOBALS['log']->fatal("Sugar to Xero Cron Running! ");
        
	$xero_bean = BeanFactory::getBean('FYN_Xero');
	$xero_bean_lists = $xero_bean->get_full_list("", "");
	if(count($xero_bean_lists)==0)
		return true;
	
    
	$response = ClsFYNXero::checkxeroApiConnection();
	if ($response['success'] !== true){
		$GLOBALS['log']->fatal("Checking Xero API Key Failed - Run fyn_crmtoxero_cronjob");
		return $response;
	}
	
	 
	$xero_bean = BeanFactory::getBean('FYN_Xero');
	$xero_bean_inventry_lists = $xero_bean->get_full_list("", " fyn_xero.name = 'ProductItemsAdd'");
	if(count($xero_bean_inventry_lists)>0)
	{
		$response = ClsFYNXero::ProductItemsAdd($xero_bean_inventry_lists);
	}
	
	$xero_bean = BeanFactory::getBean('FYN_Xero');
	$xero_bean_account_lists = $xero_bean->get_full_list("", " fyn_xero.name = 'ContactListAdd'");
	if(count($xero_bean_account_lists)>0)
	{
		$response = ClsFYNXero::XeroContactAdd($xero_bean_account_lists);
	}
	
	$xero_bean = BeanFactory::getBean('FYN_Xero');
	$xero_bean_quote_lists = $xero_bean->get_full_list("", " fyn_xero.name = 'QuoteListAdd'");
	if(count($xero_bean_quote_lists)>0)
	{
		$response = ClsFYNXero::XeroInvoiceAdd($xero_bean_quote_lists);
	}
	
	
	return true;
}
## END Sugar to Xero Cron Run

## START Xero to Sugar Inventry List Cron Run
function fyn_xeroto_inventry_cronjob(){
	
	$GLOBALS['log']->fatal("Xero to Sugar Inventry List Cron Running! ");  
    	
	$Administration = new Administration();
	$Administration->retrieveSettings('fyn_xero');
	$last_date = $Administration->settings['fynxero_job_inventry'];
	if(empty($last_date))
		$last_date = date('Y-m-d');
	
	$clsXero_To_SguarCRM = new clsXero_To_SguarCRM();
	$response = $clsXero_To_SguarCRM->sync_Product_List('N', 0, 'Y', $last_date);
	
	if($response['success']==true)
	{
		$administration = new Administration();
		$administration->saveSetting('fyn_xero', 'job_inventry', $response['datetime']);
	}	
	
	return true;
}
## END Xero to Sugar Inventry List Cron Run

## START Xero to Sugar SugarAccount Cron Run
function fyn_xeroto_Account_cronjob(){
	        
	$GLOBALS['log']->fatal("Xero to SugarAccount Cron Running ! ");  
    
	$Administration = new Administration();
	$Administration->retrieveSettings('fyn_xero');
	$last_date = $Administration->settings['fyn_xero_job_account'];
	if(empty($last_date))
		$last_date = date('Y-m-d');
	
	$clsXero_To_SguarCRM = new clsXero_To_SguarCRM();
	$response = $clsXero_To_SguarCRM->sync_Suite_Account_List('N', 0, 'Y', $last_date);
	
	if($response['success']==true)
	{
		$administration = new Administration();
		$administration->saveSetting('fyn_xero', 'job_account', $response['datetime']);
	}
	
	return true;	
}
## END Xero to Sugar SugarAccount List Cron Run

## START Xero to Sugar SugarQuote Cron Run
function fyn_xeroto_Quote_cronjob(){
	        
    $GLOBALS['log']->fatal("Xero to SugarQuote Cron Running ! ");  

	$Administration = new Administration();
	$Administration->retrieveSettings('fyn_xero');
	$last_date = $Administration->settings['fynxero_job_quote'];
	if(empty($last_date))
		$last_date = date('Y-m-d');
	
	$clsXero_To_SguarCRM = new clsXero_To_SguarCRM();
	$response = $clsXero_To_SguarCRM->sync_CRM_Quote_List('N', 0, 'Y', $last_date);
	
	if($response['success']==true)
	{
		$administration = new Administration();
		$administration->saveSetting('fyn_xero', 'job_quote', $response['datetime']);
	}	
	
	return true;
}
## END Xero to Sugar SugarQuote List Cron Run

