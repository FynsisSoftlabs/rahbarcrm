<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('modules/FYN_Xero/Classes/FYN_Xero.php');
// error_reporting(E_ERROR);
// ini_set('display_errors', 1);
class clsXero_To_SguarCRM {
	## START Xero to SugarCRM Sync. Inventry List
	public function sync_Product_List($inventry_all, $no_of_days, $date_used, $modified_date)
	{
	 
		ClsFYNXero::$webhooks_call = true;
		
		$bean = BeanFactory::getBean('AOS_Products');
		
		$cached_mappings = ClsFYNXero::GetMappingField($bean->module_dir);
		$field_options = ClsFYNXero::get_importable_field($bean);
		
		$field_mapping = array();
		foreach($field_options as $value=>$name){
			if($cached_mappings['fields'][$value]['mapping']['sugarcrm_name']==$value){
				if($cached_mappings['fields'][$value]['type']=="PurchaseDetails")
					$field_mapping["PurchaseDetails"][$cached_mappings['fields'][$value]['mapping']['xero_name']] = $value;	
				else if($cached_mappings['fields'][$value]['type']=="SalesDetails")
					$field_mapping["SalesDetails"][$cached_mappings['fields'][$value]['mapping']['xero_name']] = $value;
				else
					$field_mapping[$cached_mappings['fields'][$value]['mapping']['xero_name']] = $value;
			}
		}
		
		if(empty(ClsFYNXero::$fynGetAPIDetails['fynconsumer_key']))
			ClsFYNXero::getXeroAPIDetails();
		$fynGetAPIDetails = ClsFYNXero::$fynGetAPIDetails;
		try {
			$xero = new Xero($fynGetAPIDetails['fynconsumer_key'], $fynGetAPIDetails['fynconsumer_secret'], $fynGetAPIDetails['fynpublic_key'], $fynGetAPIDetails['fynprivate_key'], 'json' );
		
			if($inventry_all=='Y'){
				$inventry_itemlists = $xero->Items;
			}else{
				if($date_used=='Y'){
					$m_date = $modified_date;
				}else{
					if(!is_numeric($no_of_days))
						$no_of_days = 1;
					$m_date = date('Y-m-d', strtotime("-".$no_of_days." days"));
				}
				$inventry_itemlists = $xero->Items(false, $m_date, array());
			}

            #echo '<pre>';
            #print_r($xero);
            #exit;

			if(count($inventry_itemlists['Items']['Item'])>0)
			{
				if(count($inventry_itemlists['Items']['Item'][0])>1)
				{
					foreach($inventry_itemlists['Items']['Item'] as $items)
					{
						$this->Xeroto_Product_Record_Check($items, $field_mapping);
					}
				}else{
					$this->Xeroto_Product_Record_Check($inventry_itemlists['Items']['Items'], $field_mapping);
				}
			}
			
			$tmp_vcode = explode(".",$inventry_itemlists['DateTimeUTC']);
			
			return array('success'=>true, 'message' => 'Sync Successfull .', 'datetime'=>$tmp_vcode[0]);
		} catch(Exception $e) {
			$GLOBALS['log']->fatal("clsXero_To_SguarCRM::ProductTemplateItemSave: " . print_r($e->getMessage(),true));
            return array('success'=>false,'message'=>$e->getMessage());
        }
	}
	## END Xero to SugarCRM Sync. Inventry List
	
	## START Product Template - Xero Invetry List Check for Add or Update Record
	public function Xeroto_Product_Record_Check($items, $field_mapping){
		$bean = BeanFactory::getBean('AOS_Products');
		$bean->retrieve_by_string_fields(array('fyn_xero_itemid' => $items['ItemID']));
		if(empty($bean->id))
		{
			$bean->retrieve_by_string_fields(array('name' => $items['Code']));
            ## Item code found means product sync with other same name
            if(!empty($bean->id) && !empty($bean->fyn_xero_itemid)){
                $bean = BeanFactory::getBean('AOS_Products');
            }
		}

		foreach($items as $key=>$item_arr)
		{
			if(is_array($item_arr)){
				foreach($item_arr as $key_ch=>$val_ch)
				{
					$tmp = $field_mapping[$key][$key_ch];
					if(!empty($tmp))
						$bean->$tmp = $val_ch;
				}
			}else{
				$tmp = $field_mapping[$key];
				if(!empty($tmp))
					$bean->$tmp = $item_arr;	
			}
		}
		$bean->save();
	}
	## END Product Template - Xero Invetry List Check for Add or Update Record
	
	## START Xero Contact to SguarCRM Account Module Sync. Account/Contact List
	public function sync_Suite_Account_List($account_all, $no_of_days, $date_used, $modified_date)
	{
		## Webhooks Call OR Mailchmip to SugarCRM Sync
		ClsFYNXero::$webhooks_call = true;

		## Field Mapping Xero Fetched
		$cached_mappings = ClsFYNXero::GetMappingField('Accounts');
		
		## START Account Field Mapping Fetch
		$bean_account = BeanFactory::getBean('Accounts');
		$field_options = ClsFYNXero::get_importable_field($bean_account);
		$field_mapping_account = array();
		foreach($field_options as $value=>$name){
			if($cached_mappings['Accounts'][$value]['mapping']['sugarcrm_name']==$value){
				$key = $cached_mappings['Accounts'][$value]['mapping']['xero_name'];
				if(!empty($cached_mappings['Accounts'][$value]['PhoneType'])){
					$key_main = $cached_mappings['Accounts'][$value]['PhoneType'];
					$field_mapping_account[$key_main][$key] = $value;
				}else if(!empty($cached_mappings['Accounts'][$value]['AddressType'])){
					$key_main = $cached_mappings['Accounts'][$value]['AddressType'];
					$field_mapping_account[$key_main][$key] = $value;
				}else if(!empty($cached_mappings['Accounts'][$value]['BalanceType'])){
					$key_main = $cached_mappings['Accounts'][$value]['BalanceType'];
					$field_mapping_account[$key_main][$key] = $value;
				}else if(!empty($cached_mappings['Accounts'][$value]['BatchType'])){
					$key_main = $cached_mappings['Accounts'][$value]['BatchType'];
					$field_mapping_account[$key_main][$key] = $value;
				}else if(!empty($cached_mappings['Accounts'][$value]['PaymentType'])){
					$key_main = $cached_mappings['Accounts'][$value]['PaymentType'];
					$field_mapping_account[$key_main][$key] = $value;
				}else{
					$field_mapping_account[$key] = $value;
				}
			}else if($cached_mappings['Accounts']['email1']['mapping']['sugarcrm_name']=='email1'){
				$field_mapping_account['EmailAddress'] = 'email1';
			}
		}
		## END Account Field Mapping Fetch
		
		## START CONTACT Field Mapping Fetch
		$bean_contact = BeanFactory::getBean('Contacts');
		$field_options = ClsFYNXero::get_importable_field($bean_contact);
		$field_mapping_contact = array();
		foreach($field_options as $value=>$name){
			if($cached_mappings['Contacts'][$value]['mapping']['sugarcrm_name']==$value){
				$key = $cached_mappings['Contacts'][$value]['mapping']['xero_name'];
				if(!empty($cached_mappings['Contacts'][$value]['PhoneType'])){
					$key_main = $cached_mappings['Contacts'][$value]['PhoneType'];
					$field_mapping_contact[$key_main][$key] = $value;
				}else if(!empty($cached_mappings['Contacts'][$value]['AddressType'])){
					$key_main = $cached_mappings['Contacts'][$value]['AddressType'];
					$field_mapping_contact[$key_main][$key] = $value;
				}else if(!empty($cached_mappings['Contacts'][$value]['BalanceType'])){
					$key_main = $cached_mappings['Contacts'][$value]['BalanceType'];
					$field_mapping_contact[$key_main][$key] = $value;
				}else if(!empty($cached_mappings['Contacts'][$value]['BatchType'])){
					$key_main = $cached_mappings['Contacts'][$value]['BatchType'];
					$field_mapping_contact[$key_main][$key] = $value;
				}else if(!empty($cached_mappings['Contacts'][$value]['PaymentType'])){
					$key_main = $cached_mappings['Contacts'][$value]['PaymentType'];
					$field_mapping_contact[$key_main][$key] = $value;
				}else{
					$field_mapping_contact[$key] = $value;
				}
			}else if($cached_mappings['Contacts']['email1']['mapping']['sugarcrm_name']=='email1'){
				$field_mapping_contact['EmailAddress'] = 'email1';
			}
		}
		## END CONTACT Field Mapping Fetch
		#echo '<pre>';
		#print_r($field_mapping_account);
		#print_r($field_mapping_contact);
		#exit;
		if(empty(ClsFYNXero::$fynGetAPIDetails['fynconsumer_key']))
			ClsFYNXero::getXeroAPIDetails();
		$fynGetAPIDetails = ClsFYNXero::$fynGetAPIDetails;
		try {
			$xero = new Xero($fynGetAPIDetails['fynconsumer_key'], $fynGetAPIDetails['fynconsumer_secret'], $fynGetAPIDetails['fynpublic_key'], $fynGetAPIDetails['fynprivate_key'], 'json' );
		
			if($account_all=='Y'){
				$account_lists = $xero->Contacts;
			}else{
				if($date_used=='Y'){
					$m_date = $modified_date;
				}else{
					if(!is_numeric($no_of_days))
						$no_of_days = 1;
					$m_date = date('Y-m-d', strtotime("-".$no_of_days." days"));
				}
				$account_lists = $xero->Contacts(false, $m_date, array());
			}
			#echo '<pre>';
			#print_r($account_lists);
			#exit;
			if(count($account_lists['Contacts']['Contact'])>0)
			{
				if(count($account_lists['Contacts']['Contact'][0])>1)
				{
					foreach($account_lists['Contacts']['Contact'] as $items)
					{
						$tmp_lists = $xero->Contacts($items['ContactID']);
						#print_r($tmp_lists['Contacts']['Contact']);exit;
						$this->Xeroto_Account_Record_Check($tmp_lists['Contacts']['Contact'], $field_mapping_account, $field_mapping_contact);
					}
				}else{
					$tmp_lists = $xero->Contacts($account_lists['Contacts']['Contact']['ContactID']);
					#print_r($tmp_lists['Contacts']['Contact']);exit;
					$this->Xeroto_Account_Record_Check($tmp_lists['Contacts']['Contact'], $field_mapping_account, $field_mapping_contact);
				}
			}
			$tmp_vcode = explode(".",$account_lists['DateTimeUTC']);
			return array('success'=>true, 'message' => 'Sync Successful.', 'datetime'=>$tmp_vcode[0]);
		} catch(Exception $e) {
			$GLOBALS['log']->fatal("clsXero_To_SguarCRM::ProductTemplateItemSave: " . print_r($e->getMessage(),true));
            return array('success'=>false,'message'=>$e->getMessage());
        }
	}
	## END Xero Contact to SguarCRM Account Module Sync. Account/Contact List
	
	## START Product Template - Xero Invetry List Check for Add or Update Record
	public function Xeroto_Account_Record_Check($items, $field_mapping_account, $field_mapping_contact){
		#echo '<pre>';
		#print_r($items);
		#exit;
		
		$bean_account = BeanFactory::getBean('Accounts');
		$bean_account->retrieve_by_string_fields(array('fyn_xero_contactid' => $items['ContactID']));
		if(empty($bean_account->id))
		{
			$bean_account->retrieve_by_string_fields(array('name' => $items['Name']));
		}
		foreach($items as $key=>$item_arr)
		{
			if(is_array($item_arr)){
				if($key=='Phones')
				{
					foreach($item_arr['Phone'] as $key_ch=>$Phone_arr)
					{
						#print_r($Phone_arr);
						#echo $Phone_arr['PhoneType'];
						if(is_array($field_mapping_account[$Phone_arr['PhoneType']]))
						{
						#print_r($field_mapping_account[$Phone_arr['PhoneType']]);
							foreach($field_mapping_account[$Phone_arr['PhoneType']] as $map_phone_key=>$map_phone_val)
							{
								$tmp = $Phone_arr[$map_phone_key];
								if(!empty($tmp))
									$bean_account->$map_phone_val = $tmp;
							}
						}
					}
				}else if($key=='Addresses'){
				
					foreach($item_arr['Address'] as $key_ch=>$Add_arr)
					{
						#print_r($Add_arr);
						#echo $Add_arr['AddressType'];
						if(is_array($field_mapping_account[$Add_arr['AddressType']]))
						{
						#print_r($field_mapping_account[$Add_arr['AddressType']]);
							foreach($field_mapping_account[$Add_arr['AddressType']] as $map_add_key=>$map_add_val)
							{
								if($map_add_key=='AddressLine1'){
									$addi = 1; $tmp = '';
									do{
										if(empty($Add_arr['AddressLine'.$addi]))
											$addi = 100;
										else{
											if($addi>1)
												$tmp .= chr(13);
											$tmp .= $Add_arr['AddressLine'.$addi];
										}
										$addi++;
									}while($addi < 100);
								}else{
									$tmp = $Add_arr[$map_add_key];
								}
								if(!empty($tmp))
									$bean_account->$map_add_val = $tmp;
							}
						}
					}
				}else if($key=='Balances'){
					foreach($item_arr as $rec_key=>$receivable_arr)
					{
						#print_r($item_arr[$rec_key]);
						#echo $Phone_arr['PhoneType'];
						if(is_array($field_mapping_account[$rec_key]))
						{
							#print_r($field_mapping_account[$rec_key]);
							foreach($field_mapping_account[$rec_key] as $map_rec_key=>$map_rec_val)
							{
								$tmp = $receivable_arr[$map_rec_key];
								if(!empty($tmp))
									$bean_account->$map_rec_val = $tmp;
							}
						}
					}
				}else if($key=='BatchPayments'){
					if(is_array($field_mapping_account[$key]))
					{
						foreach($field_mapping_account[$key] as $map_rec_key=>$map_rec_val)
						{
							$tmp = $item_arr[$map_rec_key];
							if(!empty($tmp))
								$bean_account->$map_rec_val = $tmp;
						}
					}
				}else if($key=='PaymentTerms'){
					foreach($item_arr as $rec_key=>$receivable_arr)
					{
						#print_r($item_arr[$rec_key]);
						#echo $Phone_arr['PhoneType'];
						if(is_array($field_mapping_account[$rec_key]))
						{
							#print_r($field_mapping_account[$rec_key]);
							foreach($field_mapping_account[$rec_key] as $map_rec_key=>$map_rec_val)
							{
								$tmp = $receivable_arr[$map_rec_key];
								if(!empty($tmp))
									$bean_account->$map_rec_val = $tmp;
							}
						}
					}
				}
			}else{
				$tmp = $field_mapping_account[$key];
				if(!empty($tmp))
					$bean_account->$tmp = $item_arr;	
			}
		}
		//print_r($bean_account);
		//exit;
		$bean_account->save();
		//echo $bean_account->primary_contact_id;
		//exit;
		$bean_contact = BeanFactory::getBean('Contacts', $bean_account->primary_contact_id);
		/*
		echo "string";
				print_r($items);
				exit;*/

		foreach($items as $key=>$item_arr)
		{
			
			if(is_array($item_arr)){
				if($key=='Phones')
				{
					foreach($item_arr['Phone'] as $key_ch=>$Phone_arr)
					{
						#print_r($Phone_arr);
						#echo $Phone_arr['PhoneType'];
						if(is_array($field_mapping_contact[$Phone_arr['PhoneType']]))
						{
						#print_r($field_mapping_account[$Phone_arr['PhoneType']]);
							foreach($field_mapping_contact[$Phone_arr['PhoneType']] as $map_phone_key=>$map_phone_val)
							{
								$tmp = $Phone_arr[$map_phone_key];
								if(!empty($tmp))
									$bean_contact->$map_phone_val = $tmp;
							}
						}
					}
				}else if($key=='Addresses'){
				
					foreach($item_arr['Address'] as $key_ch=>$Add_arr)
					{
						if(is_array($field_mapping_contact[$Add_arr['AddressType']]))
						{
							foreach($field_mapping_contact[$Add_arr['AddressType']] as $map_add_key=>$map_add_val)
							{
								if($map_add_key=='AddressLine1'){
									$addi = 1; $tmp = '';
									do{
										if(empty($Add_arr['AddressLine'.$addi]))
											$addi = 100;
										else{
											if($addi>1)
												$tmp .= '\n';
											$tmp .= $Add_arr['AddressLine'.$addi];
										}
										$addi++;
									}while($addi < 100);
								}else{
									$tmp = $Add_arr[$map_add_key];
								}
								if(!empty($tmp))
									$bean_contact->$map_add_val = $tmp;
							}
						}
					}
				}else if($key=='Balances'){
						foreach($item_arr as $rec_key=>$receivable_arr)
						{
							#print_r($item_arr[$rec_key]);
							#echo $Phone_arr['PhoneType'];
							if(is_array($field_mapping_contact[$rec_key]))
							{
								#print_r($field_mapping_contact[$rec_key]);
								foreach($field_mapping_contact[$rec_key] as $map_rec_key=>$map_rec_val)
								{
									$tmp = $receivable_arr[$map_rec_key];
									if(!empty($tmp))
										$bean_contact->$map_rec_val = $tmp;
								}
							}
						}
					}else if($key=='BatchPayments'){
					if(is_array($field_mapping_contact[$key]))
					{
						foreach($field_mapping_contact[$key] as $map_rec_key=>$map_rec_val)
						{
							$tmp = $item_arr[$map_rec_key];
							if(!empty($tmp))
								$bean_contact->$map_rec_val = $tmp;
						}
					}
				}else if($key=='PaymentTerms'){
					foreach($item_arr as $rec_key=>$receivable_arr)
					{
						#print_r($item_arr[$rec_key]);
						#echo $Phone_arr['PhoneType'];
						if(is_array($field_mapping_contact[$rec_key]))
						{
							#print_r($field_mapping_account[$rec_key]);
							foreach($field_mapping_contact[$rec_key] as $map_rec_key=>$map_rec_val)
							{
								$tmp = $receivable_arr[$map_rec_key];
								if(!empty($tmp))
									$bean_contact->$map_rec_val = $tmp;
							}
						}
					}
				}
			}else{
				$tmp = $field_mapping_contact[$key];
				if(!empty($tmp))
					$bean_contact->$tmp = $item_arr;
			}
		}
		 
		$bean_contact->save();
		
		if(empty($bean_account->primary_contact_id)){
			$bean_account->primary_contact_id = $bean_contact->id;
			$bean_account->save();
		}
	}
	## END Product Template - Xero Invetry List Check for Add or Update Record
	
	## START Xero Contact to SguarCRM Account Module Sync. Account/Contact List IF Quote Not Available Account Create
    public function synSugarQuoteAccount($ContactID, $xero)
    {
        ## Webhooks Call OR Mailchmip to SugarCRM Sync
        ClsFYNXero::$webhooks_call = true;

        ## Field Mapping Xero Fetched
        $cached_mappings = ClsFYNXero::GetMappingField('Accounts');
        
        ## START Account Field Mapping Fetch
        $bean_account = BeanFactory::getBean('Accounts');
        $field_options = ClsFYNXero::get_importable_field($bean_account);
        $field_mapping_account = array();
        foreach($field_options as $value=>$name){
            if($cached_mappings['Accounts'][$value]['mapping']['sugarcrm_name']==$value){
                $key = $cached_mappings['Accounts'][$value]['mapping']['xero_name'];
                if(!empty($cached_mappings['Accounts'][$value]['PhoneType'])){
                    $key_main = $cached_mappings['Accounts'][$value]['PhoneType'];
                    $field_mapping_account[$key_main][$key] = $value;
                }else if(!empty($cached_mappings['Accounts'][$value]['AddressType'])){
                    $key_main = $cached_mappings['Accounts'][$value]['AddressType'];
                    $field_mapping_account[$key_main][$key] = $value;
                }else if(!empty($cached_mappings['Accounts'][$value]['BalanceType'])){
                    $key_main = $cached_mappings['Accounts'][$value]['BalanceType'];
                    $field_mapping_account[$key_main][$key] = $value;
                }else if(!empty($cached_mappings['Accounts'][$value]['BatchType'])){
                    $key_main = $cached_mappings['Accounts'][$value]['BatchType'];
                    $field_mapping_account[$key_main][$key] = $value;
                }else if(!empty($cached_mappings['Accounts'][$value]['PaymentType'])){
                    $key_main = $cached_mappings['Accounts'][$value]['PaymentType'];
                    $field_mapping_account[$key_main][$key] = $value;
                }else{
                    $field_mapping_account[$key] = $value;
                }
            }else if($cached_mappings['Accounts']['email1']['mapping']['sugarcrm_name']=='email1'){
                $field_mapping_account['EmailAddress'] = 'email1';
            }
        }
        ## END Account Field Mapping Fetch
        
        ## START CONTACT Field Mapping Fetch
        $bean_contact = BeanFactory::getBean('Contacts');
        $field_options = ClsFYNXero::get_importable_field($bean_contact);
        $field_mapping_contact = array();
        foreach($field_options as $value=>$name){
            if($cached_mappings['Contacts'][$value]['mapping']['sugarcrm_name']==$value){
                $key = $cached_mappings['Contacts'][$value]['mapping']['xero_name'];
                if(!empty($cached_mappings['Contacts'][$value]['PhoneType'])){
                    $key_main = $cached_mappings['Contacts'][$value]['PhoneType'];
                    $field_mapping_contact[$key_main][$key] = $value;
                }else if(!empty($cached_mappings['Contacts'][$value]['AddressType'])){
                    $key_main = $cached_mappings['Contacts'][$value]['AddressType'];
                    $field_mapping_contact[$key_main][$key] = $value;
                }else if(!empty($cached_mappings['Contacts'][$value]['BalanceType'])){
                    $key_main = $cached_mappings['Contacts'][$value]['BalanceType'];
                    $field_mapping_contact[$key_main][$key] = $value;
                }else if(!empty($cached_mappings['Contacts'][$value]['BatchType'])){
                    $key_main = $cached_mappings['Contacts'][$value]['BatchType'];
                    $field_mapping_contact[$key_main][$key] = $value;
                }else if(!empty($cached_mappings['Contacts'][$value]['PaymentType'])){
                    $key_main = $cached_mappings['Contacts'][$value]['PaymentType'];
                    $field_mapping_contact[$key_main][$key] = $value;
                }else{
                    $field_mapping_contact[$key] = $value;
                }
            }else if($cached_mappings['Contacts']['email1']['mapping']['sugarcrm_name']=='email1'){
                $field_mapping_contact['EmailAddress'] = 'email1';
            }
        }
        ## END CONTACT Field Mapping Fetch
        #echo '<pre>';
        #print_r($field_mapping_account);
        #print_r($field_mapping_contact);
        #exit;
        $tmp_lists = $xero->Contacts($ContactID);
        #print_r($tmp_lists['Contacts']['Contact']);exit;
        $this->Xeroto_Account_Record_Check($tmp_lists['Contacts']['Contact'], $field_mapping_account, $field_mapping_contact);
    }
    ## END Xero Contact to SguarCRM Account Module Sync. Account/Contact List IF Quote Not Available Account Create
	
	## START Xero Invoice to SguarCRM Quote Module Sync. 
	public function sync_CRM_Quote_List($invoice_all, $no_of_days, $date_used, $modified_date)
	{
		## Webhooks Call OR Mailchmip to SugarCRM Sync
		ClsFYNXero::$webhooks_call = true;

		## Field Mapping Xero Fetched
		$cached_mappings = ClsFYNXero::GetMappingField('AOS_Quotes');
		
		## START Quotes Field Mapping Fetch
		$bean_quote = BeanFactory::getBean('AOS_Quotes');
		$field_options = ClsFYNXero::get_importable_field($bean_quote);
		$field_mapping_quote = array();
		foreach($field_options as $value=>$name){
			if($cached_mappings['AOS_Quotes'][$value]['mapping']['sugarcrm_name']==$value){
				$key = $cached_mappings['AOS_Quotes'][$value]['mapping']['xero_name'];
				$field_mapping_quote[$key] = $value;
			}
		}
		## END Quotes Field Mapping Fetch
        	
		## START Lineitems Field Mapping Fetch
		$bean_product = BeanFactory::getBean('AOS_Products_Quotes');
		$field_options = ClsFYNXero::get_importable_field($bean_product);
		$field_mapping_lineitem = array();
		foreach($field_options as $value=>$name){
			if($cached_mappings['AOS_Products_Quotes'][$value]['mapping']['sugarcrm_name']==$value){
				$key = $cached_mappings['AOS_Products_Quotes'][$value]['mapping']['xero_name'];
				$field_mapping_lineitem[$key] = $value;
			}
		}
		## END Lineitems Field Mapping Fetch

		if(empty(ClsFYNXero::$fynGetAPIDetails['fynconsumer_key']))
			ClsFYNXero::getXeroAPIDetails();
		$fynGetAPIDetails = ClsFYNXero::$fynGetAPIDetails;
		try {
			$xero = new Xero($fynGetAPIDetails['fynconsumer_key'], $fynGetAPIDetails['fynconsumer_secret'], $fynGetAPIDetails['fynpublic_key'], $fynGetAPIDetails['fynprivate_key'], 'json' );
		
			## START Invoice List Fetch Datewise or ALL
			if($invoice_all=='Y'){
				$invoice_lists = $xero->Invoices;
			}else{
				if($date_used=='Y'){
					$m_date = $modified_date;
				}else{
					if(!is_numeric($no_of_days))
						$no_of_days = 1;
					$m_date = date('Y-m-d', strtotime("-".$no_of_days." days"));
				}
				$invoice_lists = $xero->Invoices(false, $m_date, array());
			}
			## END Invoice List Fetch Datewise or ALL
			
			#echo '<pre>';
			#print_r($invoice_lists);
			#exit;
			if(count($invoice_lists['Invoices']['Invoice'])>0)
			{
				if(count($invoice_lists['Invoices']['Invoice'][0])>1)
				{
					foreach($invoice_lists['Invoices']['Invoice'] as $items)
					{
						$tmp_lists = $xero->Invoices($items['InvoiceID']);
						$this->Xeroto_Quote_Record_Check($tmp_lists['Invoices']['Invoice'], $field_mapping_quote, $field_mapping_lineitem, $xero);
					}
				}else{
					$tmp_lists = $xero->Invoices($invoice_lists['Invoices']['Invoice']['InvoiceID']);
					$this->Xeroto_Quote_Record_Check($tmp_lists['Invoices']['Invoice'], $field_mapping_quote, $field_mapping_lineitem, $xero);
				}
			}
			$tmp_vcode = explode(".",$invoice_lists['DateTimeUTC']);
			return array('success'=>true, 'message' => 'Sync Successful.', 'datetime'=>$tmp_vcode[0]);
		} catch(Exception $e) {
			$GLOBALS['log']->fatal("clsXero_To_SguarCRM::ProductTemplateItemSave: " . print_r($e->getMessage(),true));
            return array('success'=>false,'message'=>$e->getMessage());
        }
	}
	## END Xero Invoice to SguarCRM Quote Module Sync. 
	
	## START Sugar Quotes - Xero Invoice List Check for Add or Update Record
	public function Xeroto_Quote_Record_Check($items, $field_mapping_quote, $field_mapping_lineitem, $xero){
		global $db;    
		#echo '<pre>';
		#print_r($items);
		#exit;
		
		$ContactID = $items['Contact']['ContactID'];
		$bean_account = BeanFactory::getBean('Accounts');
		$bean_account->retrieve_by_string_fields(array('fyn_xero_contactid' => $ContactID));
        if(empty($bean_account->id)){
			$this->synSugarQuoteAccount($ContactID, $xero);
		}
		
		$bean_quote = BeanFactory::getBean('AOS_Quotes');
		$bean_quote->retrieve_by_string_fields(array('fyn_xero_invoiceid' => $items['InvoiceID']));
		$avil_date = array('Date', 'DueDate', 'ExpectedPaymentDate', 'PlannedPaymentDate', 'FullyPaidOnDate');
		#print_r($field_mapping_quote);
		foreach($items as $key=>$item_arr)
		{
			if(is_array($item_arr)){
			
			}else{
				if(in_array($key, $avil_date)){
					$payment_dt = explode('T', $item_arr);
					$tmp = $field_mapping_quote[$key];
					if(!empty($tmp))
						$bean_quote->$tmp = $payment_dt[0];
				}else if($key=='SubTotal'){
					$bean_quote->subtotal_amount = $item_arr;
					$bean_quote->total_amt = $item_arr - $items['TotalDiscount'];
				}else if($key=='CurrencyCode'){
                    $bean_quote->fyn_xero_currencycode = $item_arr;
                    require_once('modules/Currencies/ListCurrency.php');
                    $currency = new ListCurrency();
                    $currency->lookupCurrencies();
                    foreach($currency->list as $currencyList)
                    {
                        if($currencyList->iso4217 == $item_arr)
                            $bean_quote->currency_id = $currencyList->id;   
                    }
                }else{
    				$tmp = $field_mapping_quote[$key];
    				if(!empty($tmp))
    					$bean_quote->$tmp = $item_arr;
    				if($key=="InvoiceNumber")	
    				{
    					$bean_quote->name = "Invoice ".$item_arr;	
    					$invno=$item_arr;	
    				}
				}
			}
		}
		if($invno=="")
		$invno="";
	    $bean_quote->name=$bean_account->name." - ".$invno;
		$bean_quote->billing_account_name = $bean_account->name;
		$bean_quote->billing_account_id = $bean_account->id;
		$bean_contact = BeanFactory::getBean('Contacts', $bean_account->primary_contact_id);
		$bean_quote->billing_contact_id = $bean_contact->id;
		$bean_quote->billing_contact_name = $bean_contact->name;
		#print_r($bean_quote);
		#exit;
		$bean_quote->save();
		#exit;
		$sql = "SELECT pg.id, pg.group_id FROM aos_products_quotes pg LEFT JOIN aos_line_item_groups lig ON pg.group_id = lig.id WHERE pg.parent_type = '".$bean_quote->object_name."' AND pg.parent_id = '".$bean_quote->id."' AND pg.deleted = 0 ORDER BY lig.number ASC, pg.number ASC";
        $results = $db->query($sql);
        $num_row = $db->getRowCount($results);
		if($num_row > 0 ){
		    $row = $db->fetchByAssoc($results);
			$pb = BeanFactory::getBean('AOS_Line_Item_Groups');
            $pb->retrieve($row['group_id']);
			$pb->total_amt = $items['SubTotal'];
            $pb->discount_amount =  $items['TotalDiscount'];
            $pb->subtotal_amount = $items['SubTotal'] + $items['TotalDiscount'];
            $pb->tax_amount = $items['TotalTax'];
            $pb->total_amount = $items['Total'];
			$pb->save();
		}else{
			$pb = BeanFactory::getBean('AOS_Line_Item_Groups');
			$pb->name = 'Group';
            $pb->total_amt = $items['SubTotal'];
            $pb->discount_amount =  $items['TotalDiscount'];
			$pb->subtotal_amount = $items['SubTotal'] + $items['TotalDiscount'];
			$pb->tax_amount = $items['TotalTax'];
			$pb->total_amount = $items['Total'];
			$pb->parent_id = $bean_quote->id;
            $pb->currency_id = $bean_quote->currency_id;
            $pb->parent_type = $bean_quote->object_name;
			$pb->save();
		}	
		
        $qry_del = "DELETE FROM aos_products_quotes WHERE parent_type = '".$bean_quote->object_name."' AND parent_id = '".$bean_quote->id."'";
        $db->query($qry_del);
		
		
		## START Quote Line Item Add
		if(is_array($items['LineItems']['LineItem']) && count($items['LineItems']['LineItem'])>0)
		{
			if(count($items['LineItems']['LineItem'][0])>1)
			{
				$parent_gr_pos = 1;
				foreach($items['LineItems']['LineItem'] as $key=>$item_arr)
				{
					#print_r($item_arr);#exit;
					$bean_product = BeanFactory::getBean('AOS_Products_Quotes');
					foreach($item_arr as $key_ch=>$item_arr_ch)
					{
						if($key_ch=='ItemCode')
						{
							$bean_inventry = BeanFactory::getBean('AOS_Products');
							$bean_inventry->retrieve_by_string_fields(array('name' => $item_arr_ch));
							$bean_product->product_id = $bean_inventry->id;
							$bean_product->name = $bean_inventry->name;
                            if($item_arr['DiscountRate'] > 0){
                                $product_discount_amount = ($item_arr['DiscountRate'] * $item_arr['UnitAmount'] * $item_arr['Quantity']) / 100;
                                $bean_product->product_unit_price = $item_arr['UnitAmount'] + $product_discount_amount;
                            } else { 
                                $bean_product->product_unit_price = $item_arr['UnitAmount'];
                            }
						}else{
							$tmp = $field_mapping_lineitem[$key_ch];
							if(!empty($tmp))
								$bean_product->$tmp = $item_arr_ch;	
							if($key_ch == 'DiscountRate'){
								$bean_product->product_discount = $item_arr_ch;
								$product_discount_amount = ($item_arr_ch * $item_arr['UnitAmount'] * $item_arr['Quantity']) / 100;
								$bean_product->product_discount_amount = $product_discount_amount;
							}
						}
					}
					if(empty($bean_product->name))
						$bean_product->name = 'No Product Catalogue';
					
					$bean_product->parent_id = $bean_quote->id;
                    $bean_product->parent_type = $bean_quote->object_name;
					$bean_product->group_id = $pb->id;
                    $bean_product->number = $parent_gr_pos;
					$bean_product->save();
					#$pb->set_productbundle_product_relationship($bean_product->id,$parent_gr_pos, $pb->id);			
					$parent_gr_pos++;
				}
			}else{
				$bean_product = BeanFactory::getBean('AOS_Products_Quotes');
				foreach($items['LineItems']['LineItem'] as $key_ch=>$item_arr_ch)
				{
					if($key_ch=='ItemCode')
					{
						$bean_inventry = BeanFactory::getBean('AOS_Products');
						$bean_inventry->retrieve_by_string_fields(array('name' => $item_arr_ch));
						$bean_product->product_id = $bean_inventry->id;
						$bean_product->name = $bean_inventry->name;
                        if($item_arr['DiscountRate'] > 0){
                            $product_discount_amount = ($item_arr['DiscountRate'] * $item_arr['UnitAmount'] * $item_arr['Quantity']) / 100;
                            $bean_product->product_unit_price = $item_arr['UnitAmount'] + $product_discount_amount;
                        } else { 
                            $bean_product->product_unit_price = $item_arr['UnitAmount'];
                        }
					}else{
						$tmp = $field_mapping_lineitem[$key_ch];
						if(!empty($tmp))
							$bean_product->$tmp = $item_arr_ch;
                        if($key_ch == 'DiscountRate'){
                            $bean_product->product_discount = $item_arr_ch;
                            $product_discount_amount = ($item_arr_ch * $item_arr['UnitAmount'] * $item_arr['Quantity']) / 100;
                            $bean_product->product_discount_amount = $product_discount_amount;
                        }	
					}
				}
				$bean_product->parent_id = $bean_quote->id;
                $bean_product->parent_type = $bean_quote->object_name;
                $bean_product->group_id = $pb->id;
                $bean_product->number = $parent_gr_pos;
				$bean_product->save();
				#$pb->set_productbundle_product_relationship($bean_product->id, 0, $pb->id);			
			}
		}
		## END Quote Line Item Add
		#exit;
		## Clear All Old Relationship & record Pemently Deleted
		$bean_payment = BeanFactory::getBean('FYN_Xeropayment');
		$bean_payment->clear_xero_payment_quote_relationship($bean_quote->id);
		
		## START Quote Payment Add
		if(count($items['Payments']['Payment'])>0)
		{
			if(count($items['Payments']['Payment'][0])>1)
			{
				foreach($items['Payments']['Payment'] as $pay_items)
				{
					$tmp_lists = $xero->Payments($pay_items['PaymentID']);
					$this->Xeroto_Quote_Payment($tmp_lists['Payments']['Payment'], $bean_quote);
				}
			}else{
				$tmp_lists = $xero->Payments($items['Payments']['Payment']['PaymentID']);
				$this->Xeroto_Quote_Payment($tmp_lists['Payments']['Payment'], $bean_quote);
			}
		}
		## END Quote Payment Add
		
		## Clear All Old Relationship & record Pemently Deleted
		$bean_credit = BeanFactory::getBean('FYN_XeroCreditNote');
		$bean_credit->clear_xero_creditnote_quote_relationship($bean_quote->id);
		
		## START Quote Credit Note Add
		if(count($items['CreditNotes']['CreditNote'])>0)
		{
			if(count($items['CreditNotes']['CreditNote'][0])>1)
			{
				$credit_note_arr = array();
				foreach($items['CreditNotes']['CreditNote'] as $pay_items)
				{
					if(!in_array($pay_items['CreditNoteID'], $credit_note_arr))
					{
					$credit_note_arr[] = $pay_items['CreditNoteID'];
					$tmp_lists = $xero->CreditNotes($pay_items['CreditNoteID']);
					
					#print_r($tmp_lists);#exit;
					$this->Xeroto_Quote_Credit_Notes($tmp_lists['CreditNotes']['CreditNote'], $bean_quote);
					}
				}
			}else{
				$tmp_lists = $xero->CreditNotes($items['CreditNotes']['CreditNote']['CreditNoteID']);
				#print_r($tmp_lists);exit;
				$this->Xeroto_Quote_Credit_Notes($tmp_lists['CreditNotes']['CreditNote'], $bean_quote);
			}
		}
		## END Quote Credit Note Add
		
		#print_r($bean_contact);
		#exit;
	}
	## END Sugar Quotes - Xero Invoice List Check for Add or Update Record
	
	## START Sugar Quote Payment Subpanle - Xero Invoice Payment List
	public function Xeroto_Quote_Payment($items, $bean_quote){
		#echo '<pre>';
		#print_r($items);exit;
		$payment_dt = explode('T', $items['Date']);
		$bean_payment = BeanFactory::getBean('FYN_Xeropayment');
		$bean_payment->retrieve_by_string_fields(array('xero_paymentid' => $items['PaymentID']));
		$bean_payment->xero_paymentid = $items['PaymentID'];
		$bean_payment->name = $items['Amount'];
		$bean_payment->xero_paymentdate = $payment_dt[0];
		$bean_payment->xero_paid_to = $items['Account']['AccountID'];
		$bean_payment->xero_amount = $items['Amount'];
		$bean_payment->xero_reference = $items['Reference'];
		$bean_payment->xero_currencyrate = $items['CurrencyRate'];
		$bean_payment->xero_currencycode = $items['CurrencyCode'];
		$bean_payment->xero_paymenttype = $items['PaymentType'];
		$bean_payment->xero_status = $items['Status'];
		$bean_payment->xero_isreconciled = $items['IsReconciled'];
		$bean_payment->save();
		
		// $bean_quote->load_relationship('fyn_xeropayment');
		// $bean_quote->fyn_xeropayment->add($bean_payment->id);

		global $db;

		 $sql="select * from fyn_xeropayment_aos_quotes_c
 where fyn_xeropayment_aos_quotesfyn_xeropayment_idb = '".$bean_payment->id."' and fyn_xeropayment_aos_quotesaos_quotes_ida='".$bean_quote->id."' and deleted='0' ";
         $res=$db->query($sql); 

    if($res->num_rows >0)
    {
    	// do nothing
    }
      
    else
    {
       $sql2="select * from fyn_xeropayment_aos_quotes_c where fyn_xeropayment_aos_quotesfyn_xeropayment_idb = '".$bean_payment->id."' and deleted=0 ";
       $res2=$db->query($sql2);

       if($res2->num_rows > 0)
       {
       		$row2=$res2->fetch_assoc();
            
            $sql3="update fyn_xeropayment_aos_quotes_c set deleted=1 where id='".$row2['id']."' ";
            $db->query($sql3);

            $sql4="Insert into fyn_xeropayment_aos_quotes_c values(UUID(),NOW(),0,'".$bean_quote->id."', '".$bean_payment->id."') ";
            $db->query($sql4);
       }

       else
       {
       	 $sql4="Insert into fyn_xeropayment_aos_quotes_c values(UUID(),NOW(),0,'".$bean_quote->id."', '".$bean_payment->id."') ";
            $db->query($sql4);
       }

   }



	}
	## END Sugar Quote Payment Subpanle - Xero Invoice Payment List
	
	## START Sugar Quote Credit Note Subpanle - Xero Invoice Credit Note List
	public function Xeroto_Quote_Credit_Notes($items, $bean_quote){
		#echo '<pre>';
		#print_r($items);
		#return;
		#exit;
		$payment_dt = explode('T', $items['Date']);
		$bean_credit = BeanFactory::getBean('FYN_XeroCreditNote');
		$bean_credit->retrieve_by_string_fields(array('xero_creditnoteid' => $items['CreditNoteID']));
		$bean_credit->xero_creditnoteid = $items['CreditNoteID'];
		$bean_credit->xero_creditnotesdate = $payment_dt[0];
		$bean_credit->xero_creditnotenumber = $items['CreditNoteNumber'];
		$bean_credit->xero_status = $items['Status'];
		$bean_credit->xero_credittype = $items['Type'];
		$bean_credit->xero_lineamounttypes = $items['LineAmountTypes'];
		$bean_credit->xero_reference = $items['Reference'];
		$bean_credit->xero_currencyrate = $items['CurrencyRate'];
		$bean_credit->xero_currencycode = $items['CurrencyCode'];
		$AppliedAmount = 0;
		if(count($items['Allocations']['Allocation'])>0)
		{
			if(count($items['Allocations']['Allocation'][0])>1)
			{
				$applied_amount_arr = array();
				foreach($items['Allocations']['Allocation'] as $pay_items)
				{
					#if(!in_array($pay_items['Invoice']['InvoiceID'], $applied_amount_arr) && $pay_items['Invoice']['InvoiceID']==$bean_quote->fyn_xero_invoiceid)
					{
						$AppliedAmount += $pay_items['AppliedAmount'];
					}
				}
			}else{
				$AppliedAmount = $items['Allocations']['Allocation']['AppliedAmount'];
			}
		}
		$bean_credit->name = $AppliedAmount;
		$bean_credit->xero_appliedamount = $AppliedAmount;
		$bean_credit->save();
		
		// $bean_quote->load_relationship('fyn_xerocreditnote');
		// $bean_quote->fyn_xerocreditnote->add($bean_credit->id);

		global $db;

		 $sql="select * from fyn_xerocreditnote_aos_quotes_c where fyn_xerocreditnote_aos_quotesfyn_xerocreditnote_idb = '".$bean_credit->id."' and fyn_xerocreditnote_aos_quotesaos_quotes_ida='".$bean_quote->id."' and deleted='0' ";
         $res=$db->query($sql); 

    if($res->num_rows >0)
    {
    	// do nothing
    }
      
    else
    {
       $sql2="select * from fyn_xerocreditnote_aos_quotes_c where fyn_xerocreditnote_aos_quotesfyn_xerocreditnote_idb = '".$bean_credit->id."' and deleted=0 ";
       $res2=$db->query($sql2);

       if($res2->num_rows > 0)
       {
       		$row2=$res2->fetch_assoc();
            
            $sql3="update fyn_xerocreditnote_aos_quotes_c set deleted=1 where id='".$row2['id']."' ";
            $db->query($sql3);

            $sql4="Insert into fyn_xerocreditnote_aos_quotes_c values(UUID(),NOW(),0,'".$bean_quote->id."', '".$bean_credit->id."') ";
            $db->query($sql4);
       }

       else
       {
       	 $sql4="Insert into fyn_xerocreditnote_aos_quotes_c values(UUID(),NOW(),0,'".$bean_quote->id."', '".$bean_credit->id."') ";
            $db->query($sql4);
       }


    } // end else



	}
	## END Sugar Quote Credit Note Subpanle - Xero Invoice Credit Note List
}