<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once 'modules/FYN_Xero/Classes/xero.php';
 
class ClsFYNXero
{
	public static $fynGetAPIDetails = array();
	
    ## supported Module for Google Apps
    public static $fyn_appssync_user = array('xero_contact_sync' => 1, 'xero_to_sugar_contact' => 1, 'sugar_to_xero_contact' => 1, 'xero_inventory_sync' => 1, 'xero_to_sugar_inventory' => 1, 'sugar_to_xero_inventory' => 1, 'xero_invoice_sync' => 1, 'xero_to_sugar_invoice' => 1, 'sugar_to_xero_invoice' => 1);
    
    public static $FYNGoogleAPIDetails = array();
    public static $FYNLicenseAPIDetails = array();
    
	## Default field Mapping XERO
	public static $default_mappings = array(
        'Accounts' => array(
            "Accounts" => array(
                "fyn_xero_contactid" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_contactid",
                        "xero_name" => "ContactID", // unchanged Field
						"no_field_mapping" => true,
                    ),
					"readonly" => true,
                ),
				"fyn_xero_accountnumber" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_accountnumber",
                        "xero_name" => "AccountNumber",
						"xero_label" => "Account Number",
                    ),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
                ),
				"fyn_xero_contactstatus" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_contactstatus",
                        "xero_name" => "ContactStatus", // unchanged Field
						"no_field_mapping" => true,
                    ),
					"readonly" => true,
					"data_type" => 'Dropdown',
					"SyncAPI" => true,
                ),
				"name" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "name",
                        "xero_name" => "Name",
						"xero_label" => "Contact",
                    ),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
                ),
				"fyn_xero_skype" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_skype",
                        "xero_name" => "SkypeUserName",
						"xero_label" => "Skype Name/Number",
                    ),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
                ),
				"fyn_xero_taxnumber" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_taxnumber",
                        "xero_name" => "TaxNumber",
						"xero_label" => "Tax ID Number",
                    ),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
                ),
				"fyn_xero_salestax" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_salestax",
                        "xero_name" => "AccountsReceivableTaxType",
						"xero_label" => "Sales Tax",
                    ),
					"data_type" => 'Dropdown',
					"SyncAPI" => true,
                ),
				"fyn_xero_purtax" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_purtax",
                        "xero_name" => "AccountsPayableTaxType",
						"xero_label" => "Purchases Tax",
                    ),
					"data_type" => 'Dropdown',
					"SyncAPI" => true,
                ),
				"fyn_xero_poattention" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_poattention",
						"xero_name" => "AttentionTo",
						"xero_label" => "Attention",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"billing_address_street" => array(
					"mapping" => array(
						"sugarcrm_name" => "billing_address_street",
						"xero_name" => "AddressLine1",
						"xero_label" => "Street Address or PO Box",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"billing_address_city" => array(
					"mapping" => array(
						"sugarcrm_name" => "billing_address_city",
						"xero_name" => "City",
						"xero_label" => "Town / City",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"billing_address_state" => array(
					"mapping" => array(
						"sugarcrm_name" => "billing_address_state",
						"xero_name" => "Region",
						"xero_label" => "State / Region",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"billing_address_postalcode" => array(
					"mapping" => array(
						"sugarcrm_name" => "billing_address_postalcode",
						"xero_name" => "PostalCode",
						"xero_label" => "Postal / Zip Code",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"billing_address_country" => array(
					"mapping" => array(
						"sugarcrm_name" => "billing_address_country",
						"xero_name" => "Country",
						"xero_label" => "Country",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"fyn_xero_streetattention" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_streetattention",
						"xero_name" => "AttentionTo",
						"xero_label" => "Attention",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"shipping_address_street" => array(
					"mapping" => array(
						"sugarcrm_name" => "shipping_address_street",
						"xero_name" => "AddressLine1",
						"xero_label" => "Street Address",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"shipping_address_city" => array(
					"mapping" => array(
						"sugarcrm_name" => "shipping_address_city",
						"xero_name" => "City",
						"xero_label" => "Town / City",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"shipping_address_state" => array(
					"mapping" => array(
						"sugarcrm_name" => "shipping_address_state",
						"xero_name" => "Region",
						"xero_label" => "State / Region",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"shipping_address_postalcode" => array(
					"mapping" => array(
						"sugarcrm_name" => "shipping_address_postalcode",
						"xero_name" => "PostalCode",
						"xero_label" => "Postal / Zip Code",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"shipping_address_country" => array(
					"mapping" => array(
						"sugarcrm_name" => "shipping_address_country",
						"xero_name" => "Country",
						"xero_label" => "Country",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				
				"phone_office" => array(
					"mapping" => array(
						"sugarcrm_name" => "phone_office",
						"xero_name" => "PhoneNumber",
						"xero_label" => "Number",
					),
					"type" => 'Phones',
					"PhoneType" => 'DEFAULT',
					"MergeField" => array('PhoneAreaCode', 'PhoneCountryCode'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"fyn_xero_phone_office_cou" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_office_cou",
						"xero_name" => "PhoneCountryCode",
						"xero_label" => "Country",
					),
					"type" => 'Phones',
					"PhoneType" => 'DEFAULT',
					"MergeField" => array('PhoneAreaCode', 'PhoneNumber'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"fyn_xero_phone_office_area" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_office_area",
						"xero_name" => "PhoneAreaCode",
						"xero_label" => "Area",
					),
					"type" => 'Phones',
					"PhoneType" => 'DEFAULT',
					"MergeField" => array('PhoneCountryCode', 'PhoneNumber'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"phone_fax" => array(
					"mapping" => array(
						"sugarcrm_name" => "phone_fax",
						"xero_name" => "PhoneNumber",
						"xero_label" => "Number",
					),
					"type" => 'Phones',
					"PhoneType" => 'FAX',
					"MergeField" => array('PhoneAreaCode', 'PhoneCountryCode'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"fyn_xero_phone_fax_cou" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_fax_cou",
						"xero_name" => "PhoneCountryCode",
						"xero_label" => "Country",
					),
					"type" => 'Phones',
					"PhoneType" => 'FAX',
					"MergeField" => array('PhoneAreaCode', 'PhoneNumber'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"fyn_xero_phone_fax_area" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_fax_area",
						"xero_name" => "PhoneAreaCode",
						"xero_label" => "Area",
					),
					"type" => 'Phones',
					"PhoneType" => 'FAX',
					"MergeField" => array('PhoneCountryCode', 'PhoneNumber'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"fyn_xero_issupplier" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_issupplier",
						"xero_name" => "IsSupplier",
						"no_field_mapping" => true,
					),
					"readonly" => true,
					"data_type" => 'Bool',
					"SyncAPI" => false,
				),
				"fyn_xero_iscustomer" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_iscustomer",
						"xero_name" => "IsCustomer",
						"no_field_mapping" => true,
					),
					"readonly" => true,
					"data_type" => 'Bool',
					"SyncAPI" => false,
				),
				"fyn_xero_re_outstanding" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_re_outstanding",
						"xero_name" => "Outstanding",
						"no_field_mapping" => true,
					),
					"type" => 'Balances',
					"BalanceType" => 'AccountsReceivable',
					"readonly" => true,
					"data_type" => 'Decimal',
					"SyncAPI" => false,
				),
				"fyn_xero_re_overdue" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_re_overdue",
						"xero_name" => "Overdue",
						"no_field_mapping" => true,
					),
					"type" => 'Balances',
					"BalanceType" => 'AccountsReceivable',
					"readonly" => true,
					"data_type" => 'Decimal',
					"SyncAPI" => false,
				),
				"fyn_xero_pay_outstanding" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_pay_outstanding",
						"xero_name" => "Outstanding",
						"no_field_mapping" => true,
					),
					"type" => 'Balances',
					"BalanceType" => 'AccountsPayable',
					"readonly" => true,
					"data_type" => 'Decimal',
					"SyncAPI" => false,
				),
				"fyn_xero_pay_overdue" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_pay_overdue",
						"xero_name" => "Overdue",
						"no_field_mapping" => true,
					),
					"type" => 'Balances',
					"BalanceType" => 'AccountsPayable',
					"readonly" => true,
					"data_type" => 'Decimal',
					"SyncAPI" => false,
				),
				"fyn_xero_currency" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_currency",
						"xero_name" => "DefaultCurrency",
						"xero_label" => "Default Currency",
					),
					"data_type" => 'Dropdown',
					"SyncAPI" => true,
				),
				"fyn_xero_discount" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_discount",
						"xero_name" => "Discount",
						"no_field_mapping" => true,
					),
					"readonly" => true,
					"data_type" => 'Decimal',
					"SyncAPI" => false,
				),
				"website" => array(
					"mapping" => array(
						"sugarcrm_name" => "website",
						"xero_name" => "Website",
						"no_field_mapping" => true,
					),
					"readonly" => true,
					"data_type" => 'Varchar',
					"SyncAPI" => false,
				),
				"fyn_xero_puraccountcode" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_puraccountcode",
                        "xero_name" => "PurchasesDefaultAccountCode",
						"xero_label" => "For Purchases Default Account",
                    ),
					"data_type" => 'Dropdown',
					"SyncAPI" => true,
                ),
				"fyn_xero_salesaccountcode" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_salesaccountcode",
                        "xero_name" => "SalesDefaultAccountCode",
						"xero_label" => "For Sales Default Account",
                    ),
					"data_type" => 'Dropdown',
					"SyncAPI" => true,
                ),
				"fyn_xero_bankaccountnumber" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_bankaccountnumber",
                        "xero_name" => "BankAccountNumber",
						"no_field_mapping" => true,
                    ),
					"type" => 'BatchPayments',
					"BatchType" => 'BatchPayments',
					"readonly" => true,
					"data_type" => 'Varchar',
					"SyncAPI" => false,
                ),
				"fyn_xero_bankaccountname" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_bankaccountname",
                        "xero_name" => "BankAccountName",
						"no_field_mapping" => true,
                    ),
					"type" => 'BatchPayments',
					"BatchType" => 'BatchPayments',
					"readonly" => true,
					"data_type" => 'Varchar',
					"SyncAPI" => false,
                ),
				"fyn_xero_bankdetails" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_bankdetails",
                        "xero_name" => "Details",
						"no_field_mapping" => true,
                    ),
					"type" => 'BatchPayments',
					"BatchType" => 'BatchPayments',
					"readonly" => true,
					"data_type" => 'Varchar',
					"SyncAPI" => false,
                ),
				"fyn_xero_billsday" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_billsday",
                        "xero_name" => "Day",
						"no_field_mapping" => true,
                    ),
					"type" => 'PaymentTerms',
					"PaymentType" => 'Bills',
					"readonly" => true,
					"data_type" => 'Varchar',
					"SyncAPI" => false,
                ),
				"fyn_xero_billstype" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_billstype",
                        "xero_name" => "Type",
						"no_field_mapping" => true,
                    ),
					"type" => 'PaymentTerms',
					"PaymentType" => 'Bills',
					"readonly" => true,
					"data_type" => 'Dropdown',
					"SyncAPI" => false,
                ),
				"fyn_xero_salesday" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_salesday",
                        "xero_name" => "Day",
						"no_field_mapping" => true,
                    ),
					"type" => 'PaymentTerms',
					"PaymentType" => 'Sales',
					"readonly" => true,
					"data_type" => 'Varchar',
					"SyncAPI" => false,
                ),
				"fyn_xero_salestype" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_salestype",
                        "xero_name" => "Type",
						"no_field_mapping" => true,
                    ),
					"type" => 'PaymentTerms',
					"PaymentType" => 'Sales',
					"readonly" => true,
					"data_type" => 'Dropdown',
					"SyncAPI" => false,
                ),
            ),
			"Contacts" => array(
				"first_name" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "first_name",
                        "xero_name" => "FirstName",
						"xero_label" => "Primary Person First Name",
                    ),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
                ),
				"last_name" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "last_name",
                        "xero_name" => "LastName",
						"xero_label" => "Primary Person Last Name",
                    ),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
                ),
				"email1" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "email1",
                        "xero_name" => "EmailAddress", // unchanged field
						"xero_label" => "Primary Person Email",
                    ),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
                ),
				"phone_work" => array(
					"mapping" => array(
						"sugarcrm_name" => "phone_work",
						"xero_name" => "PhoneNumber",
						"xero_label" => "Number",
					),
					"type" => 'Phones',
					"PhoneType" => 'DDI',
					"MergeField" => array('PhoneAreaCode', 'PhoneCountryCode'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"fyn_xero_phone_work_cou" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_work_cou",
						"xero_name" => "PhoneCountryCode",
						"xero_label" => "Country",
					),
					"type" => 'Phones',
					"PhoneType" => 'DDI',
					"MergeField" => array('PhoneAreaCode', 'PhoneNumber'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"fyn_xero_phone_work_area" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_work_area",
						"xero_name" => "PhoneAreaCode",
						"xero_label" => "Area",
					),
					"type" => 'Phones',
					"PhoneType" => 'DDI',
					"MergeField" => array('PhoneCountryCode', 'PhoneNumber'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"phone_mobile" => array(
					"mapping" => array(
						"sugarcrm_name" => "phone_mobile",
						"xero_name" => "PhoneNumber",
						"xero_label" => "Number",
					),
					"type" => 'Phones',
					"PhoneType" => 'MOBILE',
					"MergeField" => array('PhoneAreaCode', 'PhoneCountryCode'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"fyn_xero_phone_mobile_cou" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_mobile_cou",
						"xero_name" => "PhoneCountryCode",
						"xero_label" => "Country",
					),
					"type" => 'Phones',
					"PhoneType" => 'MOBILE',
					"MergeField" => array('PhoneAreaCode', 'PhoneNumber'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
				"fyn_xero_phone_mobile_area" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_mobile_area",
						"xero_name" => "PhoneAreaCode",
						"xero_label" => "Area",
					),
					"type" => 'Phones',
					"PhoneType" => 'MOBILE',
					"MergeField" => array('PhoneCountryCode', 'PhoneNumber'),
					"data_type" => 'Varchar',
					"SyncAPI" => true,
				),
			),
        ),
		'AOS_Products' => array(
            "fields" => array(
                "fyn_xero_itemid" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_itemid",
                        "xero_name" => "ItemID", 
                    ),
                ),
                "name" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "name",
                        "xero_name" => "Code",
                    ),
                ),
                "description" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "description",
                        "xero_name" => "Description",
                    ),
                ),
				"cost" => array(
					"mapping" => array(
						"sugarcrm_name" => "cost",
						"xero_name" => "UnitPrice",
					),
					"type" => 'PurchaseDetails',
				),
				"fyn_xero_puracc" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_puracc",
						"xero_name" => "AccountCode",
					),
					"type" => 'PurchaseDetails',
				),
				"fyn_xero_purtax" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_purtax",
						"xero_name" => "TaxType",
					),
					"type" => 'PurchaseDetails',
				),
				"price" => array(
					"mapping" => array(
						"sugarcrm_name" => "price",
						"xero_name" => "UnitPrice",
					),
					"type" => 'SalesDetails',
				),
				"fyn_xero_salesacc" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_salesacc",
						"xero_name" => "AccountCode",
					),
					"type" => 'SalesDetails',
				),
				"fyn_xero_salestax" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_salestax",
						"xero_name" => "TaxType",
					),
					"type" => 'SalesDetails',
				),
            ),
        ),
		'AOS_Quotes' => array(
            "AOS_Quotes" => array(
                "fyn_xero_invoiceid" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_invoiceid",
                        "xero_name" => "InvoiceID", // unchanged Field
                    ),
					"readonly" => true,
                ),
				"fyn_xero_invoicenumber" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_invoicenumber",
                        "xero_name" => "InvoiceNumber",
                    ),
                ),
				"fyn_xero_invoicedate" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_invoicedate",
                        "xero_name" => "Date", // unchanged Field
                    ),
					"readonly" => true,
					"type" => 'date',
                ),
				"fyn_xero_duedate" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_duedate",
                        "xero_name" => "DueDate",
                    ),
					"type" => 'date',
                ),
				"fyn_xero_expectedpaymentdate" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_expectedpaymentdate",
                        "xero_name" => "ExpectedPaymentDate",
                    ),
					"readonly" => true,
					"type" => 'date',
                ),
				"fyn_xero_plannedpaymentdate" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_plannedpaymentdate",
                        "xero_name" => "PlannedPaymentDate",
                    ),
					"readonly" => true,
					"type" => 'date',
                ),
				"fyn_xero_status" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_status",
                        "xero_name" => "Status",
                    ),
					"readonly" => true,
                ),
				"fyn_xero_lineamounttypes" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_lineamounttypes",
                        "xero_name" => "LineAmountTypes",
                    ),
                ),
                "discount_amount" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "discount_amount",
                        "xero_name" => "TotalDiscount",
                    ),
                    "readonly" => true,
                ),
				"subtotal_amount" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "subtotal_amount",
                        "xero_name" => "SubTotal",
                    ),
					"readonly" => true,
                ),
				"tax_amount" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "tax_amount",
                        "xero_name" => "TotalTax",
                    ),
					"readonly" => true,
                ),
				"total_amount" => array(
					"mapping" => array(
						"sugarcrm_name" => "total_amount",
						"xero_name" => "Total",
					),
					"readonly" => true,
				),
				"fyn_xero_currencycode" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_currencycode",
						"xero_name" => "CurrencyCode",
					),
				),
				"fyn_xero_type" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_type",
						"xero_name" => "Type",
					),
				),
				"fyn_xero_amountdue" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_amountdue",
						"xero_name" => "AmountDue",
					),
					"readonly" => true,
				),
				"fyn_xero_amountpaid" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_amountpaid",
						"xero_name" => "AmountPaid",
					),
					"readonly" => true,
				),
				"fyn_xero_fullypaidondate" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_fullypaidondate",
                        "xero_name" => "FullyPaidOnDate",
                    ),
					"readonly" => true,
					"type" => 'date',
                ),
				"fyn_xero_amountcredited" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_amountcredited",
						"xero_name" => "AmountCredited",
					),
					"readonly" => true,
				),
				"fyn_xero_senttocontact" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_senttocontact",
						"xero_name" => "SentToContact",
					),
					"readonly" => true,
				),
				"fyn_xero_currencyrate" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_currencyrate",
						"xero_name" => "CurrencyRate",
					),
					"readonly" => true,
				),
				"discount_amount" => array(
					"mapping" => array(
						"sugarcrm_name" => "discount_amount",
						"xero_name" => "TotalDiscount",
					),
					"readonly" => true,
				),
            ),
			"AOS_Line_Item_Groups" => array(
				"subtotal_amount" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "subtotal_amount",
                        "xero_name" => "SubTotal",
                    ),
					"readonly" => true,
                ),
				"tax_amount" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "tax_amount",
                        "xero_name" => "TotalTax",
                    ),
					"readonly" => true,
                ),
				"total_amount" => array(
					"mapping" => array(
						"sugarcrm_name" => "total_amount",
						"xero_name" => "Total",
					),
					"readonly" => true,
				),
			),
			"AOS_Products_Quotes" => array(
				"name" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "name",
                        "xero_name" => "ItemCode",
                    ),
                ),
				"item_description" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "item_description",
                        "xero_name" => "Description",
                    ),
                ),
				"product_list_price" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "product_list_price",
                        "xero_name" => "UnitAmount", // unchanged field
                    ),
                ),
				"vat" => array(
					"mapping" => array(
						"sugarcrm_name" => "vat",
						"xero_name" => "TaxType",
					),
				),
				"vat_amt" => array(
					"mapping" => array(
						"sugarcrm_name" => "vat_amt",
						"xero_name" => "TaxAmount",
					),
				),
				"product_total_price" => array(
					"mapping" => array(
						"sugarcrm_name" => "product_total_price",
						"xero_name" => "LineAmount",
					),
				),
				"fyn_xero_accountcode" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_accountcode",
						"xero_name" => "AccountCode",
					),
				),
				"product_qty" => array(
					"mapping" => array(
						"sugarcrm_name" => "product_qty",
						"xero_name" => "Quantity",
					),
				),
				"product_discount" => array(
					"mapping" => array(
						"sugarcrm_name" => "product_discount",
						"xero_name" => "DiscountRate",
					),
					"MergeField" => array('discount_select', 'deal_calc'),
				),
			),
			"Payments" => array(
				"xero_paymentid" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "xero_paymentid",
                        "xero_name" => "PaymentID",
                    ),
					"readonly" => true,
                ),
				"xero_paymentdate" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "xero_paymentdate",
                        "xero_name" => "Date",
                    ),
                ),
				"xero_amount" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "xero_amount",
                        "xero_name" => "Amount",
                    ),
                ),
				"xero_reference" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_reference",
						"xero_name" => "Reference",
					),
					"readonly" => true,
				),
				"xero_currencyrate" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_currencyrate",
						"xero_name" => "CurrencyRate",
					),
					"readonly" => true,
				),
				"xero_paymenttype" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_paymenttype",
						"xero_name" => "PaymentType",
					),
					"readonly" => true,
				),
				"xero_status" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_status",
						"xero_name" => "Status",
					),
					"readonly" => true,
				),
				"xero_isreconciled" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_isreconciled",
						"xero_name" => "IsReconciled",
					),
					"readonly" => true,
				),
				"xero_paid_to" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_paid_to",
						"xero_name" => "Account",
					),
					'is_array' => true,
				),
			),
			"CreditNotes" => array(
				"xero_creditnoteid" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "xero_creditnoteid",
                        "xero_name" => "CreditNoteID",
                    ),
                ),
				"xero_creditnotenumber" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "xero_creditnotenumber",
                        "xero_name" => "CreditNoteNumber",
                    ),
                ),
				"xero_creditnotesdate" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "xero_creditnotesdate",
                        "xero_name" => "Date",
                    ),
                ),
				"xero_lineamounttypes" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_lineamounttypes",
						"xero_name" => "LineAmountTypes",
					),
				),
				"xero_appliedamount" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "xero_appliedamount",
                        "xero_name" => "AppliedAmount",
                    ),
                ),
				"xero_reference" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_reference",
						"xero_name" => "Reference",
					),
				),
				"xero_currencyrate" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_currencyrate",
						"xero_name" => "CurrencyRate",
					),
				),
				"xero_credittype" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_credittype",
						"xero_name" => "Type",
					),
				),
				"xero_status" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_status",
						"xero_name" => "Status",
					),
				),
				"xero_isreconciled" => array(
					"mapping" => array(
						"sugarcrm_name" => "xero_isreconciled",
						"xero_name" => "IsReconciled",
					),
				),
			),
			"Accounts" => array(
                "fyn_xero_contactid" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_contactid",
                        "xero_name" => "ContactID", // unchanged Field
                    ),
                ),
				"fyn_xero_accountnumber" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_accountnumber",
                        "xero_name" => "AccountNumber",
                    ),
                ),
				"fyn_xero_contactstatus" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_contactstatus",
                        "xero_name" => "ContactStatus", // unchanged Field
                    ),
                ),
				"name" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "name",
                        "xero_name" => "Name",
                    ),
                ),
				"fyn_xero_skype" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_skype",
                        "xero_name" => "SkypeUserName",
                    ),
                ),
				"fyn_xero_taxnumber" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_taxnumber",
                        "xero_name" => "TaxNumber",
                    ),
                ),
				"fyn_xero_salestax" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_salestax",
                        "xero_name" => "AccountsReceivableTaxType",
                    ),
                ),
				"fyn_xero_purtax" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_purtax",
                        "xero_name" => "AccountsPayableTaxType",
                    ),
                ),
				"billing_address_street" => array(
					"mapping" => array(
						"sugarcrm_name" => "billing_address_street",
						"xero_name" => "AddressLine1",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
				),
				"billing_address_city" => array(
					"mapping" => array(
						"sugarcrm_name" => "billing_address_city",
						"xero_name" => "City",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
				),
				"billing_address_state" => array(
					"mapping" => array(
						"sugarcrm_name" => "billing_address_state",
						"xero_name" => "Region",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
				),
				"billing_address_postalcode" => array(
					"mapping" => array(
						"sugarcrm_name" => "billing_address_postalcode",
						"xero_name" => "PostalCode",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
				),
				"billing_address_country" => array(
					"mapping" => array(
						"sugarcrm_name" => "billing_address_country",
						"xero_name" => "Country",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
				),
				"fyn_xero_poattention" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_poattention",
						"xero_name" => "AttentionTo",
					),
					"type" => 'Addresses',
					"AddressType" => 'POBOX',
				),
				"shipping_address_street" => array(
					"mapping" => array(
						"sugarcrm_name" => "shipping_address_street",
						"xero_name" => "AddressLine1",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
				),
				"shipping_address_city" => array(
					"mapping" => array(
						"sugarcrm_name" => "shipping_address_city",
						"xero_name" => "City",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
				),
				"shipping_address_state" => array(
					"mapping" => array(
						"sugarcrm_name" => "shipping_address_state",
						"xero_name" => "Region",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
				),
				"shipping_address_postalcode" => array(
					"mapping" => array(
						"sugarcrm_name" => "shipping_address_postalcode",
						"xero_name" => "PostalCode",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
				),
				"shipping_address_country" => array(
					"mapping" => array(
						"sugarcrm_name" => "shipping_address_country",
						"xero_name" => "Country",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
				),
				"fyn_xero_streetattention" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_streetattention",
						"xero_name" => "AttentionTo",
					),
					"type" => 'Addresses',
					"AddressType" => 'STREET',
				),
				"phone_office" => array(
					"mapping" => array(
						"sugarcrm_name" => "phone_office",
						"xero_name" => "PhoneNumber",
					),
					"type" => 'Phones',
					"PhoneType" => 'DEFAULT',
					"MergeField" => array('PhoneAreaCode', 'PhoneCountryCode'),
				),
				"fyn_xero_phone_office_cou" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_office_cou",
						"xero_name" => "PhoneCountryCode",
					),
					"type" => 'Phones',
					"PhoneType" => 'DEFAULT',
					"MergeField" => array('PhoneAreaCode', 'PhoneNumber'),
				),
				"fyn_xero_phone_office_area" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_office_area",
						"xero_name" => "PhoneAreaCode",
					),
					"type" => 'Phones',
					"PhoneType" => 'DEFAULT',
					"MergeField" => array('PhoneCountryCode', 'PhoneNumber'),
				),
				"phone_fax" => array(
					"mapping" => array(
						"sugarcrm_name" => "phone_fax",
						"xero_name" => "PhoneNumber",
					),
					"type" => 'Phones',
					"PhoneType" => 'FAX',
					"MergeField" => array('PhoneAreaCode', 'PhoneCountryCode'),
				),
				"fyn_xero_phone_fax_cou" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_fax_cou",
						"xero_name" => "PhoneCountryCode",
					),
					"type" => 'Phones',
					"PhoneType" => 'FAX',
					"MergeField" => array('PhoneAreaCode', 'PhoneNumber'),
				),
				"fyn_xero_phone_fax_area" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_phone_fax_area",
						"xero_name" => "PhoneAreaCode",
					),
					"type" => 'Phones',
					"PhoneType" => 'FAX',
					"MergeField" => array('PhoneCountryCode', 'PhoneNumber'),
				),
				"fyn_xero_issupplier" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_issupplier",
						"xero_name" => "IsSupplier",
					),
				),
				"fyn_xero_iscustomer" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_iscustomer",
						"xero_name" => "IsCustomer",
					),
				),
				"fyn_xero_re_outstanding" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_re_outstanding",
						"xero_name" => "Outstanding",
					),
					"type" => 'Balances',
					"BalanceType" => 'AccountsReceivable',
				),
				"fyn_xero_re_overdue" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_re_overdue",
						"xero_name" => "Overdue",
					),
					"type" => 'Balances',
					"BalanceType" => 'AccountsReceivable',
				),
				"fyn_xero_pay_outstanding" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_pay_outstanding",
						"xero_name" => "Outstanding",
					),
					"type" => 'Balances',
					"BalanceType" => 'AccountsPayable',
				),
				"fyn_xero_pay_overdue" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_pay_overdue",
						"xero_name" => "Overdue",
					),
					"type" => 'Balances',
					"BalanceType" => 'AccountsPayable',
				),
				"fyn_xero_currency" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_currency",
						"xero_name" => "DefaultCurrency",
					),
				),
				"fyn_xero_discount" => array(
					"mapping" => array(
						"sugarcrm_name" => "fyn_xero_discount",
						"xero_name" => "Discount",
					),
				),
				"website" => array(
					"mapping" => array(
						"sugarcrm_name" => "website",
						"xero_name" => "Website",
					),
				),
				"fyn_xero_puraccountcode" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_puraccountcode",
                        "xero_name" => "PurchasesDefaultAccountCode",
                    ),
                ),
				"fyn_xero_salesaccountcode" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_salesaccountcode",
                        "xero_name" => "SalesDefaultAccountCode",
                    ),
                ),
				"fyn_xero_bankaccountnumber" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_bankaccountnumber",
                        "xero_name" => "BankAccountNumber",
                    ),
					"type" => 'BatchPayments',
					"BatchType" => 'BatchPayments',
                ),
				"fyn_xero_bankaccountname" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_bankaccountname",
                        "xero_name" => "BankAccountName",
                    ),
					"type" => 'BatchPayments',
					"BatchType" => 'BatchPayments',
                ),
				"fyn_xero_bankdetails" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_bankdetails",
                        "xero_name" => "Details",
                    ),
					"type" => 'BatchPayments',
					"BatchType" => 'BatchPayments',
                ),
				"fyn_xero_billsday" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_billsday",
                        "xero_name" => "Day",
                    ),
					"type" => 'PaymentTerms',
					"PaymentType" => 'Bills',
                ),
				"fyn_xero_billstype" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_billstype",
                        "xero_name" => "Type",
                    ),
					"type" => 'PaymentTerms',
					"PaymentType" => 'Bills',
                ),
				"fyn_xero_salesday" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_salesday",
                        "xero_name" => "Day",
                    ),
					"type" => 'PaymentTerms',
					"PaymentType" => 'Sales',
                ),
				"fyn_xero_salestype" => array(
                    "mapping" => array(
                        "sugarcrm_name" => "fyn_xero_salestype",
                        "xero_name" => "Type",
                    ),
					"type" => 'PaymentTerms',
					"PaymentType" => 'Sales',
                ),
            ),
        ),
    );
	
	## Webhooks Call OR XERO to SugarCRM Sync
	public static $webhooks_call = false;

    
    
    ## START Global Xero Apps Sync Settings
    public static function getGlobalGoogleAppsSettings(){
        
        
        
        require_once('modules/Administration/Administration.php');
        $Administration = new Administration();
        $Administration->retrieveSettings('fynxeroapps');
        
        if(!empty($Administration->settings['fynxeroapps_global_setting']))
            $fyn_appssync = unserialize(base64_decode($Administration->settings['fynxeroapps_global_setting']));
        else
            $fyn_appssync = self::$fyn_appssync_user;
        
        return $fyn_appssync;
    }
    ## END Global Xero Apps Sync Settings

	## START Get Mapping Field Xero List to SugarCRM
	public static function GetMappingField($supported_module){
		global $db;
		$default_mappings = self::$default_mappings[$supported_module];
		
		$Administration = new Administration();
		$Administration->retrieveSettings('fyn_xero');
		$current_mapping = $Administration->settings['fynxero_'.$supported_module];
		
		if(!empty($current_mapping))
		{
			return unserialize(base64_decode($current_mapping));
		}
		return $default_mappings;
	}
	## END Get Mapping Field Xero List to SugarCRM
	
	## START Checking Mapping Field For Update & Cron Run
	public function checkMappingFieldUpdate($supported_module, $bean_obj){
		$syc_xero = false;		
		$cached_mappings = self::GetMappingField($supported_module);
		$field_options = self::get_importable_field($bean_obj);
		foreach($field_options as $value=>$name){
			if($cached_mappings['fields'][$value]['mapping']['sugarcrm_name']==$value){
				if($bean_obj->$value != $bean_obj->fetched_row[$value])
					$syc_xero = true;
			}
		}
		return $syc_xero;
	}
	## END Checking Mapping Field For Update & Cron Run

	## START Xero API Detail Fetch 
	public static function getXeroAPIDetails()
    {
		require_once('modules/Administration/Administration.php');
        $Administration = new Administration();
		$Administration->retrieveSettings('fynxero');
		$fynAPI = array();
		$fynAPI['fynconsumer_key'] = $Administration->settings['fynxero_fynconsumer_key'];
		$fynAPI['fynconsumer_secret'] = $Administration->settings['fynxero_fynconsumer_secret'];
		$fynAPI['fynpublic_key'] = $Administration->settings['fynxero_fynpublic_key'];
		$fynAPI['fynprivate_key'] = $Administration->settings['fynxero_fynprivate_key'];
		
		self::$fynGetAPIDetails = $fynAPI;
		
		return self::$fynGetAPIDetails;
	}
	## END Xero API Detail Fetch 

	## START Check Xero Connection
	public static function checkxeroApiConnection()
    {
		if(empty(self::$fynGetAPIDetails['fynconsumer_key']))
			self::getXeroAPIDetails();
		$fynGetAPIDetails = self::$fynGetAPIDetails;
		try {
			
			 
			$xero = new Xero($fynGetAPIDetails['fynconsumer_key'], $fynGetAPIDetails['fynconsumer_secret'], $fynGetAPIDetails['fynpublic_key'], $fynGetAPIDetails['fynprivate_key'], 'json' );
			
			// Create the contact
			#$result = $xero->Invoices(false, date('Y-m-d').'T05:00:08', array() );//Payments('2cd9357d-0511-4482-872f-fdb7e2fd66dd');
			//Invoices('31ebe058-d04f-405a-8ce2-0c7dbe27ed9b');//('9867ab79-a178-41be-806a-6929ce1da178');//(false, date('Y-m-d'), array() );//(false, date('Y-m-d'), array() );
			#echo '<pre>';
			#print_r($result);exit;
			#$contact_result = $xero->Contacts('e6e83a0a-8af5-498a-88f5-7489d1fcf05e');
			//Payments('e8a6e251-bb43-45ae-870b-4043c76e7cf6');
			#echo '<pre>';
			#print_r($contact_result);exit;
			
			// Get details of all accounts
		    $all_accounts = $xero->Accounts;
			if(is_array($all_accounts)){
				#echo '<pre>';
				#print_r($all_accounts);
			}
			else{
				//echo urldecode($all_accounts);
				$vcode = explode("&",urldecode($all_accounts));
				$vcode1 = explode("=",$vcode[0]);
				$vcode2 = explode("=",$vcode[1]);
				$message = $vcode1[1].' <br />';
				$message .= $vcode2[1];
				
				return array('success'=>false, 'message'=>$message);
			}
			return array('success'=>true);
        } catch(Exception $e) {
        	
			$GLOBALS['log']->fatal("ClsFYNXero::checkxeroApiConnection: " . print_r($e->getMessage(),true));
            return array('success'=>false,'message'=>$e->getMessage());
        }
	} 
	## END Check Xero Connection
	
	## START Xero TaxRate List
	public static function Generate_TaxRate_List()
    {
		if(empty(self::$fynGetAPIDetails['fynconsumer_key']))
			self::getXeroAPIDetails();
		$fynGetAPIDetails = self::$fynGetAPIDetails;
		try {
			$xero = new Xero($fynGetAPIDetails['fynconsumer_key'], $fynGetAPIDetails['fynconsumer_secret'], $fynGetAPIDetails['fynpublic_key'], $fynGetAPIDetails['fynprivate_key'], 'json' );
			
			// Create the contact
			$txtrate_result = $xero->TaxRates;
			#echo '<pre>';
			#print_r($txtrate_result['TaxRates']['TaxRate']);exit;
			$list_value = '[';
			$lp = 1;
			$qry_del = "DELETE FROM fyn_taxrates WHERE 1";
			$GLOBALS['db']->query($qry_del, false);
			if(count($txtrate_result['TaxRates']['TaxRate'])>0)
			{
				foreach($txtrate_result['TaxRates']['TaxRate'] as $TaxRate)
				{
					$bean_taxrates = BeanFactory::getBean('FYN_Taxrates');
					$bean_taxrates->name = $TaxRate['Name'];
					$bean_taxrates->xero_taxtype = $TaxRate['TaxType'];
					$bean_taxrates->xero_displaytaxrate = $TaxRate['DisplayTaxRate'];
					$bean_taxrates->xero_effectiverate = $TaxRate['EffectiveRate'];
					$bean_taxrates->xero_status = ucfirst(strtolower($TaxRate['Status']));
					$bean_taxrates->list_order = $lp;
					$bean_taxrates->save();
					if($lp>1)
						$list_value .= ',';
					$list_value .= '[&quot;'.$TaxRate['TaxType'].'&quot;,&quot;'.$TaxRate['Name'].'('.intval($TaxRate['DisplayTaxRate']).'%)&quot;]';
					$lp++;
				}
			}
			
			$list_value .= ']';
			$REQUEST = $_REQUEST;
			$_REQUEST = array();
			$_REQUEST['to_pdf'] = 'true';
			$_REQUEST['sugar_body_only'] = '1';
			$_REQUEST['module'] = 'ModuleBuilder';
			$_REQUEST['action'] = 'savedropdown';
			$_REQUEST['view_module'] = '';
			$_REQUEST['view_package'] = 'studio';
			$_REQUEST['list_value'] = $list_value;
			$_REQUEST['dropdown_name'] = 'xero_taxrate_list';
			$_REQUEST['dropdown_lang'] = 'en_us';
			$_REQUEST['drop_name'] = '';
			$_REQUEST['drop_value'] = '';
		
			require_once 'modules/ModuleBuilder/parsers/parser.dropdown.php' ;
			$parser = new ParserDropDown ( ) ;
			$parser->saveDropDown ( $_REQUEST ) ;
			
			$_REQUEST = array();
			$_REQUEST = $REQUEST;
			
			return array('success'=>true, 'message' => 'Sync Successfull. Updated Taxrate List Dropdown.');
		}catch(Exception $e) {
			$GLOBALS['log']->fatal("ClsFYNXero::Generate_TaxRate_List: " . print_r($e->getMessage(),true));
            return array('success'=>false,'message'=>$e->getMessage());
        }
	}
	## END Xero TaxRate List
	
	## START Xero Accounting List
	public static function Generate_Account_List()
    {
		if(empty(self::$fynGetAPIDetails['fynconsumer_key']))
			self::getXeroAPIDetails();
		$fynGetAPIDetails = self::$fynGetAPIDetails;
		try {
			$xero = new Xero($fynGetAPIDetails['fynconsumer_key'], $fynGetAPIDetails['fynconsumer_secret'], $fynGetAPIDetails['fynpublic_key'], $fynGetAPIDetails['fynprivate_key'], 'json' );
			
			// Create the contact
			$account_result = $xero->Accounts;
			#echo '<pre>';
			#print_r($account_result['Accounts']['Account']);exit;
			$list_value = '[';
			$lp = 0;
			$class_arr = array('REVENUE', 'EQUITY', 'LIABILITY', 'ASSET', 'EXPENSE');
			foreach($class_arr as $classes){
				foreach($account_result['Accounts']['Account'] as $account)
				{
					if($classes!=$account['Class'])
						continue;
					if(empty($account['Code']))
						continue;
					if($lp==1)
						$list_value .= ',';
					$list_value .= '[&quot;'.$account['Code'].'&quot;,&quot;'.$account['Code'].' - '.$account['Name'].'&quot;]';
					$lp = 1;
				}
			}
			$list_value .= ']';
			$REQUEST = $_REQUEST;
			$_REQUEST = array();
			$_REQUEST['to_pdf'] = 'true';
			$_REQUEST['sugar_body_only'] = '1';
			$_REQUEST['module'] = 'ModuleBuilder';
			$_REQUEST['action'] = 'savedropdown';
			$_REQUEST['view_module'] = '';
			$_REQUEST['view_package'] = 'studio';
			$_REQUEST['list_value'] = $list_value;
			$_REQUEST['dropdown_name'] = 'xero_accounting_list';
			$_REQUEST['dropdown_lang'] = 'en_us';
			$_REQUEST['drop_name'] = '';
			$_REQUEST['drop_value'] = '';
		
			require_once 'modules/ModuleBuilder/parsers/parser.dropdown.php' ;
			$parser = new ParserDropDown ( ) ;
			$parser->saveDropDown ( $_REQUEST ) ;
			
			$list_value = '[';
			$list_pur_value = '[';
			$lp = 0; $lp_pur = 0;
			$class_arr = array('EXPENSE', 'ASSET', 'LIABILITY', 'EQUITY', 'REVENUE');
			#echo '<pre>';
			#print_r($account_result['Accounts']['Account']);exit;
			foreach($class_arr as $classes){
				foreach($account_result['Accounts']['Account'] as $account)
				{
					if($classes!=$account['Class'])
						continue;
					if(empty($account['AccountID']))
						continue;
					if($account['Type']=='BANK' || $account['EnablePaymentsToAccount']=='true'){
						if($lp==1)
							$list_value .= ',';
						if(empty($account['Code']))
						$list_value .= '[&quot;'.$account['AccountID'].'&quot;,&quot;'.$account['Name'].'&quot;]';
						else
						$list_value .= '[&quot;'.$account['AccountID'].'&quot;,&quot;'.$account['Code'].' - '.$account['Name'].'&quot;]';
						$lp = 1;
					}
					## Accounting Purchase List
					if($lp_pur==1)
						$list_pur_value .= ',';
					$list_pur_value .= '[&quot;'.$account['Code'].'&quot;,&quot;'.$account['Code'].' - '.$account['Name'].'&quot;]';
					$lp_pur = 1;
				}
			}

			$list_value .= ']';
			$list_pur_value .= ']';
			$REQUEST = $_REQUEST;
			$_REQUEST = array();
			$_REQUEST['to_pdf'] = 'true';
			$_REQUEST['sugar_body_only'] = '1';
			$_REQUEST['module'] = 'ModuleBuilder';
			$_REQUEST['action'] = 'savedropdown';
			$_REQUEST['view_module'] = '';
			$_REQUEST['view_package'] = 'studio';
			$_REQUEST['list_value'] = $list_pur_value;
			$_REQUEST['dropdown_name'] = 'xero_accounting_pur_list';
			$_REQUEST['dropdown_lang'] = 'en_us';
			$_REQUEST['drop_name'] = '';
			$_REQUEST['drop_value'] = '';
		
			require_once 'modules/ModuleBuilder/parsers/parser.dropdown.php' ;
			$parser = new ParserDropDown ( ) ;
			$parser->saveDropDown ( $_REQUEST ) ;
			
			$REQUEST = $_REQUEST;
			$_REQUEST = array();
			$_REQUEST['to_pdf'] = 'true';
			$_REQUEST['sugar_body_only'] = '1';
			$_REQUEST['module'] = 'ModuleBuilder';
			$_REQUEST['action'] = 'savedropdown';
			$_REQUEST['view_module'] = '';
			$_REQUEST['view_package'] = 'studio';
			$_REQUEST['list_value'] = $list_value;
			$_REQUEST['dropdown_name'] = 'xero_accounting_pay_list';
			$_REQUEST['dropdown_lang'] = 'en_us';
			$_REQUEST['drop_name'] = '';
			$_REQUEST['drop_value'] = '';
		
			require_once 'modules/ModuleBuilder/parsers/parser.dropdown.php' ;
			$parser = new ParserDropDown ( ) ;
			$parser->saveDropDown ( $_REQUEST ) ;
			
			$_REQUEST = array();
			$_REQUEST = $REQUEST;
			
			return array('success'=>true, 'message' => 'Sync Successfull. Updated Accounting List Dropdown.');
		}catch(Exception $e) {
			$GLOBALS['log']->fatal("ClsFYNXero::Generate_TaxRate_List: " . print_r($e->getMessage(),true));
            return array('success'=>false,'message'=>$e->getMessage());
        }
	}
	## END Xero Accounting List
	
	## START Xero Currencies List
	public static function Generate_Currency_List()
    {
		if(empty(self::$fynGetAPIDetails['fynconsumer_key']))
			self::getXeroAPIDetails();
		$fynGetAPIDetails = self::$fynGetAPIDetails;
		try {
			$xero = new Xero($fynGetAPIDetails['fynconsumer_key'], $fynGetAPIDetails['fynconsumer_secret'], $fynGetAPIDetails['fynpublic_key'], $fynGetAPIDetails['fynprivate_key'], 'json' );
			
			// Create the contact
			$currencies_result = $xero->Currencies;
			#echo '<pre>';
			#print_r($txtrate_result['TaxRates']['TaxRate']);exit;
			$list_value = '[[&quot;&quot;,&quot;None&quot;]';
			$lp = 0;
			foreach($currencies_result['Currencies']['Currency'] as $Currency)
			{
				#if($lp==1)
					$list_value .= ',';
				$list_value .= '[&quot;'.$Currency['Code'].'&quot;,&quot;'.$Currency['Description'].'&quot;]';
				$lp = 1;
			}
			$list_value .= ']';
			$REQUEST = $_REQUEST;
			$_REQUEST = array();
			$_REQUEST['to_pdf'] = 'true';
			$_REQUEST['sugar_body_only'] = '1';
			$_REQUEST['module'] = 'ModuleBuilder';
			$_REQUEST['action'] = 'savedropdown';
			$_REQUEST['view_module'] = '';
			$_REQUEST['view_package'] = 'studio';
			$_REQUEST['list_value'] = $list_value;
			$_REQUEST['dropdown_name'] = 'xero_currencies_list';
			$_REQUEST['dropdown_lang'] = 'en_us';
			$_REQUEST['drop_name'] = '';
			$_REQUEST['drop_value'] = '';
		
			require_once 'modules/ModuleBuilder/parsers/parser.dropdown.php' ;
			$parser = new ParserDropDown ( ) ;
			$parser->saveDropDown ( $_REQUEST ) ;
			
			$_REQUEST = array();
			$_REQUEST = $REQUEST;
			
			return array('success'=>true, 'message' => 'Sync Successfull. Updated Currency Dropdown.');
		}catch(Exception $e) {
			$GLOBALS['log']->fatal("ClsFYNXero::Generate_Currency_List: " . print_r($e->getMessage(),true));
            return array('success'=>false,'message'=>$e->getMessage());
        }
	}
	## END Xero Currencies List
	
	## START Sugar to Xero Inventry Item Add or Update
	public static function ProductItemsAdd($xero_bean_inventry_lists)
    {
		global $db;
		if(empty(self::$fynGetAPIDetails['fynconsumer_key']))
			self::getXeroAPIDetails();
		$fynGetAPIDetails = self::$fynGetAPIDetails;
		try {
			$xero = new Xero($fynGetAPIDetails['fynconsumer_key'], $fynGetAPIDetails['fynconsumer_secret'], $fynGetAPIDetails['fynpublic_key'], $fynGetAPIDetails['fynprivate_key'], 'json' );
			
			foreach($xero_bean_inventry_lists as $xero_bean_inventry_list)
			{
				$new_item = unserialize(base64_decode($xero_bean_inventry_list->description));
				// echo "<pre>"; 
				// print_r($new_item);exit;
				$item_result = $xero->Items($new_item);
				
				if($item_result['Status'] == 'OK')
                {
    				$ItemID = $item_result['Items']['Item']['ItemID'];
    				
    				if(empty($new_item[0]['ItemID'])){
    					## UPDATE Entry if Item Id Blank
    					$qry_upd = "UPDATE aos_products set fyn_xero_itemid = '".$ItemID."' WHERE id = '".$xero_bean_inventry_list->fyn_module_id."'";
    					$db->query($qry_upd);
    				}
                }else{
                    $GLOBALS['log']->fatal("Cls_fynXero::ProductItemsAdd: " . print_r($item_result,true));
                }
				## DELETE Entry permanetly
				$qry_del = "DELETE FROM fyn_xero WHERE id = '".$xero_bean_inventry_list->id."'";
				$db->query($qry_del);
			}
        } catch(Exception $e) {
			$GLOBALS['log']->fatal("ClsFYNXero::ProductItemsAdd: " . print_r($e->getMessage(),true));
        }
	} 
	## END Sugar to Xero Inventry Item Add or Update
	
	## START Sugar Account to Xero Contact List Add or Update
	public static function XeroContactAdd($xero_bean_account_lists)
    {
		global $db;
		if(empty(self::$fynGetAPIDetails['fynconsumer_key']))
			self::getXeroAPIDetails();
		$fynGetAPIDetails = self::$fynGetAPIDetails;
		try {
			$xero = new Xero($fynGetAPIDetails['fynconsumer_key'], $fynGetAPIDetails['fynconsumer_secret'], $fynGetAPIDetails['fynpublic_key'], $fynGetAPIDetails['fynprivate_key'], 'json' );
			
			foreach($xero_bean_account_lists as $xero_bean_account_list)
			{
				$new_item = unserialize(base64_decode($xero_bean_account_list->description));
				#echo '<pre>';
				#print_r($new_item);
				#exit;
				$contact_result = $xero->Contacts($new_item);
				#print_r($contact_result);
				#exit;
				if($contact_result['Status'] == 'OK')
                {
    				$ContactID = $contact_result['Contacts']['Contact']['ContactID'];
    				
    				if(empty($new_item[0]['ContactID'])){
    					## UPDATE Entry if Item Id Blank
    					$qry_upd = "UPDATE accounts set fyn_xero_contactid = '".$ContactID."' WHERE id = '".$xero_bean_account_list->fyn_module_id."'";
    					$db->query($qry_upd);
    				}
                }else{
                    $GLOBALS['log']->fatal("ClsFYNXero::XeroContactAdd: " . print_r($contact_result,true));
                }
				## DELETE Entry permanetly
				$qry_del = "DELETE FROM fyn_xero WHERE id = '".$xero_bean_account_list->id."'";
				$db->query($qry_del);
			}
        } catch(Exception $e) {
			$GLOBALS['log']->fatal("ClsFYNXero::XeroContactAdd: " . print_r($e->getMessage(),true));
        }
	} 
	## END Sugar Account to Xero Contact List Add or Update
	
	## START Sugar Quote to Xero Invoice List Add or Update
	public static function XeroInvoiceAdd($xero_bean_quote_lists)
    {
		global $db;
		if(empty(self::$fynGetAPIDetails['fynconsumer_key']))
			self::getXeroAPIDetails();
		$fynGetAPIDetails = self::$fynGetAPIDetails;
		try {
			$xero = new Xero($fynGetAPIDetails['fynconsumer_key'], $fynGetAPIDetails['fynconsumer_secret'], $fynGetAPIDetails['fynpublic_key'], $fynGetAPIDetails['fynprivate_key'], 'json' );
			
			foreach($xero_bean_quote_lists as $xero_bean_quote_list)
			{
				$new_item = unserialize(base64_decode($xero_bean_quote_list->description));
				
				#print_r($new_item);
				#exit;
				$invoice_result = $xero->Invoices($new_item);
				
				if($invoice_result['Status'] == 'OK')
                {
    				$Invoices = $invoice_result['Invoices']['Invoice'];
    				$qry_upd_inner = '';
    				if(empty($new_item[0]['InvoiceID'])){
    					## UPDATE Entry if Item Id Blank
    					$invoicedate_dt = explode('T', $Invoices['Date']);
    					$qry_upd_inner = "fyn_xero_invoiceid = '".$Invoices['InvoiceID']."', fyn_xero_invoicedate = '".$invoicedate_dt[0]."', ";
    				}
    				$qry_upd = "UPDATE aos_quotes set ".$qry_upd_inner." fyn_xero_status = '".$Invoices['Status']."', fyn_xero_amountdue = '".$Invoices['AmountDue']."', fyn_xero_amountpaid = '".$Invoices['AmountPaid']."', fyn_xero_amountcredited = '".$Invoices['AmountCredited']."', fyn_xero_currencyrate = '".$Invoices['CurrencyRate']."' WHERE id = '".$xero_bean_quote_list->fyn_module_id."'";
    				$db->query($qry_upd);
                }else{
                    $GLOBALS['log']->fatal(" ClsFYNXero::XeroInvoiceAdd: " . print_r($invoice_result,true));    
                }
                #exit;
				## DELETE Entry permanetly
				$qry_del = "DELETE FROM fyn_xero WHERE id = '".$xero_bean_quote_list->id."'";
				$db->query($qry_del);
                
			}
        } catch(Exception $e) {
			$GLOBALS['log']->fatal(" ClsFYNXero::XeroInvoiceAdd: " . print_r($e->getMessage(),true));
        }
	} 
	## END Sugar Quote to Xero Invoice List Add or Update
	
	## START Sugar Payment to Xero Payment List Add or Update
	public static function SugarPaymentXeroPaymentAdd($xero_bean_payment_lists)
    {
		global $db;
		if(empty(self::$fynGetAPIDetails['fynconsumer_key']))
			self::getXeroAPIDetails();
		$fynGetAPIDetails = self::$fynGetAPIDetails;
		try {
			$xero = new Xero($fynGetAPIDetails['fynconsumer_key'], $fynGetAPIDetails['fynconsumer_secret'], $fynGetAPIDetails['fynpublic_key'], $fynGetAPIDetails['fynprivate_key'], 'json' );
			
			foreach($xero_bean_payment_lists as $xero_bean_payment_lists)
			{
				$new_item = unserialize(base64_decode($xero_bean_payment_lists->description));
				#echo '<pre>';
				#print_r($new_item);
				#exit;
				$payment_result = $xero->Payments($new_item);
				#print_r($contact_result);
				#exit;
				if($payment_result['Status'] == 'OK')
                {
    				$Payments = $payment_result['Payments']['Payment'];
    				$qry_upd_inner = '';
    				if(empty($new_item[0]['PaymentID'])){
    					## UPDATE Entry if Item Id Blank
    					$payment_dt = explode('T', $Payments['Date']);
    					$qry_upd_inner = "xero_paymentid = '".$Payments['PaymentID']."', xero_paymentdate = '".$payment_dt[0]."', ";
    				}
    				$qry_upd = "UPDATE fyn_xeropayment set ".$qry_upd_inner." xero_status = '".$Payments['Status']."', xero_amount = '".$Payments['Amount']."', xero_currencyrate = '".$Payments['CurrencyRate']."', xero_isreconciled = '".$Payments['IsReconciled']."' WHERE id = '".$xero_bean_payment_lists->fyn_module_id."'";
    				$db->query($qry_upd);
                }else{
                    $GLOBALS['log']->fatal("ClsFYNXero::SugarPaymentXeroPaymentAdd: " . print_r($payment_result,true));
                }
				## DELETE Entry permanetly
				$qry_del = "DELETE FROM fyn_xero WHERE id = '".$xero_bean_payment_lists->id."'";
				$db->query($qry_del);
			}
        } catch(Exception $e) {
			$GLOBALS['log']->fatal("ClsFYNXero::SugarPaymentXeroPaymentAdd: " . print_r($e->getMessage(),true));
        }
	} 
	## END Sugar Payment to Xero Payment List Add or Update
	
	## START Get Importable Field 
	public function get_importable_field($object){
		global $moduleStrings;
		$fields  = $object->get_importable_fields();
		$field_options = array(); 
		$not_array = array('id', 'date_entered', 'deleted', 'date_modified', 'email1', 'email_addresses_non_primary', 'email_opt_out', 'invalid_email', 'modified_user_id', 'created_by', 'converted', 'full_name', 'ticker_symbol', 'portal_name', 'portal_app');
		foreach ( $fields as $fieldname => $properties ) {
			if(in_array($fieldname, $not_array))
				continue;
			if($properties['type']=='relate')
				continue;
			#print_r($properties);echo "<br>";
			// get field name
			if (!empty($moduleStrings['LBL_EXPORT_'.strtoupper($fieldname)]) )
			{
				 $displayname = str_replace(":","", $moduleStrings['LBL_EXPORT_'.strtoupper($fieldname)] );
			}
			else if (!empty ($properties['vname']))
			{
				$displayname = str_replace(":","",translate($properties['vname'] ,$object->module_dir));
			}
			else
				$displayname = str_replace(":","",translate($properties['name'] ,$object->module_dir));
			
			$field_options[$fieldname] = $displayname;
		}
		return $field_options;
	}
	## END Get Importable Field
}