<?php
$module_name = 'FYN_Xeropayment';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '20%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'XERO_PAYMENTID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_XERO_PAYMENTID',
    'width' => '10%',
    'default' => true,
  ),
  'XERO_AMOUNT' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_XERO_AMOUNT',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'XERO_STATUS' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'label' => 'LBL_XERO_STATUS',
    'width' => '10%',
  ),
  'XERO_PAID_TO' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_XERO_PAID_TO',
    'width' => '10%',
    'default' => true,
  ),
  'XERO_PAYMENTTYPE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_XERO_PAYMENTTYPE',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
);
?>
