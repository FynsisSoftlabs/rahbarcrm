<?php
$module_name = 'FYN_Xeropayment';
$viewdefs [$module_name] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 'assigned_user_name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'xero_paymentid',
            'label' => 'LBL_XERO_PAYMENTID',
          ),
          1 => 
          array (
            'name' => 'xero_status',
            'label' => 'LBL_XERO_STATUS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'xero_paymenttype',
            'studio' => 'visible',
            'label' => 'LBL_XERO_PAYMENTTYPE',
          ),
          1 => 
          array (
            'name' => 'xero_paymentdate',
            'label' => 'LBL_XERO_PAYMENTDATE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'xero_amount',
            'label' => 'LBL_XERO_AMOUNT',
          ),
          1 => 
          array (
            'name' => 'xero_paid_to',
            'studio' => 'visible',
            'label' => 'LBL_XERO_PAID_TO',
          ),
        ),
      ),
    ),
  ),
);
?>
