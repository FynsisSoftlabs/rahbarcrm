<?php
$module_name = 'FYN_Xeropayment';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 'assigned_user_name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'fyn_xeropayment_aos_quotes_name',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'xero_paymentid',
            'label' => 'LBL_XERO_PAYMENTID',
          ),
          1 => 
          array (
            'name' => 'xero_status',
            'label' => 'LBL_XERO_STATUS',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'xero_amount',
            'label' => 'LBL_XERO_AMOUNT',
          ),
          1 => 
          array (
            'name' => 'currency_id',
            'studio' => 'visible',
            'label' => 'LBL_CURRENCY',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'xero_paid_to',
            'studio' => 'visible',
            'label' => 'LBL_XERO_PAID_TO',
          ),
          1 => '',
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'xero_currencycode',
            'label' => 'LBL_XERO_CURRENCYCODE',
          ),
          1 => 
          array (
            'name' => 'xero_currencyrate',
            'label' => 'LBL_XERO_CURRENCYRATE',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'xero_paymenttype',
            'studio' => 'visible',
            'label' => 'LBL_XERO_PAYMENTTYPE',
          ),
          1 => 
          array (
            'name' => 'xero_paymentdate',
            'label' => 'LBL_XERO_PAYMENTDATE',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'xero_reference',
            'label' => 'LBL_XERO_REFERENCE',
          ),
          1 => 
          array (
            'name' => 'xero_isreconciled',
            'label' => 'LBL_XERO_ISRECONCILED',
          ),
        ),
        8 => 
        array (
          0 => 'description',
        ),
      ),
    ),
  ),
);
?>
