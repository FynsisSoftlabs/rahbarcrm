<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
header('Content-Type: application/json');
require_once 'custom/FynRahbarInsight/fyn_setup_lib.php';

function fynSetupRespond(array $data)
{
    echo json_encode($data);
    exit;
}

// Returns targets whose directory can't be created or written to.
function fynUnwritableTargets(array $targets)
{
    $bad = [];
    foreach ($targets as $target) {
        $dir = dirname($target);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true)) {
            $bad[] = $target;
            continue;
        }
        if (file_exists($target) ? !is_writable($target) : !is_writable($dir)) {
            $bad[] = $target;
        }
    }
    return $bad;
}

function fynPermissionMessage(array $paths)
{
    $root = realpath('.') ?: getcwd();
    $dirs = array_unique(array_map('dirname', $paths));
    return 'Rahbar could not write the required files because the web server does not have write permission on: '
        . implode(', ', $paths) . '. '
        . 'Please make sure these folders exist and are writable by the web server user (e.g. www-data / apache), '
        . 'for example: chown -R www-data:www-data ' . implode(' ', array_map(function ($d) use ($root) {
            return $root . '/' . $d;
        }, $dirs))
        . ' && chmod -R 775 ' . implode(' ', array_map(function ($d) use ($root) {
            return $root . '/' . $d;
        }, $dirs))
        . '. Then open the chat again and resubmit.';
}

function fynPostToCentral(array $fields)
{
    if (function_exists('curl_init')) {
        $ch = curl_init(FYN_ACTIVATION_URL);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($fields),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_CONNECTTIMEOUT => 15,
            // Follow redirects (http->https, www) and keep POSTing on 301/302/303
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_POSTREDIR      => CURL_REDIR_POST_ALL,
        ]);
        $body = curl_exec($ch);
        $err = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        if ($body === false) {
            throw new Exception('Could not reach the RahbarCRM activation server: ' . $err);
        }
    } else {
        $httpCode = 0;
        $finalUrl = FYN_ACTIVATION_URL;
        $ctx = stream_context_create(['http' => [
            'method'  => 'POST',
            'header'  => 'Content-Type: application/x-www-form-urlencoded',
            'content' => http_build_query($fields),
            'timeout' => 60,
        ]]);
        $body = @file_get_contents(FYN_ACTIVATION_URL, false, $ctx);
        if ($body === false) {
            throw new Exception('Could not reach the RahbarCRM activation server (enable PHP cURL or allow_url_fopen).');
        }
    }

    $data = json_decode($body, true);
    if (!is_array($data)) {
        $snippet = substr(trim(preg_replace('/\s+/', ' ', strip_tags((string)$body))), 0, 300);
        $GLOBALS['log']->fatal("Rahbar Activation: non-JSON response (HTTP {$httpCode}) from {$finalUrl}: " . substr((string)$body, 0, 2000));
        throw new Exception("Invalid response from the RahbarCRM activation server (HTTP {$httpCode}, {$finalUrl})"
            . ($snippet !== '' ? ": {$snippet}" : ': empty response') . '. Please contact support.');
    }
    return $data;
}

$action = $_REQUEST['action'] ?? 'status';

if ($action === 'status') {
    $missing = fynMissingFiles();
    fynSetupRespond(['success' => true, 'installed' => empty($missing), 'missing' => $missing]);
}

if ($action !== 'activate' || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    fynSetupRespond(['success' => false, 'message' => 'Invalid request.']);
}

try {
    $missing = fynMissingFiles();
    if (empty($missing)) {
        fynSetupRespond(['success' => true, 'installed' => true, 'message' => 'Rahbar is already activated.']);
    }

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fynSetupRespond(['success' => false, 'message' => 'Please enter your name and a valid email address.']);
    }

    // Check permissions before submitting, so the user can fix them first
    $unwritable = fynUnwritableTargets($missing);
    if (!empty($unwritable)) {
        fynSetupRespond(['success' => false, 'permission_error' => true, 'message' => fynPermissionMessage($unwritable)]);
    }

    $fields = ['missing_files' => implode(',', $missing)];
    foreach (['name', 'company', 'phone', 'email', 'url', 'base_url', 'timezone', 'language', 'platform', 'screen_width', 'user_agent'] as $key) {
        $fields[$key] = trim((string)($_POST[$key] ?? ''));
    }

    $central = fynPostToCentral($fields);
    if (empty($central['success'])) {
        throw new Exception($central['message'] ?? 'Activation was rejected by the RahbarCRM server.');
    }
    if (empty($central['files']) || !is_array($central['files'])) {
        throw new Exception('The RahbarCRM server did not return the required files.');
    }

    // Decode and verify everything before writing anything
    $toWrite = [];
    foreach (FYN_REQUIRED_FILES as $fileName => $target) {
        if (!in_array($target, $missing, true)) {
            continue;
        }
        $file = $central['files'][$fileName] ?? null;
        $content = is_array($file) ? base64_decode($file['content'] ?? '', true) : false;
        if ($content === false || $content === '' || !hash_equals((string)($file['sha256'] ?? ''), hash('sha256', $content))) {
            throw new Exception("Received file {$fileName} is missing or corrupted. Please try again.");
        }
        $toWrite[$target] = $content;
    }

    $failed = [];
    foreach ($toWrite as $target => $content) {
        if (@file_put_contents($target, $content, LOCK_EX) !== strlen($content)) {
            $failed[] = $target;
        }
    }
    if (!empty($failed)) {
        fynSetupRespond(['success' => false, 'permission_error' => true, 'message' => fynPermissionMessage($failed)]);
    }

    // Final verification
    clearstatcache();
    $stillMissing = fynMissingFiles();
    if (!empty($stillMissing)) {
        fynSetupRespond(['success' => false, 'permission_error' => true, 'message' => fynPermissionMessage($stillMissing)]);
    }
    foreach ($toWrite as $target => $content) {
        if (hash_file('sha256', $target) !== hash('sha256', $content)) {
            throw new Exception("File {$target} was not saved correctly. Please check disk space and permissions.");
        }
        if (function_exists('opcache_invalidate')) {
            @opcache_invalidate($target, true);
        }
    }

    fynSetupRespond([
        'success'   => true,
        'installed' => true,
        'message'   => $central['message'] ?? 'Rahbar has been activated successfully.',
    ]);
} catch (Exception $e) {
    $GLOBALS['log']->fatal('Rahbar Activation Error: ' . $e->getMessage());
    fynSetupRespond(['success' => false, 'message' => $e->getMessage()]);
}
