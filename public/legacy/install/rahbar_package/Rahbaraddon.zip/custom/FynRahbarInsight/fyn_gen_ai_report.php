<?php
error_reporting(E_ALL);
ini_set("dispay_errors", 1);
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
global $db;
/* ================================
   1. GET QUERY
================================ */
$query = urldecode(html_entity_decode($_GET['query'] ?? ''));
if(!$query){
    echo "<h3>No query provided</h3>";
    exit;
}
/* ================================
   2. REMOVE LIMIT
================================ */
$query = preg_replace('/\s+LIMIT\s+\d+(\s*,\s*\d+)?/i','',$query);
/* ================================
   3. SECURITY
================================ */
if(!preg_match('/^\s*SELECT/i',$query)){
    echo "<h3>Only SELECT queries allowed</h3>";
    exit;
}
/* ================================
   4. PAGINATION
================================ */
$page = max(1,(int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page-1)*$perPage;
/* total count */
$countQuery = "SELECT COUNT(*) total FROM ($query) AS t";
$countRes = $db->query($countQuery);
$totalRows = (int)$db->fetchByAssoc($countRes)['total'];
$totalPages = ceil($totalRows / $perPage);
/* apply pagination */
$query .= " LIMIT $offset,$perPage";
/* ================================
   5. DETECT AGGREGATE
================================ */
$isAggregate = preg_match('/GROUP\s+BY/i',$query);
$isPureAggregate = false;
if($isAggregate){
    $selectPart = preg_replace('/SELECT\s+(.*?)\s+FROM\s+.*/is','$1',$query);
    $columns = explode(',', $selectPart);
    if(count($columns) == 2){
        if(
            preg_match('/COUNT\s*\(/i',$columns[1]) ||
            preg_match('/COUNT\s*\(/i',$columns[0])
        ){
            $isPureAggregate = true;
        }
    }
}
/* ================================
   6. EXECUTE QUERY
================================ */
$result = $db->query($query);
$data=[];
$headers=[];
while($row=$db->fetchByAssoc($result)){
    if(empty($headers)){
        $headers=array_keys($row);
    }
    $data[]=$row;
}
if(empty($data)){
    echo "<h3>No records found</h3>";
    exit;
}
/* ================================
   7. PREPARE CHART
================================ */
$chartLabels=[];
$chartValues=[];
if($isAggregate){
    $labelCol=$headers[0];
    $valueCol=$headers[1];
    foreach($data as $row){
        $chartLabels[]=$row[$labelCol];
        $chartValues[]=(int)$row[$valueCol];
    }
}
/* ================================
   8. LOAD RGRAPH
================================ */
require_once 'include/SuiteGraphs/RGraphIncludes.php';
/* ================================
   9. SUITECRM VERSION DETECTION
================================ */
global $sugar_config;
$suiteVersion = $sugar_config['sugar_version'] ?? '7';
$isSuite8 = version_compare($suiteVersion,'8','>=');
/* ================================
   10. DETECT MODULE FROM QUERY
================================ */
$module = '';
if(preg_match('/FROM\s+([a-zA-Z0-9_]+)/i',$query,$m)){
    $table = $m[1];
    // basic mapping
    $tableModuleMap = [
        'leads' => 'Leads',
        'accounts' => 'Accounts',
        'contacts' => 'Contacts',
        'opportunities' => 'Opportunities',
        'cases' => 'Cases',
        'meetings' => 'Meetings',
        'calls' => 'Calls',
        'tasks' => 'Tasks'
    ];
    $module = $tableModuleMap[strtolower($table)] ?? '';
}
/* ================================
   11. DETECT RECORD ID FIELD
================================ */
$recordIdField = '';
foreach($headers as $h){
    if(strtolower($h) == 'id' || preg_match('/_id$/i',$h)){
        $recordIdField = $h;
        break;
    }
}
?>
<style>
/* header */
.fyn-header{
background:#b71c1c;
color:white;
padding:10px 15px;
font-size:18px;
font-weight:bold;
margin-bottom:10px;
}
/* table */
.fyn-table{
width:100%;
border-collapse:collapse;
background:white;
}
.fyn-table th{
background:#f5f5f5;
border:1px solid #ddd;
padding:8px;
font-weight:bold;
text-align:left;
}
.fyn-table td{
border:1px solid #e5e5e5;
padding:7px;
}
.fyn-table tr:nth-child(even){
background:#fafafa;
}
/* pagination */
.fyn-pagination{
    display:flex;
    flex-wrap:wrap;
    gap:6px;
    margin-top:10px;
}
.fyn-pagination a{
    padding:5px 10px;
    border:1px solid #ccc;
    text-decoration:none;
    border-radius:4px;
    font-size:13px;
    color:#333;
}
.fyn-pagination a.active{
    background:#0073ea;
    color:white;
    border-color:#0073ea;
    font-weight:bold;
}
.fyn-pagination a.nav{
    font-weight:bold;
}
.fyn-pagination a:hover{
    background:#f3f3f3;
}
</style>
<div class="fyn-header">
	AI Generated Report
</div>
<div class="fyn-container">
<?php if(!$isPureAggregate){ ?>
<table class="fyn-table">
<tr>
<?php
foreach($headers as $h){
    if(strtolower($h) == 'id' || preg_match('/_id$/i',$h)){
        continue;
    }
    echo "<th>".htmlspecialchars($h)."</th>";
}
echo "<th></th>"; // open icon column
?>
</tr>
<?php
foreach($data as $row){
	echo "<tr>";
	$recordId = $row[$recordIdField] ?? '';
	foreach($headers as $h){
	    if(strtolower($h) == 'id' || preg_match('/_id$/i',$h)){
	        continue;
	    }
	    echo "<td>".htmlspecialchars($row[$h])."</td>";
	}
	/* ================================
	   DETAIL VIEW LINK
	================================ */
	$link='';
	if($recordId && $module){
	    if($isSuite8){
	        $link = "#/module/$module/$recordId";
	    }else{
	        $link = "index.php?module=$module&action=DetailView&record=$recordId";
	    }
	}
	echo "<td style='text-align:center'>";
	if($link){
	    echo "<a href='$link' target='_blank' title='Open Record'>↗</a>";
	}
	echo "</td>";
	echo "</tr>";
}
?>
</table>
<div class="fyn-pagination">
<?php
$baseUrl = "index.php?entryPoint=fyngenaireport&query=".urlencode($_GET['query']);
if($page > 1){
    echo "<a class='nav' href='{$baseUrl}&page=".($page-1)."'>Prev</a>";
}
for($p = 1; $p <= $totalPages; $p++){
    $class = ($p == $page) ? "active" : "";
    echo "<a class='$class' href='{$baseUrl}&page=$p'>$p</a>";
}
if($page < $totalPages){
    echo "<a class='nav' href='{$baseUrl}&page=".($page+1)."'>Next</a>";
}
?>
</div>
<?php } ?>
</div>