<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

if (!defined('FYN_ACTIVATION_URL')) {
    // Central RahbarCRM activation endpoint (rahbarcrmform entrypoint)
    define('FYN_ACTIVATION_URL', 'https://crm.fynsis.com/legacy/index.php?entryPoint=rahbarcrmform');

    // Files delivered on activation: name in central response => local target path.
    // Targets are fixed here; paths sent by the server are never trusted.
    define('FYN_REQUIRED_FILES', [
        'FynTriaging.php' => 'custom/Fyntriaging/FynTriaging.php',
        'fynquery.php'    => 'custom/FynRahbarInsight/fynquery.php',
    ]);
}

if (!function_exists('fynMissingFiles')) {
    function fynMissingFiles()
    {
        clearstatcache();
        $missing = [];
        foreach (FYN_REQUIRED_FILES as $target) {
            if (!is_file($target) || filesize($target) === 0) {
                $missing[] = $target;
            }
        }
        return $missing;
    }
}
