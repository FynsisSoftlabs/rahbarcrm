<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once 'custom/FynRahbarInsight/fyn_setup_lib.php';

/*
 * Include at the top of a config page:
 *   if (require 'custom/FynRahbarInsight/fyn_activation_gate.php') return;
 * Returns true (and renders the activation form) when required files are missing.
 */

if (empty(fynMissingFiles())) {
    return false;
}
?>
<style>
    .fyn-activate { max-width: 460px; margin: 30px auto; padding: 24px; background: #fff; border: 1px solid #ddd; border-radius: 8px; font-family: inherit; }
    .fyn-activate h2 { margin: 0 0 6px; }
    .fyn-activate p { color: #666; font-size: 13px; margin: 0 0 16px; }
    .fyn-activate label { display: block; font-size: 13px; font-weight: bold; margin-bottom: 10px; }
    .fyn-activate input { display: block; width: 100%; box-sizing: border-box; padding: 8px; margin-top: 4px; border: 1px solid #ccc; border-radius: 4px; }
    .fyn-activate button { padding: 9px 20px; background: #e81515; color: #fff; border: none; border-radius: 4px; cursor: pointer; }
    .fyn-activate button:disabled { background: #ccc; cursor: not-allowed; }
    .fyn-activate-msg { display: none; font-size: 13px; padding: 10px; border-radius: 4px; margin-bottom: 12px; word-break: break-word; }
    .fyn-activate-msg.error { display: block; background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; }
    .fyn-activate-msg.info { display: block; background: #f0fdf4; color: #15803d; border: 1px solid #bbf7d0; }
</style>
<form class="fyn-activate" id="fyn-activate-form">
    <h2>Activate Rahbar</h2>
    <p>A few required components are missing. Share your details to activate Rahbar AI features on this CRM.</p>
    <label>Name *<input name="name" required maxlength="100"></label>
    <label>Company<input name="company" maxlength="150"></label>
    <label>Phone<input name="phone" type="tel" maxlength="30"></label>
    <label>Email *<input name="email" type="email" required maxlength="150"></label>
    <div class="fyn-activate-msg"></div>
    <button type="submit">Activate</button>
</form>
<script>
(function () {
    const form = document.getElementById('fyn-activate-form');
    const msg = form.querySelector('.fyn-activate-msg');
    const btn = form.querySelector('button');
    const endpoint = 'index.php?entryPoint=fynsetup';

    function show(type, text) {
        msg.className = 'fyn-activate-msg ' + type;
        msg.textContent = text;
    }

    form.addEventListener('submit', async function (e) {
        e.preventDefault();
        btn.disabled = true;
        btn.textContent = 'Activating…';
        msg.className = 'fyn-activate-msg';

        const body = new URLSearchParams(new FormData(form));
        body.set('action', 'activate');
        body.set('url', window.top.location.href);
        body.set('base_url', new URL('.', window.location.href).href);
        body.set('timezone', Intl.DateTimeFormat().resolvedOptions().timeZone || '');
        body.set('language', navigator.language || '');
        body.set('platform', (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || '');
        body.set('screen_width', String(window.screen.width));
        body.set('user_agent', navigator.userAgent);

        try {
            const res = await fetch(endpoint, { method: 'POST', body: body });
            const data = await res.json();
            if (!data.success) {
                show('error', data.message || 'Activation failed. Please try again.');
                return;
            }

            // Final check that the files are actually in place
            const status = await (await fetch(endpoint + '&action=status')).json();
            if (!status.installed) {
                show('error', 'Activation completed but these files are still missing: ' + status.missing.join(', ') + '. Please check write permissions on the CRM\'s custom/ folder and try again.');
                return;
            }

            show('info', (data.message || 'Rahbar activated successfully.') + ' Loading settings…');
            setTimeout(function () { window.location.reload(); }, 1500);
        } catch (err) {
            console.error('Rahbar: activation failed', err);
            show('error', 'Could not complete activation. Please refresh the page, log in again and retry.');
        } finally {
            btn.disabled = false;
            btn.textContent = 'Activate';
        }
    });
})();
</script>
<?php
return true;
