<?php
// echo "<pre>";
// print_r($_SESSION);
// exit;
// error_reporting(E_ALL);
// ini_set("display_errors", 1);

require_once 'modules/ACL/ACLController.php';
header('Content-Type: application/json');
// unset($_SESSION['aiconversation']);
// unset($_SESSION['sql_history']);
// exit;
require_once('include/entryPoint.php');

global $sugar_config, $db, $dictionary;
$question = $_GET['question'] ?? '';
$idmodule = $_GET['idmodule'] ?? '';
$feedback = $_GET['feedback'] ?? '';
$queryModel = $_GET['model'] ?? '';
$questionSafe = $db->quote($question);
if(!empty($feedback)){
    $db->query("UPDATE fyn_rahbar_logs SET is_correct=1 WHERE name='{$questionSafe}' and deleted=0 ORDER BY date_entered DESC LIMIT 1");
    exit;
}
$existingResult = $db->query("SELECT `generated_query` FROM fyn_rahbar_logs WHERE name = '{$questionSafe}' AND is_correct = 1 AND deleted = 0 LIMIT 1");
$existingQuery = $db->fetchByAssoc($existingResult) ?: [];
if(!empty($existingQuery))
$existingQuestion['query'] = html_entity_decode($existingQuery['generated_query'], ENT_QUOTES);

// Session for memory
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$_SESSION['request_start_time'] = microtime(true);
if (!isset($_SESSION['sql_history'])) {
    $_SESSION['sql_history'] = [];
}
if(isset($_SESSION['aiconversation']) && !empty($_SESSION['aiconversation'])){
    if (!isset($_SESSION['aiconversation']['history'])) {
        $_SESSION['aiconversation']['history'] = [];
    }
    $_SESSION['aiconversation']['history'][] = ["role" => "user","content" => $question];
    $question = $_SESSION['aiconversation']['original_question'];
}
if (empty($question) && empty($idmodule)) {
    die(json_encode([
        'success' => false,
        'response' => 'No question provided',
    ]));
}

if (!empty($idmodule)) {
    $idmoduleObj = json_decode(html_entity_decode($idmodule));
    if (!$idmoduleObj || empty($idmoduleObj->module) || empty($idmoduleObj->id)) {
        die(json_encode([
            'success' => false,
            'response' => 'Invalid module payload.'
        ]));
    }
    $module = ucfirst($idmoduleObj->module);
    $id = $idmoduleObj->id;
    $bean = BeanFactory::getBean($module, $id);
    $tool_results = json_encode($bean->fetched_row);
    $response = summarizeResults($tool_results, $bean->name);
    die(json_encode([
        'success' => true,
        'response' => $response,
    ]));
}
// Stage 1: Decide action (SQL vs Reply)
if (empty($existingQuestion)) {
    $decision = askGPTForIntent($question, $queryModel);
}else{
    $decision = ['action'  => 'sql', 'payload' => $existingQuestion['query']];
}
// Stage 2: Run query if SQL
$tool_results = null;
if (($decision['action'] ?? '') === 'sql') {
    $tool_results = runSQLQuery($decision['payload'], $question, $decision['is_aggregate'], $decision['count_query']);
}
// Stage 3: Summarize if SQL
$response = ($decision['action'] === 'sql') ? summarizeResults($tool_results, $question) : $decision['payload'];
$showFeedback = ($decision['action'] === 'sql') && empty($existingQuery);
$_SESSION['sql_history'][] = [['role'=>'user', 'content'=>$question], ['role'=>'assistant', 'content'=>$response]];
$maxHistory = 2;
if (count($_SESSION['sql_history']) > $maxHistory) {
    $_SESSION['sql_history'] = array_slice($_SESSION['sql_history'], -$maxHistory);
}
echo json_encode([
    'success' => true,
    'response' => $response,
    'feedback' => $showFeedback
]);
/* Decide SQL or reply */
function askGPTForIntent($question, $queryModel) {
    global $sugar_config;
    $modules = isset($sugar_config['fyn_rahbar_modules']) && !empty($sugar_config['fyn_rahbar_modules']) ? unserialize($sugar_config['fyn_rahbar_modules']) : '';
    if(empty($modules)){
        die(json_encode([
            'success' => false,
            'response' => 'Please select the relevant modules in the configuration',
        ]));
    }
    $moduleList = implode(",", $modules);
    $intentprompt = "You are SQL finder, who chats with the user naturally, but if you sense that the question is related to data that needs an SQL query to be executed to answer, choose action = 'SQL'
        Available modules: $moduleList. Use one of these modules only. 
        If the question contains business terms that could have multiple interpretations (e.g., contacted, active, engaged, hot, inactive, recent), choose action = 'followup'
        Detect whether it is a follow-up question, If it is a follow-up, rewrite it into a fully standalone question preserving previous context.

        IMPORTANT DEFAULT CRM DEFINITIONS:
        - 'contacted' means at least one related Call, Meeting, Email, or Completed Task exists.
        - 'inactive' means no related activity exists.
        - 'recent' means within last 30 days unless otherwise specified.
        - 'older than X days' refers to date_entered field.
        - 'active leads' means leads not deleted.

        Do NOT ask follow-up questions for these standard CRM terms.
        Only ask follow-up if:
        - The request is logically impossible
        - The module is unclear
        - A required filter is completely missing
        - The question contradicts itself";
    $input = [];
    if(isset($_SESSION['aiconversation']) && !empty($_SESSION['aiconversation'])){
        if (($_SESSION['aiconversation']['followup_counter'] ?? 0) > 2){
            unset($_SESSION['aiconversation']);
            return [
                'action' => 'reply',
                'payload' => 'I still need more clarity to generate an accurate query. Please rephrase your request with more detail.'
            ];
        }
    }
    $input[] = [
        "role" => "system",
        "content" => $intentprompt
    ];
    if (!empty($_SESSION['sql_history'])) {
        foreach ($_SESSION['sql_history'] as $pair) {
            foreach ($pair as $msg) {
                $input[] = ["role" => $msg['role'], "content" => $msg['content']];
            }
        }
    }
    if(isset($_SESSION['aiconversation']) && !empty($_SESSION['aiconversation'])){
        foreach($_SESSION['aiconversation']['history'] as $msg){
            $input[] = ["role"=>$msg['role'], "content"=>$msg['content']];
        }
    }    
    $input[] = ["role" => "user", "content" => $question];
    $body = [
        "temperature" => 0,
        "input" => $input,
        "tools" => [
            [
                "type" => "function",
                "name" => "intent_decision",
                "description" => "Decides whether SQL is required",
                "parameters" => [
                    "type" => "object",
                    "properties" => [
                        "action" => [
                            "type" => "string",
                            "enum" => ["SQL","reply","followup"]
                        ],
                        "modules" => [
                            "type" => "array",
                            "items" => ["type" => "string"],
                            "description" => "List of relevant CRM modules strictly required to answer the question. Empty if reply or followup."
                        ],
                        "reply_text" => [
                            "type" => "string",
                            "description" => "Natural conversational reply and in friendly tone and uses emojis appropriately. Empty if SQL."
                        ],
                        "followup" => [
                            "type" => "string",
                            "description" => "follow-up question to the user to remove ambiguity from original question. don't ask open ended questions, ask suggestive questions as to what user could mean."
                        ],
                        "is_followup" => [
                            "type" => "boolean",
                            "description" => "True if this question depends on previous context."
                        ],
                        "standalone_question" => [
                            "type" => "string",
                            "description" => "Rewritten full standalone version of the user's request."
                        ],
                    ],
                    "required" => ["action"]
                ]
            ]
        ],
        "tool_choice" => [
            "type" => "function",
            "name" => "intent_decision"
        ]
    ];
    $data = callOpenAI("gpt-4o-mini", $body, $question,"Check-Intent");
    $arguments = '';
    $parsed = array();
    if (isset($data['output'][0]['type']) && $data['output'][0]['type'] === 'function_call') {
        $arguments = $data['output'][0]['arguments'] ?? '{}';
        $parsed = json_decode($arguments, true);
        if (!is_array($parsed) || empty($parsed['action'])) {
            die(json_encode([
                'success' => false,
                'response' => 'Invalid AI response format.'
            ]));
        }
        $action = $parsed['action']; 
        // if(!empty($parsed['is_followup']) && !empty($parsed['standalone_question'])){
            $question = $parsed['standalone_question'];
        // }    
    }else{
        die(json_encode([
            'success' => false,
            'response' => 'Sorry, I couldn\'t understand the request',
        ]));
    }
    if($action === 'followup'){
        if(isset($_SESSION['aiconversation']) && !empty($_SESSION['aiconversation'])){
            $_SESSION['aiconversation']['followup_counter'] = $_SESSION['aiconversation']['followup_counter']+1;
        }else{
            $_SESSION['aiconversation']['original_question'] = $question;
            $_SESSION['aiconversation']['followup_counter'] = 1;
        }
        if (!isset($_SESSION['aiconversation']['history'])) {
            $_SESSION['aiconversation']['history'] = [];
        }
        $_SESSION['aiconversation']['history'][] = ["role" => "assistant","content" => $parsed['followup']];
        return ['action'=>'reply','payload'=>$parsed['followup']];
    }
    if ($action === 'SQL'){
        unset($_SESSION['aiconversation']);
        $relevant_modules = $parsed['modules'] ?? [];
        foreach ($relevant_modules as $module) {
            if (!ACLController::checkAccess($module, 'list', true)) {
                die(json_encode([
                    'success' => false,
                    'response' => "Sorry, you don't have access to $module module",
                ]));
            }
        }
        return askGPTForSQLAction($question, $relevant_modules, $queryModel);
    }
    $content = $parsed['reply_text'] ?? 'I could not generate a proper response.';
    return ['action'=>'reply','payload'=>$content];
}
function askGPTForSQLAction($question, $relevant_modules, $queryModel) {
    global $db, $sugar_config, $current_user;
    $currentUserId = $current_user->id ?? '1';
    $db_structure_str = json_encode(getDatabaseStructure($relevant_modules), JSON_UNESCAPED_UNICODE);
    $fixedPrompt = "You are a senior SuiteCRM Database Architect and MySQL expert.

    Your responsibility:
    - Generate logically correct and performance-aware MySQL queries.
    - Use ONLY the provided database schema.
    - Never assume fields or relationships that are not present in schema.
    - Never hallucinate tables or columns.
    - Always apply minimum required logic to answer the question accurately.

    Before answering you must critically evaluate:
    1. Does the query EXACTLY answer the user's question?
    2. Is any business meaning misinterpreted?
    3. Does the query use shortcuts that change semantics?
    4. Does the query assume business logic incorrectly?
    5. Would this query return results that contradict the question intent?

    CRM Semantic Rules:
    - \"Contacted\" means at least one related activity exists (Calls, Meetings, Emails, Completed Tasks).
    - Do NOT infer contact status from phone/email fields alone.
    - Always fetch id (primary_key) fields in the select parameters, use relevant join to fetch correct columns (ex: for assigned_user_id join users table to fetch first_name, last_name from users table and join with assigned_user_id=users.id)
    - When concatenating fields, always use CONCAT_WS() instead of CONCAT() to avoid NULL results.
    - If the question includes \"my\" or ownership filter, use the id \"$currentUserId\" for the relevant columns ex:assigned_user_id or created_by etc.
    -For activities (Calls, Meetings, Tasks, Emails), do NOT assume only relationship tables exist. Always check parent_type + parent_id relationships as well.
    Activity Relationship Rules:
    - Calls, Meetings, Tasks, and Emails can be linked to modules in two ways:
        1) Relationship tables (e.g., calls_leads, meetings_contacts)
        2) Generic parent relationship using parent_type and parent_id fields.
    - When checking whether a record has related activities,
      ALWAYS consider BOTH mechanisms.
    - Example for Leads:
        calls_leads.lead_id = leads.id
        OR (calls.parent_type = 'Leads' AND calls.parent_id = leads.id)
    - Queries that check existence or absence of activities must evaluate both link mechanisms.

    Relationship Resolution Rules:
    - If a field is a foreign key (e.g., assigned_user_id, created_by, modified_user_id, account_id, contact_id),
        you MUST join the related table to fetch a human-readable identifier.
    - Never display raw UUID or id values in result sets.
    - When grouping by a foreign key, join the related table and group by the foreign key,
        but SELECT a readable identifier such as:
        - users.first_name + users.last_name
        - accounts.name
        - contacts.first_name + contacts.last_name
        - Always ensure deleted = 0 condition on joined tables where applicable.

    Query Rules:
    - Custom tables (_cstm) use id_c as the join key. id_c matches the id of the main module table. Join using: <module>.id = <module>_cstm.id_c
    - you must determine the expected result structure based on the user's question.
        - SCALAR_AGGREGATE:
            - Generate a single-row aggregate query.
            - NEVER use GROUP BY.
        - GROUPED_AGGREGATE:
            - Use GROUP BY.
            - Join related tables for readable identifiers.
        - RECORD_RETRIEVAL:
            - Use LIMIT 10.
            - Also generate count_query.
    - Prefer ordering by date_modified DESC or date_entered DESC when relevant.
    - For SCALAR_AGGREGATE queries, do not generate count_query.
    - Set is_aggregate = true only when the main query itself is an aggregate.
    - Users refer to fields and enum values using their display labels. 
    - You must always map labels to their corresponding database column names and enum keys before generating SQL. Never use labels inside SQL queries.
    - When filtering text or enum values, perform case-insensitive comparison using LOWER(). Do not modify column names. Only normalize user-provided values (trim spaces and compare in lowercase).
    - Never apply LOWER() to id column or numeric, date, or boolean fields.
    - If a field has possible_values, the database stores the ENUM KEY (array key), not the display label (array value).
    - When filtering enum fields, ALWAYS use the enum key.
    - NEVER use display labels inside SQL.
    - If user provides a label, map it to its corresponding enum key before generating SQL.
    - If the column/field does not have possible_values. Use safer queries for filter (ex: status='yet to start' -> status='yet to start' OR status='yet_to_start')
    - if checking for emptiness or nullness always check null and '' (empty string)

    Audit / Field Movement Rules
    Some modules may have audit tables that track field history. Audit tables follow the naming pattern:
    <module_table>_audit
    These tables contain:
    id, parent_id, date_created, created_by, field_name, data_type,
    before_value_string, after_value_string, before_value_text, after_value_text
    If an audit table is present in the provided database schema, use it to answer questions related to field movement or history.
    Movement indicators include:
    changed, moved, became, transitioned, progressed, updated from, updated to,
    status change, stage change, disposition change, history, previous value.
    Rules when using audit tables:
    - Join main table using: <module>.id = <module>_audit.parent_id
    - Filter the tracked field using: field_name = '<column>'
    - Movement TO value → after_value_string = '<value>'
    - Movement FROM value → before_value_string = '<value>'
    - Transition FROM X TO Y →
      before_value_string = '<x>' AND after_value_string = '<y>'
    - Movement time must use audit_table.date_created
    - Always apply deleted = 0 on the main module table
    - For counts prefer COUNT(DISTINCT parent_id) to avoid duplicate movements

    Output Rules:
    - Return ONLY valid JSON.
    - Do NOT include explanations.
    - JSON must follow this format:

    {
      \"action\": \"sql\",
      \"query\": \"<valid_mysql_query>\"
      \"is_aggregate\": <true_or_false>,
      \"count_query\": \"<count_query_or_null>\"
    }";
    $dynamicPrompt = $sugar_config['fyn_rahbar_prompt'];
    $inputArray = array();
    $inputArray[] = ["role" => "system", "content" => $fixedPrompt ."\n\n". $dynamicPrompt];
    if($queryModel != 'gpt-5'){
        $inputArray[] = ["role" => "system", "content" => $db_structure_str];
    }
    $inputArray[] = ["role" => "user", "content" => $question];
    $bodyArray = [
        "input" => $inputArray,
        "text" => [
            "format" => [
                "type" => "json_object"
            ]
        ],
        "max_output_tokens" => 3500
    ];
    if (strpos($queryModel, 'gpt-5') !== 0) {
        $bodyArray["temperature"] = 0;
        $questionSafe = $db->quote($question);
        $db->query("UPDATE fyn_rahbar_logs SET is_correct='-1' WHERE name='{$questionSafe}' and deleted=0 ORDER BY date_entered DESC LIMIT 1");
    }
    $queryModel = $queryModel ?: "gpt-4.1-mini";
    $data = callOpenAI($queryModel, $bodyArray, $question,"Generate Query");
    $content = trim($data['output_text'] ?? '{}');
    if ($data['status'] === 'incomplete') {
        die(json_encode([
            'success' => false,
            'response' => 'AI response truncated. Increase max_output_tokens.',
        ]));
    }
    if(isset($data['output'][0]['content']) && !empty($data['output'][0]['content'])){
        $content = trim($data['output'][0]['content'][0]['text'] ?? '{}');
    }elseif (!empty($data['output_text'])) {
        $content = trim($data['output_text']);
    }elseif (!empty($data['output'][1]['content'])) {
        $content = trim($data['output'][1]['content'][0]['text'] ?? '{}');
    }else{
        die(json_encode([
            'success' => false,
            'response' => 'Could not determine the API response while generating query'
        ]));
    }
    $content_array = json_decode($content, true);
    // print_r($content_array);
    // echo "<br><br>";
    $query = $content_array['query'] ?? '';
    $is_aggregate = $content_array['is_aggregate'] ?? '';
    $count_query = $content_array['count_query'] ?? '';
    $query = preg_replace('/^```[a-zA-Z]*\s*/', '', $query);
    $query = preg_replace('/```$/', '', $query);
    $query = trim($query);
    $count_query = preg_replace('/^```[a-zA-Z]*\s*/', '', $count_query);
    $count_query = preg_replace('/```$/', '', $count_query);
    $count_query = trim($count_query);
    return ['action'=>'sql','payload'=>$query, 'is_aggregate'=>$is_aggregate, 'count_query'=>$count_query];
}

/*** Run query */
function runSQLQuery($sql, $question, $is_aggregate='', $count_query='') {
    global $db;
    // $decodedDecision = json_decode($sqldecision, true);
    // if (!is_array($decodedDecision) || empty($decodedDecision['query'])) {
    //     die(json_encode([
    //         'success' => false,
    //         'response' => 'Invalid SQL payload.'
    //     ]));
    // }
    // $sql = trim($decodedDecision['query']);
    if (!preg_match('/^\s*(SELECT|WITH)\s/i', $sql)) {
        die(json_encode([
            'success' => false,
            'response' => 'Only SELECT queries allowed.',
        ]));
    }
    $blockedPatterns = ['/;\s*(DELETE|UPDATE|INSERT|DROP|ALTER|TRUNCATE)/i','/\bINTO\s+OUTFILE\b/i','/\bLOAD_FILE\b/i'];
    foreach ($blockedPatterns as $pattern) {
        if (preg_match($pattern, $sql)) {
            die(json_encode([
                'success' => false,
                'response' => 'Disallowed SQL pattern detected.',
            ]));
        }
    }
    $sql = rtrim($sql, ";");
    try{
        $result = $db->query($sql);
        if(empty($is_aggregate) && !empty($count_query)){
            $count_result = $db->query($count_query)->fetch_array()[0];
        }
    } catch (\Exception $e) {
        generateDBlog($question, 'error', $db->quote($e->getMessage()));
        die(json_encode([
            'success' => false,
            'response' => $e->getMessage(),
        ]));
        exit;
    }
    $rows = [];
    $output = [];
    while ($row = $db->fetchByAssoc($result)) {
        $rows[] = $row;
    }
    $output["query"] = $sql;
    $output["row_count"] = $result->num_rows;
    $output["rows"] = $rows;
    if(empty($is_aggregate) && !empty($count_query)){
        $output["is_aggregate"] = false;
        $output["query_count"] = $count_result ?? '';
    }
    // print_r($output);
    return $output;
}

/*** Summarize SQL results */
function summarizeResults($tool_results, $question) {
    $query = "";
    $row_count = 0;
    $rows = array();
    $rowlimit = 10;
    if(isset($tool_results) && !empty($tool_results)){
        $query = $tool_results["query"] ?? '';
        $row_count = (int)$tool_results["row_count"];
        if(isset($tool_results["query_count"])){
            $row_count = (int)$tool_results["query_count"];
        }
        if(isset($tool_results["rows"]) && !empty($tool_results["rows"])){
            $rows = $tool_results["rows"];
            // if($row_count > $rowlimit){
            //     $rows = array_slice($rows, 0, $rowlimit);
            // }
        }
    }    
    $isAggregation = (bool) preg_match('/\b(COUNT|SUM|AVG|MIN|MAX)\b/i', $query);
    $baseUrl = $getBaseUrl;
    $relevant_modules = unserialize($sugar_config['fyn_rahbar_modules']);
    $prompt = "Summarize SuiteCRM results clearly and concisely.

        Core Rules:
        - Always align the response directly with the user's question.
        - Never mention SQL, queries, tables, or database terminology.
        - Never display internal fields like id, deleted, date_modified, modified_user_id, etc.
        - Return raw HTML only.
        - Never include newline escape characters (\n).
        - Do not include explanations about how data was fetched.
        - if no records are found, instead of phrases like \"No matching records were found.\" use phrases that answers the question

        Rendering Logic (STRICT):

        1) If is_aggregation = false OR empty:
           - This is a record-based result.
           - Show query_count.
           - State how many records are being displayed (infer from dataset).
           - Render results using accordion format.
           
           Accordion Rules:
           - Generate one <details> block per row.
           - <summary> must contain the primary identifier (e.g., full_name, lead_number, name).
           - Expanded content must contain secondary fields formatted inline (NOT bullet points).
           - Do NOT wrap multiple rows inside a single <details>.
           - Do NOT include escape characters.

        2) If is_aggregation = true AND rows > 1:
           - This is a multi-row aggregate result.
           - DO NOT use accordion.
           - Render a clean HTML <table>.
           - Include column headers.
           - After the table, provide a short analytical insight paragraph.
           - The analysis MUST directly answer the user's question.
           - Highlight key findings (largest value, smallest value, biggest drop-off, trend, etc.).
           - Provide a clear concluding sentence.

        3) If is_aggregation = true AND rows = 1:
           - This is a single aggregate value.
           - DO NOT render a table.
           - Provide a direct one- or two-sentence answer.
           - Be precise and conclusive.

        4) If row_count = 0 and query_count = 0:
           - Return a short message stating no matching records were found.
           - Do not render table or accordion.

        Analysis Expectations for Aggregates:
        - Identify highest and lowest values where relevant.
        - Calculate meaningful differences when needed.
        - Explain what the numbers imply in business terms.
        - Always end with a direct conclusion sentence answering the user's question.

        Link Rules:
        1) Record Link (for accordion records):
           - Each record must include a \"View Record\" link at the end of the expanded content.
           - The \"View Record\" link should appear as the last element inside the expanded content of the accordion.
           - The link must open the SuiteCRM DetailView in a new tab using the following format:
            ".$baseUrl."index.php?action=ajaxui#ajaxUILoc=index.php%3Fmodule%3D<module_name>%26action%3DDetailView%26record%3D<record_id>
        2) View All Link (for SQL query summaries including accordion results):
           - Always include a \"View All Records\" link with an icon below the results.
           - The link must open the following page:
            ".$baseUrl."index.php?entryPoint=fyngenaireport&query=<sql_query>
        3) Module Name Rule:
            - The module name MUST come from the \"relevant_modules\" field provided in the input JSON.
            - NEVER derive the module name from SQL table names.
            - NEVER change the casing of module names.
            - If multiple modules exist in relevant_modules, determine the correct module by matching it with the table used in the SQL query.
            Example:
            SQL uses table \"leads\" → module = \"Leads\"
            SQL uses table \"accounts\" → module = \"Accounts\"
            Use the EXACT module name from relevant_modules.
        4) - Always user target=\"_blank\" and use the \"↗️\" icon when generating links

        Record ID Rule:
        The <record_id> used in DetailView links MUST come from the field named \"id\".
        If the query results do not contain an \"id\" column,
        DO NOT generate a \"View Record\" link.
        Never infer or fabricate record IDs from other fields.";


    $userData = [
        "question" => $question,
        "row_count" => $row_count,
        "showing" => min($row_count, $rowlimit),
        "query" => $query,
        "is_aggregation" => $isAggregation,
        "rows" => $rows,
        "relevant_modules" => $relevant_modules,
        "is_truncated" => $row_count > $rowlimit
    ];
    $userPrompt = json_encode($userData);
    $body = [
            "input" => [
                ["role" => "system", "content" => $prompt],
                ["role" => "user", "content" => $userPrompt]
            ],
            'temperature' => 0
        ];
    $data = callOpenAI("gpt-4o-mini", $body, $question,"Summarize Result");
    if(isset($data['output'][0]['content']) && !empty($data['output'][0]['content'])){
        $summary = trim($data['output'][0]['content'][0]['text'] ?? '{}');
    }elseif (isset($data['output_text']) && !empty($data['output_text'])) {
        $summary = trim($data['output_text']);
    }elseif (isset($data['output'][1]['content']) && !empty($data['output'][1]['content'])) {
        $summary = trim($data['output'][1]['content'][0]['text'] ?? '{}');
    }else{
        die(json_encode([
            'success' => false,
            'response' => 'Could not determine the API response while summarizing result'
        ]));
    }
    generateDBlog($question, $summary, $query);
    return $summary;
}

/*** DB structure */
function getDatabaseStructure($relevant_modules) {
    global $db, $sugar_config, $app_list_strings, $current_language, $dictionary;
    $modules = isset($relevant_modules) && !empty($relevant_modules) ? $relevant_modules : unserialize($sugar_config['fyn_rahbar_modules']);
    if(empty($modules)){
        die(json_encode([
            'success' => false,
            'response' => 'Relevant modules for answering this question could not be found. Please make sure to select modules from here <link to config page>',
        ]));
    }
    $tableList = array();
    $auditTableList = array();
    foreach ($modules as $module) {
        $bean = BeanFactory::newBean($module);
        $table = $bean->getTableName();
        $cstm_table = $table . "_cstm";
        $audit_table = $table. "_audit";
        $tables = array();
        $tables[$table] = array("fields" => array());
        $table_fields = [];
        $tableres = $db->query("DESCRIBE $table");
        while($row = $tableres->fetch_assoc()){
            $table_fields[] = $row['Field'];
        }
        if ($db->tableExists($cstm_table)) {
            $tables[$cstm_table] = array("fields" => array());
            $tableres = $db->query("DESCRIBE $cstm_table");
            while($row = $tableres->fetch_assoc()){
                $table_fields[] = $row['Field'];
            }
        }
        if($db->tableExists($audit_table)){
            $auditTableList[] = $audit_table;
        }
        $fielddefs = $bean->field_defs;
        $relationships = array();
        $moduleData = array();
        $mod_strings = return_module_language($current_language, $module);
        foreach ($fielddefs as $field_name => $field) {
            if(!in_array($field_name, $table_fields) && $field['type'] != 'link'){
                continue;
            }
            $field_info = array(
                "label" => $mod_strings[$field['vname']] ?? $field_name,
                "type" => $field['type'] ?? 'unknown'
            );
            if (isset($field['type']) && $field['type'] === 'enum' && isset($field['options'])) {
                $dom = $field['options'];
                if (isset($app_list_strings[$dom]) && is_array($app_list_strings[$dom])) {
                    if($field_name === 'vehicle_make_c' || $field_name === 'vehicle_body_c' || $field_name === 'eq_source_c' || $field_name === 'vehicle_type_c' || $field_name === 'car_registration_year_c')
                        continue;
                    $field_info['possible_values'] = $app_list_strings[$dom];
                }
            }  
            $target_table = $table;
            if (strpos($field_name, '_c') !== false) {
                $target_table = $cstm_table;
            } 
            // Only add if table exists
            if (isset($tables[$target_table])) {
                $tables[$target_table]['fields'][$field_name] = $field_info;
            }
            // Handle relationships
            if (isset($field['type']) && $field['type'] === 'link' && isset($field['relationship'])) {
                $relationship = $field['relationship'];
                if (isset($dictionary[$relationship]['table'])) {
                    $relationshipTable = $dictionary[$relationship]['table'];
                    if ($db->tableExists($relationshipTable) && !isset($relationships[$relationshipTable])) {
                        $relationships[$relationshipTable] = ["fields" => []];
                        $relationshipres = $db->query("DESCRIBE $relationshipTable");
                        while($row = $relationshipres->fetch_assoc()){
                            $relationships[$relationshipTable]['fields'][$row['Field']] = ["type" => $row['Type']];
                        }
                    }
                }
            }
        }
        $moduleData['tables'] = $tables;
        $moduleData['relationship_tables'] = array_unique($relationships);
        $moduleData['audit_tables'] = array_unique($auditTableList);
        $schema['modules'][$module] = $moduleData;
    }
    return $schema;
}
function getDatabaseStructureCached($relevant_modules) {
    $cacheFile = __DIR__ . '/db_structure_cache.json';
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile) < 86400)) {
        return json_decode(file_get_contents($cacheFile), true);
    }
    $structure = getDatabaseStructure($relevant_modules);
    file_put_contents($cacheFile, json_encode($structure));
    return $structure;
}
function getBaseUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
    $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    $posHash  = strpos($url, '#');
    $posIndex = stripos($url, 'index.php');
    $cutPos = false;
    if ($posHash !== false && $posIndex !== false) {
        $cutPos = min($posHash, $posIndex);
    } elseif ($posHash !== false) {
        $cutPos = $posHash;
    } elseif ($posIndex !== false) {
        $cutPos = $posIndex;
    }
    return ($cutPos !== false) ? substr($url, 0, $cutPos) : $url;
}
function getTableFields($tables){
    global $db;
    $tablestr = "'".implode("','", $tables)."'";
    $fields = [];
    $sql = "SELECT COLUMN_NAME, DATA_TYPE
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ($tablestr)
            ORDER BY TABLE_NAME, ORDINAL_POSITION";
    $result = $db->query($sql);
    while ($row = $db->fetchByAssoc($result)) {
        $fields[] = [
            'column' => $row['COLUMN_NAME'],
            'type' => $row['DATA_TYPE']
        ];
    }
    return $fields;
}
function generateDBlog($question, $answer, $generatedquery){
    global $db, $current_user;
    $currentUserId = $current_user->id ?? '1';
    $rawResponse = $db->quote($answer);
    $inputTokens = $outputTokens = $approx_charge = 0;
    $usages = $_SESSION['ai_usage'] ?? [];
    foreach ($usages as $usage) {
        $in  = $usage['usage']['input_tokens']  ?? 0;
        $out = $usage['usage']['output_tokens'] ?? 0;
        $inputTokens  = $inputTokens+$in;
        $outputTokens = $outputTokens+$out;
        if($usage['model'] == "gpt-4o-mini"){
            $approx_charge = $approx_charge+ ($in * 0.30 / 1000000)+($out * 0.60 / 1000000); //4o-mini formula here
        }elseif($usage['model'] == "gpt-4.1-mini"){
            $approx_charge = $approx_charge+ ($in * 0.30 / 1000000)+($out * 1.20 / 1000000); //4.1-mini formula here
        }
    }
    $start = $_SESSION['request_start_time'] ?? microtime(true);
    $duration = round(microtime(true) - $start, 2);
    unset($_SESSION['request_start_time']);
    unset($_SESSION['ai_usage']);
    $rahbar_log_bean = BeanFactory::newBean("Fyn_Rahbar_Logs");
    $rahbar_log_bean->name = $question;
    $rahbar_log_bean->response = $rawResponse;
    $rahbar_log_bean->generated_query = $generatedquery;
    $rahbar_log_bean->input_tokens = $inputTokens;
    $rahbar_log_bean->output_tokens = $outputTokens;
    $rahbar_log_bean->approx_charge = $approx_charge;
    $rahbar_log_bean->time_taken = $duration;
    $rahbar_log_bean->save();
}

function generateFileLog($question, $request, $response, $context='general'){
    $logFile = __DIR__ . '/rahbar_' . date('Y-m-d') . '.log';
    // $entry = [
    //     'timestamp' => date('c'),
    //     'question'  => $question,
    //     'context'   => $context,
    //     'request'   => is_string($request) ? $request : json_encode($request),
    //     'response'  => is_string($response) ? $response : json_encode($response),
    // ];
    // $formatted = json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    // file_put_contents($logFile,$formatted . "\n" . str_repeat("=", 120) . "\n\n",FILE_APPEND | LOCK_EX);
    $logEntry  = "====================================================================\n";
    $logEntry .= "Timestamp : " . date('c') . "\n";
    $logEntry .= "Context   : $context\n";
    $logEntry .= "Question  : $question\n\n";
    $logEntry .= "----- REQUEST -----\n";
    $logEntry .= (is_string($request) ? $request : json_encode($request, JSON_PRETTY_PRINT)) . "\n\n";
    $logEntry .= "----- RESPONSE -----\n";
    $logEntry .= (is_string($response) ? $response : json_encode($response, JSON_PRETTY_PRINT)) . "\n";
    $logEntry .= "====================================================================\n\n";
    file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}

/*** Call OpenAi API */
function callOpenAI($model, $payload, $question, $context='general') {
    global $sugar_config;
    $client = new \GuzzleHttp\Client([
        'timeout' => 60,
    ]);
    try {
        $response = $client->post(
            'https://api.openai.com/v1/responses',
            [
                'headers' => [
                    'Authorization' => 'Bearer ' . $sugar_config['fyn_rahbar_api_key'],
                    'Content-Type'  => 'application/json',
                ],
                'json' => array_merge(['model' => $model], $payload)
            ]
        );
        $raw = $response->getBody()->getContents();
        $data = json_decode($raw, true);
        generateFileLog($question, $payload, $raw, $context);
        if (!isset($_SESSION['ai_usage'])) {
            $_SESSION['ai_usage'] = [];
        }
        $_SESSION['ai_usage'][] = ["usage" => $data['usage'] ?? ['input_tokens'=>0,'output_tokens'=>0,'total_tokens'=>0],"model" => $model];
        return $data;
    } catch (\Exception $e) {
        die(json_encode([
            'success' => false,
            'response' => $e->getMessage(),
        ]));
    }
}