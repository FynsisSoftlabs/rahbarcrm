<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
global $db;
header('Content-Type: application/json');
// $sql = "SELECT name, generated_query FROM fyn_rahbar_logs WHERE is_correct = 1 AND deleted = 0 GROUP BY name";
$sql = "SELECT name, generated_query FROM fyn_rahbar_logs WHERE is_correct = 1 AND deleted = 0";
$result = $db->query($sql);
$suggestions = [];
while ($row = $db->fetchByAssoc($result)) {
    $suggestions[] = ['question' => $row['name'], 'query' => $row['generated_query']];
}

// Include session chat history
$chatHistory = [];
if (!empty($_SESSION['sql_history']) && is_array($_SESSION['sql_history'])) {
    foreach ($_SESSION['sql_history'] as $turn) {
        // Each turn is an array of [{role, content}, {role, content}]
        foreach ($turn as $msg) {
            if (!empty($msg['role']) && isset($msg['content'])) {
                $chatHistory[] = [
                    'role'    => $msg['role'],
                    'content' => $msg['content'],
                ];
            }
        }
    }
}


echo json_encode(['success' => true, 'data' => $suggestions, 'chat_history' => $chatHistory]);