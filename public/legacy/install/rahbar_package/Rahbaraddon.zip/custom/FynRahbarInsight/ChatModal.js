(function () {

  if (window.location.href.toLowerCase().includes('login')) {
    return;
  }

  let approvedQuestions = [];
  async function loadApprovedQuestions() {
    try {
      const res = await fetch(`${getBaseUrl()}index.php?entryPoint=fynsuggest`);
      const data = await res.json();
      console.log(data)
      if (data.success) {
        approvedQuestions = data.data;
        if (Array.isArray(data.chat_history) && data.chat_history.length > 0) {
          restoreChatHistory(data.chat_history);
        }
      }
    } catch (e) {
      console.error("Rehbar: failed to load suggestions", e);
    }
  }

  function restoreChatHistory(history) {
    if (messages.length > 0) return;
    history.forEach(msg => {
      if (msg.role === 'user') {
        messages.push({ from: 'You', text: msg.content, time: '' });
        lastQuestion = msg.content;
      } else if (msg.role === 'assistant') {
        messages.push({ from: 'AI', text: msg.content, time: '' });
      }
    });
    welcomeShown = true;
  }

  // DOMContentLoaded may have already fired by the time this script is injected
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", loadApprovedQuestions);
  } else {
    loadApprovedQuestions();
  }

  // ====== CSS Injection ======
  const style = document.createElement("style");
  style.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap');

    :root {
      --brand: #e81515;
      --brand-dark: #c00f0f;
      --brand-glow: rgba(232, 21, 21, 0.18);
      --surface: #ffffff;
      --surface-2: #f7f7f8;
      --surface-3: #efefef;
      --text-primary: #111111;
      --text-secondary: #6b6b6b;
      --text-inverse: #ffffff;
      --border: #e4e4e4;
      --shadow-sm: 0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06);
      --shadow-md: 0 4px 16px rgba(0,0,0,0.10), 0 2px 6px rgba(0,0,0,0.07);
      --shadow-lg: 0 12px 40px rgba(0,0,0,0.14), 0 4px 12px rgba(0,0,0,0.08);
      --radius-sm: 8px;
      --radius-md: 14px;
      --radius-lg: 20px;
      --radius-xl: 24px;
    }

    #chatModal * {
      box-sizing: border-box;
      font-family: 'DM Sans', sans-serif;
    }

    /* Launcher button */
    #rehbar-launcher {
      position: fixed;
      bottom: 24px;
      right: 24px;
      width: 56px;
      height: 56px;
      background: var(--brand);
      border-radius: 50%;
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 20px var(--brand-glow), 0 2px 8px rgba(0,0,0,0.15);
      z-index: 999998;
      transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.2s ease;
      outline: none;
    }
    #rehbar-launcher:hover {
      transform: scale(1.08);
      box-shadow: 0 6px 24px var(--brand-glow), 0 3px 10px rgba(0,0,0,0.18);
    }
    #rehbar-launcher:active { transform: scale(0.96); }
    #rehbar-launcher svg { transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); }
    #rehbar-launcher.open .icon-chat { display: none; }
    #rehbar-launcher:not(.open) .icon-close { display: none; }

    /* Unread badge */
    #rehbar-launcher .badge {
      position: absolute;
      top: -2px;
      right: -2px;
      width: 16px;
      height: 16px;
      background: #fff;
      color: var(--brand);
      border-radius: 50%;
      font-size: 9px;
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 2px solid var(--brand);
      display: none;
    }

    /* Modal */
    .chat-modal {
      position: fixed;
      bottom: 90px;
      right: 24px;
      width: 360px;
      height: 520px;
      background: var(--surface);
      border-radius: var(--radius-xl);
      display: flex;
      flex-direction: column;
      box-shadow: var(--shadow-lg);
      z-index: 999999;
      overflow: hidden;
      border: 1px solid var(--border);
      transform: scale(0.92) translateY(16px);
      transform-origin: bottom right;
      opacity: 0;
      pointer-events: none;
      transition: transform 0.28s cubic-bezier(0.34, 1.56, 0.64, 1),
                  opacity 0.22s ease;
    }
    .chat-modal.open {
      transform: scale(1) translateY(0);
      opacity: 1;
      pointer-events: all;
    }

    /* Header */
    .chat-header {
      background: var(--brand);
      padding: 14px 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-shrink: 0;
    }
    .chat-header-left {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .chat-header-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      border: 2px solid rgba(255,255,255,0.35);
      object-fit: cover;
      flex-shrink: 0;
    }
    .chat-header-info {}
    .chat-header-name {
      color: #fff;
      font-size: 15px;
      font-weight: 600;
      line-height: 1.2;
    }
    .chat-header-sub {
      color: rgba(255,255,255,0.72);
      font-size: 11px;
      font-weight: 400;
      letter-spacing: 0.02em;
    }
    .chat-header-status {
      display: flex;
      align-items: center;
      gap: 5px;
      margin-top: 2px;
    }
    .chat-header-status-dot {
      width: 7px;
      height: 7px;
      background: #4ade80;
      border-radius: 50%;
      box-shadow: 0 0 0 2px rgba(74, 222, 128, 0.3);
      animation: pulse-green 2s ease infinite;
    }
    @keyframes pulse-green {
      0%, 100% { box-shadow: 0 0 0 2px rgba(74, 222, 128, 0.3); }
      50% { box-shadow: 0 0 0 4px rgba(74, 222, 128, 0.1); }
    }
    .chat-header-close {
      background: rgba(255,255,255,0.15);
      border: none;
      border-radius: 8px;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      color: white;
      transition: background 0.15s;
      flex-shrink: 0;
    }
    .chat-header-close:hover { background: rgba(255,255,255,0.25); }

    /* Body */
    .chat-body {
      flex: 1;
      overflow-y: auto;
      padding: 16px 14px;
      background: var(--surface-2);
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .chat-body::-webkit-scrollbar { width: 4px; }
    .chat-body::-webkit-scrollbar-track { background: transparent; }
    .chat-body::-webkit-scrollbar-thumb { background: var(--surface-3); border-radius: 4px; }

    /* Welcome card */
    .welcome-card {
      background: linear-gradient(135deg, var(--brand) 0%, #c00f0f 100%);
      border-radius: var(--radius-lg);
      padding: 20px 18px;
      color: white;
      margin-bottom: 8px;
      position: relative;
      overflow: hidden;
    }
    .welcome-card::before {
      content: '';
      position: absolute;
      top: -20px;
      right: -20px;
      width: 80px;
      height: 80px;
      background: rgba(255,255,255,0.07);
      border-radius: 50%;
    }
    .welcome-card::after {
      content: '';
      position: absolute;
      bottom: -30px;
      right: 20px;
      width: 60px;
      height: 60px;
      background: rgba(255,255,255,0.05);
      border-radius: 50%;
    }
    .welcome-card h3 {
      font-size: 15px;
      font-weight: 600;
      margin: 0 0 4px 0;
    }
    .welcome-card p {
      font-size: 12.5px;
      color: rgba(255,255,255,0.8);
      margin: 0;
      line-height: 1.5;
    }

    /* Messages */
    .message {
      display: flex;
      align-items: flex-end;
      gap: 8px;
      animation: msg-in 0.22s cubic-bezier(0.22, 1, 0.36, 1);
    }
    @keyframes msg-in {
      from { opacity: 0; transform: translateY(8px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .message.ai { justify-content: flex-start; }
    .message.you { justify-content: flex-end; }

    .msg-avatar {
      width: 26px;
      height: 26px;
      border-radius: 50%;
      flex-shrink: 0;
      object-fit: cover;
      margin-bottom: 2px;
    }
    .msg-avatar.hidden { visibility: hidden; }

    .msg-bubble-wrap {
      display: flex;
      flex-direction: column;
      max-width: 78%;
      position: relative;
    }
    .message.you .msg-bubble-wrap { align-items: flex-end; }

    .msg-bubble {
      padding: 10px 13px;
      border-radius: var(--radius-md);
      font-size: 13.5px;
      line-height: 1.55;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
      word-break: break-word;
      position: relative;
    }

    /* AI bubble */
    .message.ai .msg-bubble {
      background: var(--surface);
      color: var(--text-primary);
      border-bottom-left-radius: 4px;
      border: 1px solid var(--border);
      box-shadow: var(--shadow-sm);
    }
    .message.ai .msg-bubble.has-feedback {
      padding-bottom: 30px;
    }

    /* User bubble */
    .message.you .msg-bubble {
      background: var(--brand);
      color: var(--text-inverse);
      border-bottom-right-radius: 4px;
    }

    /* Typing indicator */
    .typing-bubble {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 10px 14px;
    }
    .typing-dot {
      width: 6px;
      height: 6px;
      background: #bbb;
      border-radius: 50%;
      animation: typing-bounce 1.2s ease infinite;
    }
    .typing-dot:nth-child(2) { animation-delay: 0.2s; }
    .typing-dot:nth-child(3) { animation-delay: 0.4s; }
    @keyframes typing-bounce {
      0%, 80%, 100% { transform: translateY(0); }
      40% { transform: translateY(-5px); background: var(--brand); }
    }

    /* Feedback buttons */
    .feedback-buttons {
      position: absolute;
      bottom: 6px;
      right: 8px;
      display: flex;
      gap: 3px;
    }
    .feedback-btn {
      background: none;
      border: 1px solid var(--border);
      border-radius: 6px;
      width: 24px;
      height: 22px;
      font-size: 11px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--text-secondary);
      transition: background 0.15s, border-color 0.15s, transform 0.15s;
      line-height: 1;
      padding: 0;
    }
    .feedback-btn:hover { background: var(--surface-3); border-color: #ccc; transform: scale(1.12); }
    .feedback-btn.like:hover { background: #ecfdf5; border-color: #4ade80; }
    .feedback-btn.dislike:hover { background: #fef2f2; border-color: #f87171; }
    .feedback-done {
      font-size: 11px;
      color: var(--text-secondary);
      font-style: italic;
    }

    /* Timestamp */
    .msg-time {
      font-size: 10px;
      color: var(--text-secondary);
      margin-top: 3px;
      padding: 0 2px;
    }

    /* Footer */
    .chat-footer {
      border-top: 1px solid var(--border);
      background: var(--surface);
      padding: 10px 12px 12px;
      flex-shrink: 0;
      position: relative;
    }
    .chat-input-row {
      display: flex;
      align-items: flex-end;
      gap: 8px;
      background: var(--surface-2);
      border: 1.5px solid var(--border);
      border-radius: var(--radius-md);
      padding: 8px 8px 8px 12px;
      transition: border-color 0.2s;
    }
    .chat-input-row:focus-within {
      border-color: var(--brand);
      box-shadow: 0 0 0 3px var(--brand-glow);
    }
    .chat-footer textarea {
      flex: 1;
      resize: none;
      padding: 0;
      font-size: 13.5px;
      border: none;
      outline: none;
      height: 20px;
      max-height: 80px;
      background: transparent;
      color: var(--text-primary);
      line-height: 1.5;
      font-family: 'DM Sans', sans-serif;
      overflow-y: auto;
    }
    .chat-footer textarea::placeholder { color: #b0b0b0; }
    .chat-footer textarea::-webkit-scrollbar { width: 3px; }
    .chat-footer textarea::-webkit-scrollbar-thumb { background: #ddd; border-radius: 3px; }

    .send-btn {
      width: 34px;
      height: 34px;
      background: var(--brand);
      border: none;
      border-radius: 10px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      transition: background 0.15s, transform 0.15s;
      color: white;
    }
    .send-btn:hover { background: var(--brand-dark); transform: scale(1.06); }
    .send-btn:active { transform: scale(0.95); }
    .send-btn:disabled { background: #eee; color: #bbb; cursor: not-allowed; transform: none; }

    /* Suggestions */
    .suggestions-container {
      position: absolute;
      bottom: calc(100% + 6px);
      left: 12px;
      right: 12px;
      background: var(--surface);
      border-radius: var(--radius-md);
      box-shadow: var(--shadow-md);
      border: 1px solid var(--border);
      max-height: 180px;
      overflow-y: auto;
      display: none;
      z-index: 999;
    }
    .suggestions-container::-webkit-scrollbar { width: 4px; }
    .suggestions-container::-webkit-scrollbar-thumb { background: var(--surface-3); border-radius: 4px; }
    .suggestion-item {
      padding: 9px 14px;
      cursor: pointer;
      font-size: 13px;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      gap: 8px;
      transition: background 0.12s;
      border-bottom: 1px solid var(--surface-3);
    }
    .suggestion-item:last-child { border-bottom: none; }
    .suggestion-item::before {
      content: '↗';
      color: var(--brand);
      font-size: 11px;
      flex-shrink: 0;
    }
    .suggestion-item:hover,
    .suggestion-item.active {
      background: var(--surface-2);
    }

    /* Footer branding */
    .chat-powered {
      text-align: center;
      font-size: 10px;
      color: #c0c0c0;
      margin-top: 6px;
      letter-spacing: 0.02em;
    }
    .chat-powered a { color: #c0c0c0; text-decoration: none; }
    .chat-powered a:hover { color: var(--brand); }

    /* Day divider */
    .day-divider {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 8px 0 4px;
    }
    .day-divider::before, .day-divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background: var(--border);
    }
    .day-divider span {
      font-size: 10.5px;
      color: var(--text-secondary);
      white-space: nowrap;
    }

    /* ====== FIX 2: details / summary accordion styling ====== */
    .msg-bubble details {
      background: var(--surface-2);
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      margin: 4px 0;
      overflow: hidden;
      /* details contains structured data — override pre-wrap so it wraps normally */
      white-space: normal;
    }
    .msg-bubble details + details {
      margin-top: 3px;
    }
    .msg-bubble summary {
      padding: 7px 10px;
      cursor: pointer;
      font-weight: 500;
      font-size: 13px;
      color: var(--text-primary);
      list-style: none;
      display: flex;
      align-items: center;
      gap: 6px;
      user-select: none;
      transition: background 0.12s;
      line-height: 1.4;
    }
    .msg-bubble summary::-webkit-details-marker { display: none; }
    .msg-bubble summary::before {
      content: '▶';
      font-size: 8px;
      color: var(--brand);
      transition: transform 0.2s ease;
      flex-shrink: 0;
      margin-top: 1px;
    }
    .msg-bubble details[open] > summary::before {
      transform: rotate(90deg);
    }
    .msg-bubble summary:hover {
      background: var(--surface-3);
    }
    .msg-bubble details > *:not(summary) {
      padding: 8px 12px 8px 28px;
      font-size: 12.5px;
      color: var(--text-secondary);
      line-height: 1.65;
      border-top: 1px solid var(--border);
      white-space: normal;
    }

    /* AI Insights button */
    #aiInsightsBtn {
      background: var(--brand) !important;
      color: #fff !important;
      border: none !important;
      border-radius: 6px !important;
      padding: 5px 12px !important;
      font-size: 13px !important;
      cursor: pointer !important;
      font-family: 'DM Sans', sans-serif !important;
      font-weight: 500 !important;
      transition: background 0.15s !important;
    }
    #aiInsightsBtn:hover { background: var(--brand-dark) !important; }
  `;
  document.head.appendChild(style);

  // ====== Create Launcher Button ======
  const launcher = document.createElement("button");
  launcher.id = "rehbar-launcher";
  launcher.innerHTML = `
    <svg class="icon-chat" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
    </svg>
    <svg class="icon-close" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
    </svg>
    <span class="badge">1</span>
  `;
  document.body.appendChild(launcher);

  // ====== Create Modal HTML ======
  const modal = document.createElement("div");
  modal.className = "chat-modal";
  modal.id = "chatModal";
  modal.innerHTML = `
    <div class="chat-header">
      <div class="chat-header-left">
        <img class="chat-header-avatar" src="custom/FynRahbarInsight/logo.png" alt="Rehbar">
        <div class="chat-header-info">
          <div class="chat-header-name">Rehbar</div>
          <div class="chat-header-status">
            <div class="chat-header-status-dot"></div>
            <span class="chat-header-sub">By Fynsis SoftLabs · Online</span>
          </div>
        </div>
      </div>
      <button class="chat-header-close" title="Close">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>
    <div class="chat-body"></div>
    <div class="chat-footer">
      <div class="suggestions-container" id="suggestions"></div>
      <div class="chat-input-row">
        <textarea id="chatInput" placeholder="Ask your SuiteCRM question…" rows="1"></textarea>
        <button class="send-btn" title="Send">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
          </svg>
        </button>
      </div>
      <div class="chat-powered">Powered by <a href="https://fynsis.com" target="_blank">Fynsis SoftLabs</a></div>
    </div>
  `;
  document.body.appendChild(modal);

  const chatBody = modal.querySelector(".chat-body");
  // FIX 1: scope both to modal, not the whole document
  const textarea = modal.querySelector("#chatInput");
  const sendBtn = modal.querySelector(".send-btn");
  const closeBtn = modal.querySelector(".chat-header-close");

  let isOpen = false;
  let messages = [];
  let lastQuestion = null;
  let lastResponseHadFeedback = false;
  let welcomeShown = false;

  // ====== Toggle Open/Close ======
  function openChat() {
    isOpen = true;
    modal.classList.add("open");
    launcher.classList.add("open");
    if (!welcomeShown) {
      showWelcome();
      welcomeShown = true;
    }
    renderMessages(); // <-- add this line
    setTimeout(() => textarea.focus(), 300);
  }
  
  function closeChat() {
    isOpen = false;
    modal.classList.remove("open");
    launcher.classList.remove("open");
  }
  launcher.addEventListener("click", () => isOpen ? closeChat() : openChat());
  closeBtn.addEventListener("click", closeChat);

  // ====== Welcome message ======
  function showWelcome() {
    const card = document.createElement("div");
    card.className = "welcome-card";
    card.innerHTML = `<h3>👋 Hello! I'm Rehbar</h3><p>Your SuiteCRM AI assistant. Ask me anything about your CRM or use the suggestions below.</p>`;
    chatBody.appendChild(card);

    const divider = document.createElement("div");
    divider.className = "day-divider";
    divider.innerHTML = `<span>Today</span>`;
    chatBody.appendChild(divider);
  }

  // ====== Helpers ======
  function getTime() {
    return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  function renderMessages() {
    const keep = chatBody.querySelectorAll(".welcome-card, .day-divider");
    chatBody.innerHTML = "";
    keep.forEach(el => chatBody.appendChild(el));

    messages.forEach((m, index) => {
      const isAI = m.from === "AI";
      const isTyping = m.typing === true;
      const isLast = index === messages.length - 1;
      const showFeedback = isAI && isLast && lastQuestion && lastResponseHadFeedback && !isTyping;

      const div = document.createElement("div");
      div.className = `message ${isAI ? "ai" : "you"}`;

      if (isAI) {
        const avatar = document.createElement("img");
        avatar.src = "custom/FynRahbarInsight/AI.png";
        avatar.className = "msg-avatar";
        div.appendChild(avatar);
      }

      const wrap = document.createElement("div");
      wrap.className = "msg-bubble-wrap";

      const bubble = document.createElement("div");
      bubble.className = "msg-bubble";

      if (isTyping) {
        bubble.classList.add("typing-bubble");
        bubble.innerHTML = `<span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span>`;
      } else {
        if (showFeedback) bubble.classList.add("has-feedback");
        bubble.innerHTML = m.text;
      }

      wrap.appendChild(bubble);

      if (!isTyping) {
        const time = document.createElement("div");
        time.className = "msg-time";
        time.textContent = m.time || getTime();
        wrap.appendChild(time);
      }

      if (showFeedback) {
        if (m.feedbackDone) {
          const done = document.createElement("div");
          done.className = "feedback-done";
          done.textContent = m.feedbackText || "";
          bubble.appendChild(done);
        } else {
          const feedbackDiv = document.createElement("div");
          feedbackDiv.className = "feedback-buttons";
          feedbackDiv.innerHTML = `
            <button class="feedback-btn like" title="Mark answer 'correct' for future references">👍</button>
            <button class="feedback-btn dislike" title="Mark answer 'incorrect' to help make Rahbar better">👎</button>
          `;
          feedbackDiv.querySelector(".like").addEventListener("click", async () => {
            await fetch(`${getBaseUrl()}index.php?entryPoint=fynquery&question=${encodeURIComponent(lastQuestion)}&feedback=correct`);
            m.feedbackDone = true;
            m.feedbackText = "✔ Marked as correct";
            renderMessages();
          });
          feedbackDiv.querySelector(".dislike").addEventListener("click", async () => {
            m.feedbackDone = true;
            m.feedbackText = "⏳ Regenerating…";
            renderMessages();
            await sendQuestion("gpt-5-mini");
          });
          bubble.appendChild(feedbackDiv);
        }
      }

      div.appendChild(wrap);

      if (!isAI) {
        const avatar = document.createElement("img");
        avatar.src = "custom/FynRahbarInsight/You.png";
        avatar.className = "msg-avatar";
        div.appendChild(avatar);
      }

      chatBody.appendChild(div);
    });

    chatBody.scrollTop = chatBody.scrollHeight;
  }

  function addMessage(from, text, opts = {}) {
    messages.push({ from, text, time: getTime(), ...opts });
    renderMessages();
  }

  // ====== Send question ======
  async function sendQuestion(forceModel = null) {
    // FIX 1: always read from the scoped textarea reference
    const question = forceModel ? lastQuestion : textarea.value.trim();
    if (!question) return;

    if (!forceModel) {
      lastQuestion = question;
      addMessage("You", question);
      textarea.value = "";
      autoResize();
      messages.push({ from: "AI", text: "", typing: true, time: getTime() });
      renderMessages();
      sendBtn.disabled = true;
    }

    try {
      const resp = await fetch(
        `${getBaseUrl()}index.php?entryPoint=fynquery&question=${encodeURIComponent(question)}${forceModel ? `&model=${forceModel}` : ""}`
      );
      const data = await resp.json();

      if (!forceModel) {
        messages = messages.filter(m => !m.typing);
      }

      if (data.success) {
        lastResponseHadFeedback = data.feedback === true;
        addMessage("AI", data.explanation || data.response);
      } else {
        console.log(data);
        addMessage("AI", "⚠️ " + (data.error || "Something went wrong."));
      }
    } catch (e) {
      messages = messages.filter(m => !m.typing);
      console.log(e);
      if(e == 'Unexpected token \'<\', "<!DOCTYPE "... is not valid JSON'){
        addMessage("AI", "🔃 Refresh this page, and login to CRM again.");
      }else{
        addMessage("AI", "❌ Error connecting to server.");
      }
    } finally {
      sendBtn.disabled = false;
    }
  }

  // ====== Auto-resize textarea ======
  function autoResize() {
    textarea.style.height = "20px";
    textarea.style.height = Math.min(textarea.scrollHeight, 80) + "px";
  }

  // ====== Event Listeners ======
  // FIX 1: wrap in arrow function so sendQuestion() is called with no arguments
  sendBtn.addEventListener("click", () => sendQuestion());
  textarea.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendQuestion();
    }
  });
  textarea.addEventListener("input", autoResize);

  // ====== Inject "AI Insights" button next to Insights ======
  function injectAiInsightsBtn() {
    const insightsBtn = [...document.querySelectorAll("button, a")]
      .find(el => el.textContent.trim() === "Insights");

    if (insightsBtn && !document.getElementById("aiInsightsBtn")) {
      const aiBtn = document.createElement("button");
      aiBtn.id = "aiInsightsBtn";
      aiBtn.innerText = "✦ AI Insights";
      aiBtn.style.marginLeft = "8px";

      insightsBtn.parentNode.insertBefore(aiBtn, insightsBtn.nextSibling);
      aiBtn.addEventListener("click", async () => {
        if (!isOpen) openChat();
        const url = window.location.href;
        let urlArray = url.split("/");
        const recordId = urlArray[6].split("?")[0];
        const recordModule = urlArray[4];
        const idmodule = encodeURIComponent(JSON.stringify({ id: recordId, module: recordModule }));

        if (!recordId) {
          addMessage("AI", "⚠️ Could not detect record ID in URL.");
          return;
        }
        messages.push({ from: "AI", text: "", typing: true, time: getTime() });
        renderMessages();

        try {
          const res = await fetch(`${getBaseUrl()}index.php?entryPoint=fynrahbarinsight&idmodule=${idmodule}`);
          const data = await res.json();
          messages = messages.filter(m => !m.typing);
          if (data.success) {
            lastResponseHadFeedback = false;
            addMessage("AI", data.response);
          } else {
            addMessage("AI", `❌ Error: ${data.error || "Unknown error"}`);
          }
        } catch (e) {
          messages = messages.filter(m => !m.typing);
          addMessage("AI", "❌ Request failed. Check console for details.");
          console.error(e);
        }
      });
    }
  }

  // ====== Suggestions ======
  let selectedSuggestionIndex = -1;
  let currentSuggestions = [];
  // FIX 1: scope these to modal too, not document
  const suggestionsBox = modal.querySelector("#suggestions");
  const input = modal.querySelector("#chatInput");

  function showSuggestions(matches) {
    suggestionsBox.innerHTML = "";
    selectedSuggestionIndex = -1;
    currentSuggestions = matches;
    if (!matches.length) {
      suggestionsBox.style.display = "none";
      return;
    }
    matches.forEach((item, index) => {
      const div = document.createElement("div");
      div.className = "suggestion-item";
      div.textContent = item.question;
      div.addEventListener("click", () => applySuggestion(index));
      suggestionsBox.appendChild(div);
    });
    suggestionsBox.style.display = "block";
  }

  function applySuggestion(index) {
    const selected = currentSuggestions[index];
    if (!selected) return;
    input.value = selected.question;
    autoResize();
    suggestionsBox.style.display = "none";
    input.focus();
  }

  input.addEventListener("keydown", function (e) {
    if (!currentSuggestions.length) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      selectedSuggestionIndex = (selectedSuggestionIndex + 1) % currentSuggestions.length;
      updateActiveSuggestion();
    }
    if (e.key === "ArrowUp") {
      e.preventDefault();
      selectedSuggestionIndex = (selectedSuggestionIndex - 1 + currentSuggestions.length) % currentSuggestions.length;
      updateActiveSuggestion();
    }
    if (e.key === "Enter" && selectedSuggestionIndex >= 0) {
      e.preventDefault();
      applySuggestion(selectedSuggestionIndex);
    }
  });

  function updateActiveSuggestion() {
    const items = suggestionsBox.querySelectorAll(".suggestion-item");
    items.forEach(item => item.classList.remove("active"));
    if (items[selectedSuggestionIndex]) {
      items[selectedSuggestionIndex].classList.add("active");
    }
  }

  function getBaseUrl() {
    const href = window.location.href;
    const hashIdx = href.indexOf('#');
    const cleanHref = hashIdx !== -1 ? href.substring(0, hashIdx) : href;
    const phpIdx = cleanHref.indexOf('index.php');
    if (phpIdx !== -1) {
      return cleanHref.substring(0, phpIdx);
    }
    // fallback: just use origin
    return window.location.origin + '/';
  }

  input.addEventListener("input", function () {
    const value = this.value.toLowerCase().trim();
    if (!value) {
      suggestionsBox.style.display = "none";
      return;
    }
    const matches = approvedQuestions.filter(q =>
      q.question.toLowerCase().includes(value)
    );
    showSuggestions(matches.slice(0, 5));
  });

  // Close suggestions when clicking outside
  document.addEventListener("click", (e) => {
    if (!modal.contains(e.target)) suggestionsBox.style.display = "none";
  });

  // Run on route changes
  setInterval(injectAiInsightsBtn, 2000);
})();