<?php
$entry_point_registry['fynTriaging'] = array(
    'file' => 'custom/Fyntriaging/FynTriaging.php',
    'auth' => false
);