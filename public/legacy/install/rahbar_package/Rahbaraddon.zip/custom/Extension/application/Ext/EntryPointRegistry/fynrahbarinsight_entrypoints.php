<?php

$entry_point_registry['fynquery'] = array(
    'file' => 'custom/FynRahbarInsight/fynquery.php',
    'auth' => true
);
$entry_point_registry['fynsuggest'] = array(
    'file' => 'custom/FynRahbarInsight/fyn_suggestions.php',
    'auth' => true
);
$entry_point_registry['fyngenaireport'] = array(
    'file' => 'custom/FynRahbarInsight/fyn_gen_ai_report.php',
    'auth' => true
);