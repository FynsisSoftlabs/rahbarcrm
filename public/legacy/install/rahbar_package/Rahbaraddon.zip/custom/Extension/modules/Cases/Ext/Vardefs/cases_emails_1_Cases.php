<?php
// created: 2025-12-08 13:08:53
$dictionary["Case"]["fields"]["cases_emails_1"] = array (
  'name' => 'cases_emails_1',
  'type' => 'link',
  'relationship' => 'cases_emails_1',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'side' => 'right',
  'vname' => 'LBL_CASES_EMAILS_1_FROM_EMAILS_TITLE',
);
