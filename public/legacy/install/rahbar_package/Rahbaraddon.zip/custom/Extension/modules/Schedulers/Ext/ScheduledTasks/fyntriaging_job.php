<?php

// Scheduler job wrapper
$job_strings[] = 'fyn_triaging_scheduler';
function fyn_triaging_scheduler()
{
    $script = 'custom/Fyntriaging/FynTriaging.php';

    if (file_exists($script)) {
        require_once $script;
        return true;
    }

    $GLOBALS['log']->fatal("FynTriaging: Script not found: " . $script);
    return false;
}
