<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$dictionary["Contact"]["fields"]['fyn_xero_contactid'] = array(
	'name' => 'fyn_xero_contactid',
	'vname' => 'LBL_FYN_XERO_CONTACTID',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Contact"]["fields"]['fyn_xero_phone_work_cou'] = array(
	'name' => 'fyn_xero_phone_work_cou',
	'vname' => 'LBL_FYN_XERO_PHONE_WORK_COU',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Contact"]["fields"]['fyn_xero_phone_work_area'] = array(
	'name' => 'fyn_xero_phone_work_area',
	'vname' => 'LBL_FYN_XERO_PHONE_WORK_AREA',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Contact"]["fields"]['fyn_xero_phone_mobile_cou'] = array(
	'name' => 'fyn_xero_phone_mobile_cou',
	'vname' => 'LBL_FYN_XERO_PHONE_MOBILE_COU',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Contact"]["fields"]['fyn_xero_phone_mobile_area'] = array(
	'name' => 'fyn_xero_phone_mobile_area',
	'vname' => 'LBL_FYN_XERO_PHONE_MOBILE_AREA',
	'type' => 'varchar',
	'len' => 255,
);