<?php

global $sugar_version;

$admin_option_defs=array();

if(preg_match( "/^6.*/", $sugar_version) ) {
    $admin_option_defs['Administration']['triaging_info']= array('helpInline','LBL_TRIAGING_LICENSE_TITLE','LBL_TRIAGING_LICENSE','./index.php?module=Triaging&action=license');
    $admin_option_defs['Administration']['fyntriagingconfig'] = array('Administration', 'LBL_FYNTRIAGING_CONFIG', 'LBL_FYNTRIAGING_CONFIG_DESC', './index.php?module=Administration&action=fyntriagingconfig');
} else {
    $admin_option_defs['Administration']['triaging_info']= array('helpInline','LBL_TRIAGING_LICENSE_TITLE','LBL_TRIAGING_LICENSE','javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=Triaging&action=license", {trigger: true});');
    $admin_option_defs['Administration']['fyntriagingconfig'] = array('Administration', 'LBL_FYNTRIAGING_CONFIG', 'LBL_FYNTRIAGING_CONFIG_DESC', 'javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=Administration&action=fyntriagingconfig", {trigger: true});');
}

$admin_group_header[]= array('LBL_TRIAGING','',false,$admin_option_defs, '');
