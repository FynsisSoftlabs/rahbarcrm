<?php
// created: 2017-05-26 11:43:39
$dictionary["AOS_Quotes"]["fields"]["fyn_xerocreditnote_aos_quotes"] = array (
  'name' => 'fyn_xerocreditnote_aos_quotes',
  'type' => 'link',
  'relationship' => 'fyn_xerocreditnote_aos_quotes',
  'source' => 'non-db',
  'module' => 'FYN_XeroCreditNote',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_FYN_XEROCREDITNOTE_AOS_QUOTES_FROM_FYN_XEROCREDITNOTE_TITLE',
);
