<?php
//We add the mod string for our method here.
$mod_strings['LBL_FYN_TRIAGING_SCHEDULER'] = 'FynTriaging';