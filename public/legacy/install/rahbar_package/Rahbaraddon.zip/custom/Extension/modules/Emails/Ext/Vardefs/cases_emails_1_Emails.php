<?php
// created: 2025-12-08 13:08:53
$dictionary["Email"]["fields"]["cases_emails_1"] = array (
  'name' => 'cases_emails_1',
  'type' => 'link',
  'relationship' => 'cases_emails_1',
  'source' => 'non-db',
  'module' => 'Cases',
  'bean_name' => 'Case',
  'vname' => 'LBL_CASES_EMAILS_1_FROM_CASES_TITLE',
  'id_name' => 'cases_emails_1cases_ida',
);
$dictionary["Email"]["fields"]["cases_emails_1_name"] = array (
  'name' => 'cases_emails_1_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_CASES_EMAILS_1_FROM_CASES_TITLE',
  'save' => true,
  'id_name' => 'cases_emails_1cases_ida',
  'link' => 'cases_emails_1',
  'table' => 'cases',
  'module' => 'Cases',
  'rname' => 'name',
);
$dictionary["Email"]["fields"]["cases_emails_1cases_ida"] = array (
  'name' => 'cases_emails_1cases_ida',
  'type' => 'link',
  'relationship' => 'cases_emails_1',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_CASES_EMAILS_1_FROM_EMAILS_TITLE',
);
