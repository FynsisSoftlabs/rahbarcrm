<?php 

global $sugar_version;

$admin_option_defs=array();

if(preg_match( "/^6.*/", $sugar_version) ) {
    $admin_option_defs['Administration']['fynxeroapikey']= array('icon_xeroapi','LBL_XEROAPIKEY_TITLE','LBL_XEROAPIKEY_DESC', './index.php?module=FYN_Xero&action=XeroSetup');
    $admin_option_defs['Administration']['FYNXeroSugar'] = array('xero_sugar_icon', 'LBL_XEROSUGAR_TITLE', 'LBL_XEROSUGAR_DESC', './index.php?module=FYN_Xero&action=XerotoSugar');
    $admin_option_defs['Administration']['FYNXeroInventry'] = array('inventory_icon', 'LBL_XEROINVENTORY_TITLE', 'LBL_XEROINVENTORY_DESC', './index.php?module=FYN_Xero&action=InventrylisttoSugar');
    $admin_option_defs['Administration']['FYNXeroContacts'] = array('contact_icon', 'LBL_XEROSUGAR_TITLE', 'LBL_XEROSUGAR_DESC', './index.php?module=FYN_Xero&action=ContactslisttoSugar');
    $admin_option_defs['Administration']['FYNXeroContacts'] = array('invoice_icon', 'LBL_XEROSUGAR_TITLE', 'LBL_XEROSUGAR_DESC', './index.php?module=FYN_Xero&action=InovicelisttoSugar');
} else {
    $admin_option_defs['Administration']['fynxeroapikey']= array('icon_xeroapi','LBL_XEROAPIKEY_TITLE','LBL_XEROAPIKEY_DESC','javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=FYN_Xero&action=XeroSetup", {trigger: true});');
    $admin_option_defs['Administration']['FYNXeroSugar'] = array('xero_sugar_icon', 'LBL_XEROSUGAR_TITLE', 'LBL_XEROSUGAR_DESC', 'javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=FYN_Xero&action=XerotoSugar", {trigger: true});');
    $admin_option_defs['Administration']['FYNXeroInventry'] = array('inventory_icon', 'LBL_XEROINVENTORY_TITLE', 'LBL_XEROINVENTORY_DESC', 'javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=FYN_Xero&action=InventrylisttoSugar", {trigger: true});');
    $admin_option_defs['Administration']['FYNXeroContacts'] = array('contact_icon', 'LBL_XEROCONTACTS_TITLE', 'LBL_XEROCONTACTS_DESC', 'javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=FYN_Xero&action=ContactslisttoSugar", {trigger: true});');
    $admin_option_defs['Administration']['FYNXeroContacts'] = array('invoice_icon', 'LBL_XEROINVOICE_TITLE', 'LBL_XEROINVOICE_DESC', 'javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=FYN_Xero&action=InovicelisttoSugar", {trigger: true});');
}

$admin_group_header[]= array('LBL_XERO','',false,$admin_option_defs, '');