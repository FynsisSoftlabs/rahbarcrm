<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings['LBL_FYN_XERO_CONTACTID'] = 'Xero ContactID';
$mod_strings['LBL_FYN_XERO_ACCOUNTNUMBER'] = 'Xero Account Number';
$mod_strings['LBL_FYN_XERO_CONTACTSTATUS'] = 'Xero Contact Status';
$mod_strings['LBL_FYN_XERO_SKYPE'] = 'Xero Skype Name/Number';
$mod_strings['LBL_FYN_XERO_TAXNUMBER'] = 'Xero Tax ID Number';
$mod_strings['LBL_FYN_XERO_SALESTAX'] = 'Xero Sales Tax';
$mod_strings['LBL_FYN_XERO_PURTAX'] = 'Xero Purchases Tax';
$mod_strings['LBL_FYN_XERO_PURTAX'] = 'Xero Purchases Tax';
$mod_strings['LBL_FYN_XERO_POATTENTION'] = 'Xero POX AttentionTo';
$mod_strings['LBL_FYN_XERO_STREETATTENTION'] = 'Xero AttentionTo';
$mod_strings['LBL_FYN_XERO_ISSUPPLIER'] = 'Xero IsSupplier';
$mod_strings['LBL_FYN_XERO_ISCUSTOMER'] = 'Xero IsCustomer';
$mod_strings['LBL_FYN_XERO_CURRENCY'] = 'Xero DefaultCurrency';
$mod_strings['LBL_FYN_XERO_DISCOUNT'] = 'Xero Discount';
$mod_strings['LBL_FYN_XERO_PURACCOUNTCODE'] = 'Xero Purchase Account Code';
$mod_strings['LBL_FYN_XERO_SALESACCOUNTCODE'] = 'Xero Sales Account Code';
$mod_strings['LBL_FYN_XERO_BANKACCOUNTNUMBER'] = 'Xero Bank Account Number';
$mod_strings['LBL_FYN_XERO_BANKACCOUNTNAME'] = 'Xero Bank Account Name';
$mod_strings['LBL_FYN_XERO_BANKDETAILS'] = 'Xero Bank Details';
$mod_strings['LBL_FYN_XERO_BILLSDAY'] = 'Xero Bills Due Days';
$mod_strings['LBL_FYN_XERO_BILLSTYPE'] = 'Xero Bills Due Type';
$mod_strings['LBL_FYN_XERO_SALESDAY'] = 'Xero Sales Due Days';
$mod_strings['LBL_FYN_XERO_SALSESTYPE'] = 'Xero Sales Due Type';


$mod_strings['LBL_PRIMARY_CONTACT'] = 'Xero Primary Person';
$mod_strings['LBL_FYN_XERO_PHONE_OFFICE_COU'] = 'Xero Telephone Country';
$mod_strings['LBL_FYN_XERO_PHONE_OFFICE_AREA'] = 'Xero Telephone Area';
$mod_strings['LBL_FYN_XERO_PHONE_FAX_COU'] = 'Xero Fax Country';
$mod_strings['LBL_FYN_XERO_PHONE_FAX_AREA'] = 'Xero Fax Area';
$mod_strings['LBL_FYN_XERO_RE_OUTSTANDING'] = 'Xero Receivable Outstanding';
$mod_strings['LBL_FYN_XERO_RE_OVERDUE'] = 'Xero Receivable Overdue';
$mod_strings['LBL_FYN_XERO_PAY_OUTSTANDING'] = 'Xero Payable Outstanding';
$mod_strings['LBL_FYN_XERO_PAY_OVERDUE'] = 'Xero Payable Overdue';
?>