<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
## Start Create Custom Field Using DB Default
## START Relationship between Quote & Xero Payment
$dictionary["AOS_Quotes"]["fields"]["fyn_xeropayment"] = array(
    'name' => 'fyn_xeropayment',
    'type' => 'link',
    'relationship' => 'quote_fyn_xeropayment',
    'module' => 'FYN_Xeropayment',
    'bean_name' => 'FYN_Xeropayment',
    'source' => 'non-db',
    'vname' => 'LBL_FYNXEROPAYMENT',
);
$dictionary["AOS_Quotes"]["relationships"]["quote_fyn_xeropayment"] = array(
    'lhs_module' => 'AOS_Quotes',
    'lhs_table' => 'aos_quotes',
    'lhs_key' => 'id',
    'rhs_module' => 'FYN_Xeropayment',
    'rhs_table' => 'fyn_xeropayment',
    'rhs_key' => 'parent_id',
    'relationship_type' => 'one-to-many',
    'relationship_role_column' => 'parent_type',
    'relationship_role_column_value' => 'AOS_Quotes'
);
## END Relationship betweeb Quote & Xero Payment

## START Relationship between Quote & Xero Credit Note
$dictionary["AOS_Quotes"]["fields"]["fyn_xerocreditnote"] = array(
    'name' => 'fyn_xerocreditnote',
    'type' => 'link',
    'relationship' => 'quote_fyn_xerocreditnote',
    'module' => 'FYN_XeroCreditNote',
    'bean_name' => 'FYN_XeroCreditNote',
    'source' => 'non-db',
    'vname' => 'LBL_FYNXEROCREDITNOTE',
);

$dictionary["AOS_Quotes"]["relationships"]["quote_fyn_xerocreditnote"] = array(
    'lhs_module' => 'AOS_Quotes',
    'lhs_table' => 'aos_quotes',
    'lhs_key' => 'id',
    'rhs_module' => 'FYN_XeroCreditNote',
    'rhs_table' => 'fyn_xerocreditnote',
    'rhs_key' => 'parent_id',
    'relationship_type' => 'one-to-many',
    'relationship_role_column' => 'parent_type',
    'relationship_role_column_value' => 'AOS_Quotes'
);
## END Relationship betweeb Quote & Xero Credit Note

$dictionary["AOS_Quotes"]["fields"]['fyn_xero_invoicedate'] = array(
    'name' => 'fyn_xero_invoicedate',
    'vname' => 'LBL_FYN_XERO_INVOICEDATE',
    'type' => 'date',
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_duedate'] = array(
    'name' => 'fyn_xero_duedate',
    'vname' => 'LBL_FYN_XERO_DUEDATE',
    'type' => 'date',
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_expectedpaymentdate'] = array(
    'name' => 'fyn_xero_expectedpaymentdate',
    'vname' => 'LBL_FYN_XERO_EXPECTEDPAYMENTDATE',
    'type' => 'date',
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_plannedpaymentdate'] = array(
    'name' => 'fyn_xero_plannedpaymentdate',
    'vname' => 'LBL_FYN_XERO_PLANNEDPAYMENTDATE',
    'type' => 'date',
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_status'] = array(
    'name' => 'fyn_xero_status',
    'vname' => 'LBL_FYN_XERO_STATUS',
    'default' => 'DRAFT',
    'type' => 'enum',
    'options' => 'xero_status_list',
    'len' => 255,
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_lineamounttypes'] = array(
    'name' => 'fyn_xero_lineamounttypes',
    'vname' => 'LBL_FYN_XERO_LINEAMOUNTTYPES',
    'type' => 'enum',
    'options' => 'xero_lineamounttypes_list',
    'len' => 255,
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_currencycode'] = array(
    'name' => 'fyn_xero_currencycode',
    'vname' => 'LBL_FYN_XERO_CURRENCYCODE',
    'type' => 'enum',
    'options' => 'xero_currencies_list',
    'len' => 255,
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_type'] = array(
    'required' => true,
    'name' => 'fyn_xero_type',
    'vname' => 'LBL_FYN_XERO_TYPE',
    'type' => 'enum',
    'options' => 'xero_type_list',
    'len' => 255,
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_invoiceid'] = array(
    'name' => 'fyn_xero_invoiceid',
    'vname' => 'LBL_FYN_XERO_INVOICEID',
    'type' => 'varchar',
    'len' => 100,
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_invoicenumber'] = array(
    'name' => 'fyn_xero_invoicenumber',
    'vname' => 'LBL_FYN_XERO_INVOICENUMBER',
    'type' => 'varchar',
    'len' => 100,
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_amountdue'] = array(
    'name' => 'fyn_xero_amountdue',
    'vname' => 'LBL_FYN_XERO_AMOUNTDUE',
    'dbType' => 'decimal',
    'type' => 'currency',
    'len' => '26,6',
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_amountpaid'] = array(
    'name' => 'fyn_xero_amountpaid',
    'vname' => 'LBL_FYN_XERO_AMOUNTPAID',
    'dbType' => 'decimal',
    'type' => 'currency',
    'len' => '26,6',
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_fullypaidondate'] = array(
    'name' => 'fyn_xero_fullypaidondate',
    'vname' => 'LBL_FYN_XERO_FULLYPAIDONDATE',
    'type' => 'date',
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_amountcredited'] = array(
    'name' => 'fyn_xero_amountcredited',
    'vname' => 'LBL_FYN_XERO_AMOUNTCREDITED',
    'dbType' => 'decimal',
    'type' => 'currency',
    'len' => '26,6',
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_senttocontact'] = array(
    'name' => 'fyn_xero_senttocontact',
    'vname' => 'LBL_FYN_XERO_SENDTOCONTACT',
    'type' => 'bool',
);
$dictionary["AOS_Quotes"]["fields"]['fyn_xero_currencyrate'] = array(
    'name' => 'fyn_xero_currencyrate',
    'vname' => 'LBL_FYN_XERO_CURRENCYRATE',
    'default' => '1.0',
    'dbType' => 'decimal',
    'type' => 'currency',
    'len' => '26,6',
);

$dictionary["AOS_Quotes"]["fields"]['line_items']['function'] = array(
    'name' => 'custom_display_lines',
    'returns' => 'html',
    'include' => 'custom/modules/AOS_Products_Quotes/Line_Items.php'
);
?>