<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$dictionary["AOS_Products"]["fields"]['fyn_xero_itemid'] = array(
    'name' => 'fyn_xero_itemid',
    'vname' => 'LBL_FYN_XERO_ITEMID',
    'type' => 'varchar',
    'len' => 255,
);
$dictionary["AOS_Products"]["fields"]['fyn_xero_puracc'] = array(
    'name' => 'fyn_xero_puracc',
    'vname' => 'LBL_FYN_XERO_PURACC',
    'type' => 'enum',
    'options' => 'xero_accounting_list',
    'len' => 255,
);
$dictionary["AOS_Products"]["fields"]['fyn_xero_purtax'] = array(
    'name' => 'fyn_xero_purtax',
    'vname' => 'LBL_FYN_XERO_PURTAX',
    'type' => 'enum',
    'options' => 'xero_taxrate_list',
    'len' => 255,
);
$dictionary["AOS_Products"]["fields"]['fyn_xero_salesacc'] = array(
    'name' => 'fyn_xero_salesacc',
    'vname' => 'LBL_FYN_XERO_SALESACC',
    'type' => 'enum',
    'options' => 'xero_accounting_list',
    'len' => 255,
);
$dictionary["AOS_Products"]["fields"]['fyn_xero_salestax'] = array(
    'name' => 'fyn_xero_salestax',
    'vname' => 'LBL_FYN_XERO_SALESTAX',
    'type' => 'enum',
    'options' => 'xero_taxrate_list',
    'len' => 255,
);

?>