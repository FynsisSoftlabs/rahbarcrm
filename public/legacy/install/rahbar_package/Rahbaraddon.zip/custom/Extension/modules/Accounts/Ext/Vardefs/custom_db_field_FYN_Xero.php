<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$dictionary["Account"]["fields"]['fyn_xero_contactid'] = array(
	'name' => 'fyn_xero_contactid',
	'vname' => 'LBL_FYN_XERO_CONTACTID',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_accountnumber'] = array(
	'name' => 'fyn_xero_accountnumber',
	'vname' => 'LBL_FYN_XERO_ACCOUNTNUMBER',
	'type' => 'varchar',
	'len' => 50,
);
$dictionary["Account"]["fields"]['fyn_xero_contactstatus'] = array(
	'name' => 'fyn_xero_contactstatus',
	'vname' => 'LBL_FYN_XERO_CONTACTSTATUS',
	'type' => 'varchar',
	'len' => 50,
);
$dictionary["Account"]["fields"]['fyn_xero_skype'] = array(
	'name' => 'fyn_xero_skype',
	'vname' => 'LBL_FYN_XERO_SKYPE',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_taxnumber'] = array(
	'name' => 'fyn_xero_taxnumber',
	'vname' => 'LBL_FYN_XERO_TAXNUMBER',
	'type' => 'varchar',
	'len' => 50,
);

$dictionary["Account"]["fields"]['fyn_xero_salestax'] = array(
	'name' => 'fyn_xero_salestax',
	'vname' => 'LBL_FYN_XERO_SALESTAX',
	'type' => 'enum',
	'options' => 'xero_taxrate_list',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_purtax'] = array(
	'name' => 'fyn_xero_purtax',
	'vname' => 'LBL_FYN_XERO_PURTAX',
	'type' => 'enum',
	'options' => 'xero_taxrate_list',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_poattention'] = array(
	'name' => 'fyn_xero_poattention',
	'vname' => 'LBL_FYN_XERO_POATTENTION',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_streetattention'] = array(
	'name' => 'fyn_xero_streetattention',
	'vname' => 'LBL_FYN_XERO_STREETATTENTION',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_issupplier'] = array(
	'name' => 'fyn_xero_issupplier',
	'vname' => 'LBL_FYN_XERO_ISSUPPLIER',
	'type' => 'bool',
);
$dictionary["Account"]["fields"]['fyn_xero_iscustomer'] = array(
	'name' => 'fyn_xero_iscustomer',
	'vname' => 'LBL_FYN_XERO_ISCUSTOMER',
	'type' => 'bool',
);
$dictionary["Account"]["fields"]['fyn_xero_currency'] = array(
	'name' => 'fyn_xero_currency',
	'vname' => 'LBL_FYN_XERO_CURRENCY',
	'type' => 'enum',
	'options' => 'xero_currencies_list',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_discount'] = array(
	'name' => 'fyn_xero_discount',
	'vname' => 'LBL_FYN_XERO_DISCOUNT',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_puraccountcode'] = array(
	'name' => 'fyn_xero_puraccountcode',
	'vname' => 'LBL_FYN_XERO_PURACCOUNTCODE',
	'type' => 'enum',
	'options' => 'xero_accounting_pur_list',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_salesaccountcode'] = array(
	'name' => 'fyn_xero_salesaccountcode',
	'vname' => 'LBL_FYN_XERO_SALESACCOUNTCODE',
	'type' => 'enum',
	'options' => 'xero_accounting_list',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_bankaccountnumber'] = array(
	'name' => 'fyn_xero_bankaccountnumber',
	'vname' => 'LBL_FYN_XERO_BANKACCOUNTNUMBER',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_bankaccountname'] = array(
	'name' => 'fyn_xero_bankaccountname',
	'vname' => 'LBL_FYN_XERO_BANKACCOUNTNAME',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_bankdetails'] = array(
	'name' => 'fyn_xero_bankdetails',
	'vname' => 'LBL_FYN_XERO_BANKDETAILS',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_billsday'] = array(
	'name' => 'fyn_xero_billsday',
	'vname' => 'LBL_FYN_XERO_BILLSDAY',
	'type' => 'varchar',
	'len' => 10,
);
$dictionary["Account"]["fields"]['fyn_xero_billstype'] = array(
	'name' => 'fyn_xero_billstype',
	'vname' => 'LBL_FYN_XERO_BILLSTYPE',
	'type' => 'enum',
	'options' => 'xero_duedatedropdown_list',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_salesday'] = array(
	'name' => 'fyn_xero_salesday',
	'vname' => 'LBL_FYN_XERO_SALESDAY',
	'type' => 'varchar',
	'len' => 10,
);
$dictionary["Account"]["fields"]['fyn_xero_salestype'] = array(
	'name' => 'fyn_xero_salestype',
	'vname' => 'LBL_FYN_XERO_SALSESTYPE',
	'type' => 'enum',
	'options' => 'xero_duedatedropdown_list',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_phone_office_cou'] = array(
	'name' => 'fyn_xero_phone_office_cou',
	'vname' => 'LBL_FYN_XERO_PHONE_OFFICE_COU',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_phone_office_area'] = array(
	'name' => 'fyn_xero_phone_office_area',
	'vname' => 'LBL_FYN_XERO_PHONE_OFFICE_AREA',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_phone_fax_cou'] = array(
	'name' => 'fyn_xero_phone_fax_cou',
	'vname' => 'LBL_FYN_XERO_PHONE_FAX_COU',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_phone_fax_area'] = array(
	'name' => 'fyn_xero_phone_fax_area',
	'vname' => 'LBL_FYN_XERO_PHONE_FAX_AREA',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_re_outstanding'] = array(
	'name' => 'fyn_xero_re_outstanding',
	'vname' => 'LBL_FYN_XERO_RE_OUTSTANDING',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_re_overdue'] = array(
	'name' => 'fyn_xero_re_overdue',
	'vname' => 'LBL_FYN_XERO_RE_OVERDUE',
	'type' => 'varchar',
	'len' => 255,
);
$dictionary["Account"]["fields"]['fyn_xero_pay_outstanding'] = array(
	'name' => 'fyn_xero_pay_outstanding',
	'vname' => 'LBL_FYN_XERO_PAY_OUTSTANDING',
	'type' => 'varchar',
	'len' => 20,
);
$dictionary["Account"]["fields"]['fyn_xero_pay_overdue'] = array(
	'name' => 'fyn_xero_pay_overdue',
	'vname' => 'LBL_FYN_XERO_PAY_OVERDUE',
	'type' => 'varchar',
	'len' => 20,
);

## PRIMARY Contact 
$dictionary["Account"]["fields"]["primary_contact"] = array(
	'required' => false,
	'source' => 'non-db',
	'name' => 'primary_contact',
	'vname' => 'LBL_PRIMARY_CONTACT',
	'type' => 'relate',
	'massupdate' => '0',
	'default' => NULL,
	'comments' => '',
	'help' => '',
	'importable' => 'true',
	'duplicate_merge' => 'disabled',
	'duplicate_merge_dom_value' => '0',
	'audited' => false,
	'reportable' => true,
	'len' => '255',
	'size' => '20',
	'id_name' => 'primary_contact_id',
	'ext2' => 'Contacts',
	'module' => 'Contacts',
	'rname' => 'name',
	'studio' => 'visible',
);
$dictionary["Account"]["fields"]["primary_contact_id"] = array(
	'required' => false,
	'name' => 'primary_contact_id',
	'vname' => 'LBL_PRIMARY_CONTACT_ID',
	'type' => 'id',
	'massupdate' => '0',
	'default' => NULL,
	'comments' => '',
	'help' => '',
	'importable' => 'true',
	'duplicate_merge' => 'disabled',
	'duplicate_merge_dom_value' => '0',
	'audited' => false,
	'reportable' => true,
	'len' => '36',
	'size' => '20',
);