<?php

$mod_strings['LBL_XERO'] = 'Xero Integration Configuration';
$mod_strings['LBL_XEROAPIKEY_TITLE'] = 'Xero API Settings';
$mod_strings['LBL_XEROAPIKEY_DESC'] = 'Set your Xero API and other required credentials.';
$mod_strings['LBL_XEROSUGAR_TITLE'] = 'Xero to SuiteCRM Sync';
$mod_strings['LBL_XEROSUGAR_DESC'] = 'Import Taxrates, Xero Accounting, Currency List from Xero to SuiteCRM.';
$mod_strings['LBL_XEROINVENTORY_TITLE'] = 'Inventory List >> SuiteCRM';
$mod_strings['LBL_XEROINVENTORY_DESC'] = 'Import Inventory(Products) from Xero to SuiteCRM.';
$mod_strings['LBL_XEROCONTACTS_TITLE'] = 'Contacts List >> SuiteCRM';
$mod_strings['LBL_XEROCONTACTS_DESC'] = 'Import account/contact from Xero to SuiteCRM.';
$mod_strings['LBL_XEROINVOICE_TITLE'] = 'Invoice List >> SuiteCRM';
$mod_strings['LBL_XEROINVOICE_DESC'] = 'Import invoice from Xero to SuiteCRM.';