<?php
// created: 2017-05-26 12:08:54
$dictionary["AOS_Quotes"]["fields"]["fyn_xeropayment_aos_quotes"] = array (
  'name' => 'fyn_xeropayment_aos_quotes',
  'type' => 'link',
  'relationship' => 'fyn_xeropayment_aos_quotes',
  'source' => 'non-db',
  'module' => 'FYN_Xeropayment',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_FYN_XEROPAYMENT_AOS_QUOTES_FROM_FYN_XEROPAYMENT_TITLE',
);
