<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
 
$dictionary["AOS_Products_Quotes"]["fields"]['fyn_xero_accountcode'] = array(
	'name' => 'fyn_xero_accountcode',
	'vname' => 'LBL_FYN_XERO_ACCOUNTCODE',
	'type' => 'enum',
	'options' => 'xero_accounting_list',
	'len' => 255,
);
?>