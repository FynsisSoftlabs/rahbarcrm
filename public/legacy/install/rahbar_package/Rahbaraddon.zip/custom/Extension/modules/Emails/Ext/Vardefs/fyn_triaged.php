<?php

$dictionary['Email']['fields']['fyn_triaged_c'] = array(
    'name' => 'fyn_triaged_c',
    'vname' => 'LBL_FYN_TRIAGED',
    'type' => 'bool',
    'default' => '0',
    'audited' => false,
    'reportable' => false,
    'importable' => false,
    'massupdate' => false,
    'duplicate_merge' => 'disabled',
);
