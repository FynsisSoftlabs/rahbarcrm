<?php
// created: 2017-05-26 12:08:54
$dictionary["FYN_Xeropayment"]["fields"]["fyn_xeropayment_aos_quotes"] = array (
  'name' => 'fyn_xeropayment_aos_quotes',
  'type' => 'link',
  'relationship' => 'fyn_xeropayment_aos_quotes',
  'source' => 'non-db',
  'module' => 'AOS_Quotes',
  'bean_name' => 'AOS_Quotes',
  'vname' => 'LBL_FYN_XEROPAYMENT_AOS_QUOTES_FROM_AOS_QUOTES_TITLE',
  'id_name' => 'fyn_xeropayment_aos_quotesaos_quotes_ida',
);
$dictionary["FYN_Xeropayment"]["fields"]["fyn_xeropayment_aos_quotes_name"] = array (
  'name' => 'fyn_xeropayment_aos_quotes_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_FYN_XEROPAYMENT_AOS_QUOTES_FROM_AOS_QUOTES_TITLE',
  'save' => true,
  'id_name' => 'fyn_xeropayment_aos_quotesaos_quotes_ida',
  'link' => 'fyn_xeropayment_aos_quotes',
  'table' => 'aos_quotes',
  'module' => 'AOS_Quotes',
  'rname' => 'name',
);
$dictionary["FYN_Xeropayment"]["fields"]["fyn_xeropayment_aos_quotesaos_quotes_ida"] = array (
  'name' => 'fyn_xeropayment_aos_quotesaos_quotes_ida',
  'type' => 'link',
  'relationship' => 'fyn_xeropayment_aos_quotes',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_FYN_XEROPAYMENT_AOS_QUOTES_FROM_FYN_XEROPAYMENT_TITLE',
);
