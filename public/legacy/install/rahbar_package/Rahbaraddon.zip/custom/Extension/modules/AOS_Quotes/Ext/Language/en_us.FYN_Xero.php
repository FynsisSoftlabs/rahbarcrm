<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$mod_strings['LBL_FYN_XERO_ITEMID'] = 'Xero Item id';
$mod_strings['LBL_FYN_XERO_DUEDATE'] = 'Xero DueDate';
$mod_strings['LBL_FYN_XERO_INVOICEDATE'] = 'Xero InvoiceDate';
$mod_strings['LBL_FYN_XERO_EXPECTEDPAYMENTDATE'] = 'Xero ExpectedPaymentDate';
$mod_strings['LBL_FYN_XERO_PLANNEDPAYMENTDATE'] = 'Xero PlannedPaymentDate';
$mod_strings['LBL_FYN_XERO_STATUS'] = 'Xero Status';
$mod_strings['LBL_FYN_XERO_LINEAMOUNTTYPES'] = 'Xero LineAmountTypes';
$mod_strings['LBL_FYN_XERO_TYPE'] = 'Xero Type';
$mod_strings['LBL_FYN_XERO_INVOICEID'] = 'Xero InvoiceID';
$mod_strings['LBL_FYN_XERO_INVOICENUMBER'] = 'Xero InvoiceNumber';
$mod_strings['LBL_FYN_XERO_AMOUNTDUE'] = 'Xero AmountDue';
$mod_strings['LBL_FYN_XERO_AMOUNTPAID'] = 'Xero AmountPaid';
$mod_strings['LBL_FYN_XERO_FULLYPAIDONDATE'] = 'Xero FullyPaidDate';
$mod_strings['LBL_FYN_XERO_AMOUNTCREDITED'] = 'Xero AmountCredited';
$mod_strings['LBL_FYN_XERO_SENDTOCONTACT'] = 'Xero SentToContact';
$mod_strings['LBL_FYN_XERO_CURRENCYRATE'] = 'Xero CurrencyRate';
$mod_strings['LBL_FYN_XERO_CURRENCYCODE'] = 'Xero CurrencyCode';
$mod_strings['LBL_FYNXEROPAYMENT_SUBPANEL_TITLE'] = 'Xero Payment';
$mod_strings['LBL_FYNXEROCREDITNOTE_SUBPANEL_TITLE'] = 'Xero Credit Note';
$mod_strings['LBL_LIST_ACCOUNTING'] = 'Accounting';
$mod_strings['LBL_LIST_TAX_RATES'] = 'Tax Rate';
$mod_strings['LBL_LIST_TAX_AMOUNT'] = 'Tax Amount';
$mod_strings['LBL_LIST_LINEAMOUNT'] = 'Amount';
$mod_strings['LBL_LIST_DEAL_AMOUNT'] = 'Amount';
$mod_strings['LBL_FYN_XERO_ACCOUNTCODE'] = 'Xero Account';

?>