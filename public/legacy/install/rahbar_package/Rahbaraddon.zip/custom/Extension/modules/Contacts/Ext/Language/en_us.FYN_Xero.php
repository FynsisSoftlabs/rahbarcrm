<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings['LBL_FYN_XERO_CONTACTID'] = 'Xero ContactID';
$mod_strings['LBL_FYN_XERO_PHONE_WORK_COU'] = 'Xero Direct Dial Country';
$mod_strings['LBL_FYN_XERO_PHONE_WORK_AREA'] = 'Xero Direct Dial Area';
$mod_strings['LBL_FYN_XERO_PHONE_MOBILE_COU'] = 'Xero Mobile Country';
$mod_strings['LBL_FYN_XERO_PHONE_MOBILE_AREA'] = 'Xero Mobile Area';
?>