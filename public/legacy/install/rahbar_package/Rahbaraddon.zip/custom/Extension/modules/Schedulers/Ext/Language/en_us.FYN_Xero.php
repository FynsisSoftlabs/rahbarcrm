<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings['LBL_FYN_CRMTOXERO_CRONJOB'] = 'FYN - Sugar to Xero';
$mod_strings['LBL_FYN_XEROTO_INVENTRY_CRONJOB'] = 'FYN - Xero to Sugar Inventry';
$mod_strings['LBL_FYN_XEROTO_ACCOUNT_CRONJOB'] = 'FYN - Xero to Sugar Account';
$mod_strings['LBL_FYN_XEROTO_QUOTE_CRONJOB'] = 'FYN - Xero to Sugar Quote';
 
