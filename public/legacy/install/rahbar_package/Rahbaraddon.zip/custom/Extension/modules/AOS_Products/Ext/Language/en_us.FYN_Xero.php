<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$mod_strings['LBL_FYN_XERO_ITEMID'] = 'Xero Item id';
$mod_strings['LBL_FYN_XERO_PURACC'] = 'Xero Purchase Account';
$mod_strings['LBL_FYN_XERO_PURTAX'] = 'Xero Purchase TaxRate';
$mod_strings['LBL_FYN_XERO_SALESACC'] = 'Xero Salse Account';
$mod_strings['LBL_FYN_XERO_SALESTAX'] = 'Xero Sales TaxRate';
?>