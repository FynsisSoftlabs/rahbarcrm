<?php

$mod_strings['LBL_TRIAGING'] = 'FynTriaging Configuration';
$mod_strings['LBL_TRIAGING_LICENSE_TITLE'] = 'License Configuration';
$mod_strings['LBL_TRIAGING_LICENSE'] = 'Manage and configure the license for this add-on';
$mod_strings['LBL_FYNTRIAGING_CONFIG'] = 'FynTriaging Settings';
$mod_strings['LBL_FYNTRIAGING_CONFIG_DESC'] = 'Configure FynTriaging to automate email sense';
$mod_strings['LBL_FYNTRIAGING_CONFIG_TITLE'] = 'FynTriaging Configuration';
