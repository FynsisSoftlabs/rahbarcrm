<?php
$mod_strings['LBL_FYN_TRIAGED'] = 'Scanned by FynTriaging';