<?php
 // created: 2017-05-26 12:08:54
$layout_defs["AOS_Quotes"]["subpanel_setup"]['fyn_xeropayment_aos_quotes'] = array (
  'order' => 100,
  'module' => 'FYN_Xeropayment',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_FYN_XEROPAYMENT_AOS_QUOTES_FROM_FYN_XEROPAYMENT_TITLE',
  'get_subpanel_data' => 'fyn_xeropayment_aos_quotes',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
