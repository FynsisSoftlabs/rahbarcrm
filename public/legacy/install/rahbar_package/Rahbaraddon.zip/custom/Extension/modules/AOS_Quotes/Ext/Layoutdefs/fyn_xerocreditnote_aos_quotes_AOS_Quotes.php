<?php
 // created: 2017-05-26 11:43:39
$layout_defs["AOS_Quotes"]["subpanel_setup"]['fyn_xerocreditnote_aos_quotes'] = array (
  'order' => 100,
  'module' => 'FYN_XeroCreditNote',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_FYN_XEROCREDITNOTE_AOS_QUOTES_FROM_FYN_XEROCREDITNOTE_TITLE',
  'get_subpanel_data' => 'fyn_xerocreditnote_aos_quotes',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
