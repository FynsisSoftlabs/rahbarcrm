<?php
$lockFile = sys_get_temp_dir() . '/fyntriaging.lock';
$fp = fopen($lockFile, 'c');
if (!flock($fp, LOCK_EX | LOCK_NB)) {
    // Another instance is running
    exit;
}
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

use GuzzleHttp\Client;
require_once 'modules/Cases/Case.php';
require_once 'modules/Leads/Lead.php';

global $sugar_config, $db, $app_list_strings;
$open_ai_key = $sugar_config['fyntriaging_api_key'] ?? '';
if (!$open_ai_key) {
    exit();
}

$logFile = __DIR__ . '/email_triage_log.txt';

function write_log($logFile, $subject, $from, $decision) {
    $timestamp = date('Y-m-d H:i:s');
    $entry = "[$timestamp] Subject: $subject | Decision: $decision | From: $from" . PHP_EOL;
    file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
}
function write_dblog($db, $name, $payload, $emailid, $decision, $moduleid) {
    $triaging_id = $db->query("SELECT UUID()")->fetch_array()[0];
    $db->query("INSERT INTO `fyn_triaging` SET id='$triaging_id', name='$name', date_entered=NOW(), date_modified=NOW(), modified_user_id=1, created_by=1, description='$payload', deleted=0, assigned_user_id=1, emailid='$emailid', decision='$decision'");
    $db->query("INSERT INTO `fyn_triaging_emails_c` SET id=UUID(), date_modified=NOW(), deleted=0, fyn_triaging_emailsfyn_triaging_ida='$triaging_id', fyn_triaging_emailsemails_idb='$emailid'");
    if($decision == 'Lead Created'){
        $db->query("INSERT INTO `fyn_triaging_leads_c` SET id=UUID(), date_modified=NOW(), deleted=0, fyn_triaging_leadsfyn_triaging_ida='$triaging_id', fyn_triaging_leadsleads_idb='$moduleid'");
    }elseif ($decision == 'Case Created') {
        $db->query("INSERT INTO `fyn_triaging_cases_c` SET id=UUID(), date_modified=NOW(), deleted=0, fyn_triaging_casesfyn_triaging_ida='$triaging_id', fyn_triaging_casescases_idb='$moduleid'");
    }
}

$emailsres = $db->query("SELECT emails.id, emails.name, emails_text.from_addr, emails_text.description, emails_text.description_html 
    FROM emails 
    LEFT JOIN emails_text ON emails.id=emails_text.email_id 
    WHERE emails.deleted=0 AND emails.type='inbound' AND (fyn_triaged_c = 0 OR fyn_triaged_c IS NULL)");

$typesubtypeString = "";

if (isset($app_list_strings["case_type_dom"])) {
    $types = "'type': '" . implode("' | '", array_filter($app_list_strings["case_type_dom"])) . "'";
}
// if (isset($app_list_strings["sub_type_list"])) {
//     $subtypes = "'subtype': '" . implode("' | '", array_filter($app_list_strings["sub_type_list"])) . "'";
// }

$prompt = "System:
You are an assistant that classifies inbound emails for SuiteCRM. 
Decide if the email should create a Case, a Lead, or be Ignored (spam/irrelevant). 
Mandatory fields can never be empty.
Mandatory fields for a lead : last_name, email.
Mandatory fields for a case : subject, type.
Always respond in valid JSON format starting with '{' and ending with '}' according to the schema.
{
  'decision': 'Case | Lead | Ignore',
  'case': {
    'subject': 'string',
    'description': 'string',
    'priority': 'P1 | P2 | P3',
    " . $types . "
  },
  'lead': {
    'first_name': 'string',
    'last_name': 'string',
    'title': 'string',
    'phone_mobile': 'string',
    'phone_work': 'string',
    'primary_address_street': 'string',
    'primary_address_city': 'string',
    'primary_address_state': 'string',
    'primary_address_postalcode': 'string',
    'primary_address_country': 'string',
    'description': 'string',
    'website': 'string',
    'email': 'string'
  }
}
Rules:
- If decision = 'Case', only fill the `case` fields.
- If decision = 'Lead', only fill the `lead` fields.
- If decision = 'Ignore', leave both objects empty.";  

if ($emailsres->num_rows > 0) {
    $ids = array();

    while ($emailsrow = $emailsres->fetch_assoc()) {
        $ids[] = $emailid = $emailsrow['id'];
        $updateRes = $db->query("UPDATE emails SET fyn_triaged_c = 1 WHERE id = '$emailid' AND (fyn_triaged_c = 0 OR fyn_triaged_c IS NULL)");
        if ($db->getAffectedRowCount($updateRes) == 0) {
            continue;
        }
        $emailSubject = $emailsrow['name'];
        $htmldescription = preg_replace('/ {3,}/', '  ', strip_tags($emailsrow['description_html']));
        $emailBody = !empty($htmldescription) ? $htmldescription : $emailsrow['description'];
        $emailFrom = $emailsrow['from_addr'];

        $client = new Client();
        $response = $client->post('https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => "Bearer $open_ai_key",
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode([
                'model' => 'gpt-4o-mini',
                'messages' => [
                    ['role' => 'system', 'content' => $prompt],
                    ['role' => 'user', 'content' => "Email record:\nSubject: $emailSubject\nFrom: $emailFrom\nBody: $emailBody\n\nReturn JSON as per schema"]
                ],
                'temperature' => 0
            ])
        ]);

        $result = json_decode($response->getBody(), true);
        $decision = $result['choices'][0]['message']['content'] ?? '{}';
        $data = json_decode($decision, true);

        if (empty($data['decision'])) {
            write_log($logFile, $emailSubject, $emailFrom, 'ParsingError');
            write_dblog($db, $emailSubject, 'ParsingError', $emailid, '', '');
            continue;
        }

        if ($data['decision'] === 'Case') {
            $case = BeanFactory::newBean('Cases');
            $case->name = $data['case']['subject'] ?? $emailSubject;
            $case->description = $data['case']['description'] ?? $emailBody;
            $case->priority = $data['case']['priority'] ?? 'P3';
            $case->type = $data['case']['type'] ?? '';
            // $case->sub_type_c = $data['case']['subtype'] ?? '';
            $case->save();
            $case->load_relationship('emails');
            $case->emails->add($emailsrow['id']);
            if($case->load_relationship('cases_emails_1')){
                if(isset($case->cases_emails_1))
                $case->cases_emails_1->add($emailsrow['id']);
            }
            write_log($logFile, $emailSubject, $emailFrom, 'Case Created');
            $caseString = $db->quote(json_encode(array('name'=>$case->name, 'description'=>$case->description, 'priority'=>$case->priority, 'type'=>$case->type)));
            write_dblog($db, $emailSubject, $caseString, $emailid, 'Case Created', $case->id);
        } elseif ($data['decision'] === 'Lead') {
            $lead = BeanFactory::newBean('Leads');
            $leadArray = array();
            foreach ($data['lead'] as $field => $value) {
                if (!empty($value)) {
                    $lead->$field = $leadArray[$field] = $value;
                }
            }
            $lead->lead_source = "Direct Mail";
            $lead->save();
            $lead->load_relationship('emails');
            $lead->emails->add($emailsrow['id']);

            write_log($logFile, $emailSubject, $emailFrom, 'Lead Created');
            $leadString = $db->quote(json_encode($leadArray));
            write_dblog($db, $emailSubject, $leadString, $emailid, 'Lead Created', $lead->id);
        } elseif ($data['decision'] === 'Ignore') {
            write_log($logFile, $emailSubject, $emailFrom, 'Ignored');
            write_dblog($db, $emailSubject, '', $emailid, 'Ignored', '');
        } else {
            write_log($logFile, $emailSubject, $emailFrom, 'Unknown Decision');
            write_dblog($db, $emailSubject, '', $emailid, 'Unknown Decision', '');
        }
    }
}
flock($fp, LOCK_UN);
fclose($fp);