<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
global $db;

/* ===== PIE DATA ===== */
$decisionCounts = [
    'Case Created' => 0,
    'Lead Created' => 0,
    'Ignored'      => 0,
];

$wherePie = "deleted = 0";

$pie_from    = $_REQUEST['pie_from'] ?? date("Y-m-01");
$pie_to      = $_REQUEST['pie_to'] ?? date("Y-m-d");
$trend_range = $_REQUEST['trend_range'] ?? '7days';
// echo $pie_from." ".$pie_to." ".$trend_range;
if (!empty($pie_from) && !empty($pie_to)) {
    $from = $db->quote($pie_from . " 00:00:00");
    $to   = $db->quote($pie_to . " 23:59:59");
    $wherePie .= " AND date_entered BETWEEN '$from' AND '$to'";
}

$res = $db->query("
    SELECT decision, COUNT(*) cnt
    FROM fyn_triaging
    WHERE $wherePie
    GROUP BY decision
");

while ($row = $db->fetchByAssoc($res)) {
    if (isset($decisionCounts[$row['decision']])) {
        $decisionCounts[$row['decision']] = (int)$row['cnt'];
    }
}
//for testing overriding values
// $decisionCounts = [
//     'Case Created' => 13,
//     'Lead Created' => 19,
//     'Ignored'      => 82,
// ];

/* HARD GUARD: avoid empty charts */
if (array_sum($decisionCounts) === 0) {
    echo "<h3>No triaging data available</h3>";
    return;
}

/* ===== Line Chart DATA ===== */
$dates   = [];
$cases   = [];
$leads   = [];
$ignored = [];
$whereLine = "deleted = 0";
$groupBy   = "";
$dateLabel = "";

switch ($trend_range) {

    // LAST 7 DAYS (DAILY)
    case '7days':
        $whereLine .= " AND date_entered >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)";
        $groupBy = "DATE(date_entered)";
        $dateLabel = "DATE(date_entered)";
        break;

    // THIS MONTH (WEEKLY)
    case 'this_month':
        $whereLine .= " AND MONTH(date_entered) = MONTH(CURDATE())
                        AND YEAR(date_entered) = YEAR(CURDATE())";
        $groupBy = "YEARWEEK(date_entered, 1)";
        $dateLabel = "YEARWEEK(date_entered, 1)";
        break;

    // LAST MONTH (WEEKLY)
    case 'last_month':
        $whereLine .= " AND date_entered >= DATE_FORMAT(CURDATE() - INTERVAL 1 MONTH, '%Y-%m-01')
                        AND date_entered < DATE_FORMAT(CURDATE(), '%Y-%m-01')";
        $groupBy = "YEARWEEK(date_entered, 1)";
        $dateLabel = "YEARWEEK(date_entered, 1)";
        break;

    // LAST 6 MONTHS (MONTHLY)
    case '6months':
        $whereLine .= " AND date_entered >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)";
        $groupBy = "DATE_FORMAT(date_entered, '%Y-%m')";
        $dateLabel = "DATE_FORMAT(date_entered, '%Y-%m')";
        break;
}
$res = $db->query("
    SELECT 
        $dateLabel AS dt,
        SUM(decision='Case Created') cases_cnt,
        SUM(decision='Lead Created') leads_cnt,
        SUM(decision='Ignored') ignored_cnt
    FROM fyn_triaging
    WHERE $whereLine
    GROUP BY $groupBy
    ORDER BY dt ASC
");
if($res->num_rows > 0){
    while ($row = $db->fetchByAssoc($res)) {
        $label = $row['dt'];
        // Convert YEARWEEK to readable label
        if (strpos($label, '-') === false && strlen($label) == 6) {
            $year = substr($label, 0, 4);
            $week = substr($label, 4);
            $label = "W{$week} {$year}";
        }
        $dates[]   = $label;
        $cases[]   = (int)$row['cases_cnt'];
        $leads[]   = (int)$row['leads_cnt'];
        $ignored[] = (int)$row['ignored_cnt'];
    } 
}    


//for testing overriding values
// $dates   = ['12-01-2026','13-01-2026','14-01-2026','15-01-2026'];
// $cases   = [12, 13, 15, 18];
// $leads   = [2, 17, 14, 35];
// $ignored = [120, 130, 150, 180];
/* ===== LOAD RGRAPH ===== */
require_once 'include/SuiteGraphs/RGraphIncludes.php';
?>
<style>
    #fyn_pie_legend {
        font-size: 13px;
        display: inline-block;
    }

    .fyn-legend-row {
        margin-bottom: 10px;
    }

    .fyn-dot {
        display:inline-block;
        width:10px;
        height:10px;
        border-radius:50%;
        background:#4572a7;
        margin-right:6px;
    }

    .fyn-meta {
        color:#666;
        font-size:12px;
    }

/*    .r6{
        display: inline-block; 
        clear:both; 
        width: 49%;
    }*/
</style>
<!-- index.php?module=Administration&action=triagingreport -->
<form method="POST" action="index.php?module=Administration&action=triagingreport"
      style="margin-bottom:20px; display:flex; gap:30px; align-items:flex-end; flex-wrap:wrap;">

    <!-- PIE DATE RANGE -->
    <div>
        <label><strong>Pie Chart Range</strong></label><br>
        <input type="hidden" name="module" value="Administration">
        <input type="hidden" name="action" value="triagingreport">
        <input type="date" name="pie_from" value="<?= htmlspecialchars($pie_from) ?>">
        <input type="date" name="pie_to" value="<?= htmlspecialchars($pie_to) ?>">
    </div>

    <!-- LINE CHART RANGE -->
    <div>
        <label><strong>Trend Range</strong></label><br>
        <select name="trend_range">
            <option value="7days" <?= $trend_range=='7days'?'selected':'' ?>>Last 7 Days</option>
            <option value="this_month" <?= $trend_range=='this_month'?'selected':'' ?>>This Month (Weekly)</option>
            <option value="last_month" <?= $trend_range=='last_month'?'selected':'' ?>>Last Month (Weekly)</option>
            <option value="6months" <?= $trend_range=='6months'?'selected':'' ?>>Last 6 Months (Monthly)</option>
        </select>
    </div>

    <div>
        <button type="submit" class="button primary">Apply Filters</button>
    </div>
</form>


 <!-- style="display:flex; gap:30px; align-items:flex-start; -->
<div class="r6">
    <h2>FynTriaging Report</h2>
    <canvas id="fyn_triaging_pie" width="240" height="240"></canvas>
    <div id="fyn_pie_legend">
        <?php
        $total = array_sum($decisionCounts);
        foreach ($decisionCounts as $label => $count) {
            $percent = $total ? round(($count / $total) * 100, 1) : 0;
            echo "
            <div class='fyn-legend-row'>
                <span class='fyn-dot'></span>
                <strong>{$label}</strong><br>
                <span class='fyn-meta'>{$count} ({$percent}%)</span>
            </div>";
        }
        ?>
    </div>
</div>
<div class="r6">
    <h3 style="margin-top:40px;">Triaging Trend</h3>
    <canvas id="fyn_triaging_line" width="840" height="260"></canvas>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var data   = <?= json_encode(array_values($decisionCounts)) ?>;
    var labels = <?= json_encode(array_keys($decisionCounts)) ?>;
    var pie = new RGraph.Pie({
        id: 'fyn_triaging_pie',
        data: data,
        options: {
            key: [],          // hide legend
            labels: [],       // hide labels
            shadow: true,
            exploded: 5,
            colors: ['#4e79a7', '#59a14f', '#e15759'],
            tooltips: labels.map(function(l, i) {
                return l + ': ' + data[i];
            })
        }
    });
    pie.roundRobin();
    var dots = document.querySelectorAll('.fyn-dot');
    pie.get('colors').forEach(function(c, i){
        if (dots[i]) dots[i].style.backgroundColor = c;
    });
});

var line = new RGraph.Line({
    id: 'fyn_triaging_line',
    data: [
        <?= json_encode($cases) ?>,
        <?= json_encode($leads) ?>,
        <?= json_encode($ignored) ?>
    ],
    options: {
        labels: <?= json_encode($dates) ?>,
        colors: ['#4e79a7', '#59a14f', '#e15759'],
        linewidth: 2,
        tickmarks: 'circle',
        ticksize: 4,
        shadow: false,
        xaxis: true,
        yaxis: true,
        gutterLeft: 50,
        gutterBottom: 60,
        yaxisScaleMax: null,
        textSize: 10,
        backgroundGridVlines: false,
        xaxisLabelsAngle: 45,
        gutterBottom: 60,
        gutterRight: 90,
        keyPosition: 'margin',
        keyPositionX: 60,
        keyPositionY: 20
    }
});

// Animate left → right
line.trace({ frames: 60 });
</script>