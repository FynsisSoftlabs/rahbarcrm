<?php
require_once('modules/Configurator/Configurator.php');
global $sugar_config, $db;  

// 1. License validated
$licenseValid = 1;

// 2. Scheduler: fyn_triaging_scheduler
$sql = "SELECT COUNT(*) AS cnt 
        FROM schedulers 
        WHERE job = 'function::fyn_triaging_scheduler' 
          AND deleted = 0 
          AND status = 'Active'";
$res = $db->fetchByAssoc($db->query($sql));
$fynSchedulerExists = !empty($res['cnt']) && $res['cnt'] > 0;

// 3. Scheduler: pollMonitoredInboxesAOP
$sql = "SELECT COUNT(*) AS cnt 
        FROM schedulers 
        WHERE job = 'function::pollMonitoredInboxesAOP' 
          AND deleted = 0 
          AND status = 'Active'";
$res = $db->fetchByAssoc($db->query($sql));
$aopSchedulerExists = !empty($res['cnt']) && $res['cnt'] > 0;

// 4. Inbound Group Email + Auto Import enabled
$groupInboundOk = false;
$groupInboundDetails = [];

$sql = "SELECT id, name, stored_options 
        FROM inbound_email 
        WHERE deleted = 0 
          AND type = 'group'";
$result = $db->query($sql);

while ($row = $db->fetchByAssoc($result)) {
    $storedOptions = [];
    if (!empty($row['stored_options'])) {
        $storedOptions = @unserialize(base64_decode($row['stored_options']));
    }

    $isAutoImport = !empty($storedOptions['isAutoImport']) && $storedOptions['isAutoImport'] == 1;

    if ($isAutoImport) {
        $groupInboundOk = true;
        $groupInboundDetails[] = $row['name'];
    }
}          

$apiKey     = isset($sugar_config['fyntriaging_api_key']) ? $sugar_config['fyntriaging_api_key'] : '';
// Handle Save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $apiKey = $_POST['api_key'];
    $overrideFile = 'config_override.php';
    require_once 'modules/Administration/QuickRepairAndRebuild.php';
    require_once 'include/utils.php';

    // Update config values
    $cfg = new Configurator();
    $cfg->config['fyntriaging_api_key'] = $apiKey;
    // $cfg->config['fyn_gpt_tables'] = $allowedTbl;
    $cfg->handleOverride();  
    echo '<div style="color: green; font-weight: bold;">Settings saved successfully!</div>';
}
?>
<html>
    <style>
    .checklist {
        border: 1px solid #ccc;
        border-radius: 6px;
        padding: 15px;
        background: #fff;
        margin-bottom: 20px;
    }
    .check-item {
        display: flex;
        align-items: center;
        margin-bottom: 8px;
    }
    .check-item span {
        margin-left: 8px;
    }
    .ok { color: #2ecc71; font-weight: bold; }
    .fail { color: #e74c3c; font-weight: bold; }
    .note { color: #f39c12; font-weight: bold; }

    /* container tweaks: keep columns top-aligned to avoid vertical shifts */
    .container-wrapper {
        display: flex;
        gap: 20px;
        margin-top: 20px;
        align-items: flex-start; /* <-- important */
    }
    .container {
        flex: 1;
        border: 1px solid #ccc;
        border-radius: 6px;
        padding: 10px;
        min-height: 250px;
        background: #f9f9f9;
        box-sizing: border-box;
    }
    .container h3 {
        text-align: center;
        font-size: 16px;
        margin-bottom: 10px;
    }
    /* ensure each item keeps full width and consistent box sizing */
    .table-item {
        padding: 6px 10px;
        margin: 4px 0;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 4px;
        cursor: grab;
        display: block;
        width: 100%;             /* keep consistent width for clones */
        box-sizing: border-box;  /* avoid size jumps */
        -webkit-user-select: none;
        user-select: none;
    }
    .table-item:active { cursor: grabbing; }
    .disabled .table-item {
        background: #eee;
        color: #888;
        cursor: not-allowed;
    }
    .sortable-ghost {
        opacity: 0.85 !important;
        pointer-events: none;
        box-shadow: 0 6px 18px rgba(0,0,0,0.12);
        z-index: 9999;
    }
    .sortable-chosen {
        opacity: 0.6;
    }
    .table-container {
      min-height: 200px;
      max-height: 400px;
      overflow-y: auto;
      border: 1px solid #ccc;
      border-radius: 6px;
      padding: 10px;
      background: #fafafa;
    }
    .table-container .sortable-item {
      padding: 6px 10px;
      margin: 4px 0;
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 4px;
      cursor: grab;
    }
    .table-container .sortable-item.sortable-chosen {
      background: #e6f7ff;
      border-color: #91d5ff;
      cursor: grabbing;
    }
    .table-container .sortable-item.sortable-ghost {
      opacity: 0.5;
    }
    .fix-link {
        margin-left: 10px;
        font-size: 12px;
    }
    .fix-link a {
        color: #2980b9;
        text-decoration: none;
        font-weight: bold;
    }
    .fix-link a:hover {
        text-decoration: underline;
    }
    </style>
    <body style="margin:0; height:100vh; overflow:hidden;">
        <!-- Wrapper that gets its own scrollbar -->
        <div id="fyn-config-wrapper" style="height:100%; overflow-y:auto; padding:20px; box-sizing:border-box;">
            <h2>FynTriaging Configuration</h2>
            <div class="checklist">
                <h3>Setup Checklist</h3>
                <table width="100%" cellpadding="8" cellspacing="0" style="border-collapse:collapse;">
                    <thead>
                        <tr style="background:#f1f1f1;">
                            <th align="left" style="border:1px solid #ccc;">Sl No</th>
                            <th align="left" style="border:1px solid #ccc;">Status</th>
                            <th align="left" style="border:1px solid #ccc;">Name</th>
                            <th align="left" style="border:1px solid #ccc;">Action</th>
                        </tr>
                    </thead>
                    <tbody>

                        <!-- 1. License -->
                        <tr>
                            <td style="border:1px solid #ccc;">1</td>
                            <td style="border:1px solid #ccc;">
                                <?= $licenseValid ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>' ?>
                            </td>
                            <td style="border:1px solid #ccc;">License Validated</td>
                            <td style="border:1px solid #ccc;">
                                <?php if (!$licenseValid): ?>
                                    <a href="index.php?module=Triaging&action=license">Fix it</a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>

                        <!-- 2. Fyn Scheduler -->
                        <tr>
                            <td style="border:1px solid #ccc;">2</td>
                            <td style="border:1px solid #ccc;">
                                <?= $fynSchedulerExists ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>' ?>
                            </td>
                            <td style="border:1px solid #ccc;">
                                FynTriaging Scheduler<br/>
                                <small>(function::fyn_triaging_scheduler)</small>
                            </td>
                            <td style="border:1px solid #ccc;">
                                <?php if (!$fynSchedulerExists): ?>
                                    <a href="index.php?module=Schedulers&action=EditView">Fix it</a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>

                        <!-- 3. AOP Scheduler -->
                        <tr>
                            <td style="border:1px solid #ccc;">3</td>
                            <td style="border:1px solid #ccc;">
                                <?= $aopSchedulerExists ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>' ?>
                            </td>
                            <td style="border:1px solid #ccc;">
                                AOP Inbound Mail Scheduler<br/>
                                <small>(function::pollMonitoredInboxesAOP)</small>
                            </td>
                            <td style="border:1px solid #ccc;">
                                <?php if (!$aopSchedulerExists): ?>
                                    <a href="index.php?module=Schedulers">Fix it</a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>

                        <!-- 4. Inbound Group Email -->
                        <tr>
                            <td style="border:1px solid #ccc;">4</td>
                            <td style="border:1px solid #ccc;">
                                <?= $groupInboundOk ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>' ?>
                            </td>
                            <td style="border:1px solid #ccc;">
                                Inbound Group Email<br/>
                                <small>Auto Import Enabled</small>
                                <?php if ($groupInboundOk): ?>
                                    <div style="font-size:11px;color:#555;">
                                        Found: <?= htmlspecialchars(implode(', ', $groupInboundDetails)) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td style="border:1px solid #ccc;">
                                <?php if (!$groupInboundOk): ?>
                                    <a href="index.php?module=InboundEmail">Fix it</a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>

                        <!-- 5. Cron -->
                        <tr>
                            <td style="border:1px solid #ccc;">5</td>
                            <td style="border:1px solid #ccc;">
                                <span class="note">⚠</span>
                            </td>
                            <td style="border:1px solid #ccc;">
                                System Cron (crontab) must be running
                            </td>
                            <td style="border:1px solid #ccc;">Manual Check</td>
                        </tr>

                    </tbody>
                </table>
            </div>
            <form method="POST" action="">
                <input type="submit" value="Save Settings" /><br/>
                <!-- API Key -->
                <label>API Key:</label><br/>
                <input type="text" name="api_key" value="<?= htmlspecialchars($apiKey) ?>" size="50"/><br/><br/> 
                <br/>
                <input type="submit" value="Save Settings" />
            </form>
        </div>
    </body>
</html>