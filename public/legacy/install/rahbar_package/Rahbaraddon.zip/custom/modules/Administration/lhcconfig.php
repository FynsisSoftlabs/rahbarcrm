<?php
require_once('modules/Configurator/Configurator.php');

global $sugar_config, $current_user;

// 1. License validation
$licenseValid = TRUE;

// 2. Knowledge Base URL (stored only for reference)
$kbUrl = isset($sugar_config['livehelperchat_kb_url'])
    ? $sugar_config['livehelperchat_kb_url']
    : '';

// Handle Save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kbUrl = trim($_POST['kb_url']);

    $cfg = new Configurator();
    $cfg->config['livehelperchat_kb_url'] = $kbUrl;
    $cfg->handleOverride();

    echo '<div style="color: green; font-weight: bold; margin-bottom:10px;">
            Settings saved successfully!
          </div>';
}
?>

<html>
<style>
.checklist {
    border: 1px solid #ccc;
    border-radius: 6px;
    padding: 15px;
    background: #fff;
    margin-bottom: 20px;
}
.ok { color: #2ecc71; font-weight: bold; }
.fail { color: #e74c3c; font-weight: bold; }
.note { color: #f39c12; font-weight: bold; }
</style>

<body style="margin:0; height:100vh; overflow:hidden;">
<div style="height:100%; overflow-y:auto; padding:20px; box-sizing:border-box;">

    <h2>LiveHelperChat Configuration</h2>

    <div class="checklist">
        <h3>Setup Checklist</h3>

        <table width="100%" cellpadding="8" cellspacing="0" style="border-collapse:collapse;">
            <thead>
                <tr style="background:#f1f1f1;">
                    <th align="left" style="border:1px solid #ccc;">Sl No</th>
                    <th align="left" style="border:1px solid #ccc;">Status</th>
                    <th align="left" style="border:1px solid #ccc;">Name</th>
                    <th align="left" style="border:1px solid #ccc;">Action</th>
                </tr>
            </thead>
            <tbody>

                <!-- 1. License -->
                <tr>
                    <td style="border:1px solid #ccc;">1</td>
                    <td style="border:1px solid #ccc;">
                        <?= $licenseValid == 1
                            ? '<span class="ok">✔</span>'
                            : '<span class="fail">✖</span>' ?>
                    </td>
                    <td style="border:1px solid #ccc;">
                        LiveHelperChat License Validated
                    </td>
                    <td style="border:1px solid #ccc;">
                        <?php if ($licenseValid != 1): ?>
                            <a href="/#/LiveHelperChat/license" target="_blank">
                                Fix it
                            </a>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                </tr>

            </tbody>
        </table>
    </div>

    <!-- Knowledge Base URL -->
    <form method="POST" action="">
        <h3>Reference Settings</h3>

        <label>
            Knowledge Base URL
            <small style="color:#666;">
                (For reminder purposes only — does not affect setup)
            </small>
        </label><br/>

        <input
            type="text"
            name="kb_url"
            size="80"
            placeholder="https://url.to.livehelper.knowledgebase.directory"
            value="<?= htmlspecialchars($kbUrl) ?>"
        />
        <br/><br/>

        <input type="submit" value="Save Settings" />
    </form>

</div>
</body>
</html>