<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
require_once('modules/Configurator/Configurator.php');
global $sugar_config, $app_list_strings;
$licenseValid = TRUE;
$jsFile  = 'custom/fynqol/style.js';
$cssFile = 'custom/fynqol/style.css';

/* ══════════════════════════════════════════════════════
   HELPERS
══════════════════════════════════════════════════════ */
function slugify($str) {
    return strtolower(preg_replace('/\s+/', '-', trim($str)));
}

function generateJs($listbg_enabled, $listbg_color, $hasHomepageBg=false, $homepageBg='#F5F5F5', $homepageText='#777777', $navText='#000000') {
    $js = <<<JS
function colorizeEnum(columnClass, prefix, root = document) {
    root.querySelectorAll("td." + columnClass).forEach(td => {
        const el = td.querySelector("scrm-dropdownenum-detail");
        if (!el) return;
        const slug = el.innerText.trim()
            .toLowerCase()
            .replace(/\\s+/g, "-");
        td.classList.forEach(cls => {
            if (cls.startsWith(prefix + "-")) {
                td.classList.remove(cls);
            }
        });
        td.classList.add(prefix + "-" + slug);
    });
}
function applyColors(root = document) {
    colorizeEnum("column-status", "status", root);
    colorizeEnum("column-state", "state", root);
}
JS;
    if ($hasHomepageBg) {
        $js .= <<<JS
function handleIframe(iframe) {
    if (!iframe || iframe.dataset.processed) return;
    iframe.dataset.processed = "true";
    iframe.addEventListener("load", () => {
        const doc = iframe.contentDocument || iframe.contentWindow.document;
        if (!doc) return;
        function injectStyles() {
            if (!doc.getElementById("custom-style")) {
                const style = doc.createElement("style");
                style.id = "custom-style";
                style.innerHTML = `
                    body { background-color: ${homepageBg} !important; }
                    .dashletNonTable { background-color: #fff !important; }
                    .module-title-text, .header-module-title, .moduleTitle h2, .fc-ltr .fc-axis { color: ${homepageText} !important; }`;
                doc.head.appendChild(style);
            }
        }
        injectStyles();
        applyColors(doc);
        new MutationObserver(() => {
            injectStyles();
            applyColors(doc);
        }).observe(doc.body, {
            childList: true,
            subtree: true
        });
    });
}
function observeAppChanges() {
    let lastUrl = location.href;
    new MutationObserver(() => {
        // Detect URL change (SPA navigation)
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            onRouteChange();
        }
        document.querySelectorAll("iframe").forEach(handleIframe);
    }).observe(document.body, {
        childList: true,
        subtree: true
    });
}
function onRouteChange() {
    applyColors();
    document.querySelectorAll("iframe").forEach(handleIframe);
}
JS;
    }
    $js .= <<<JS
document.addEventListener("DOMContentLoaded", () => {
    applyColors();
    observeAppChanges(); // 🔥 THIS replaces interval completely
    new MutationObserver(() => applyColors()).observe(document.body, {
        childList: true,
        subtree: true
    });
JS;
    if ($listbg_enabled) {
        $js .= <<<JS
    document.addEventListener("click", function (e) {
        const row = e.target.closest("tr");
        if (!row) return;
        document.querySelectorAll("tr").forEach(tr => {
            tr.style.backgroundColor = "";
        });
        row.style.backgroundColor = "{$listbg_color}";
    });
JS;
    }
    if ($hasHomepageBg) {
        $js .= <<<JS
    // setupIframeHandling();
JS;
    }
    $js .= "\n});\n";
    return $js;
}

function generateCss($enabled, $colors) {
    // if (!$enabled) {
    //     return "/* Auto Generated - Disabled */\n\n";
    // }
    $css = "/* Auto Generated - Do Not Edit */\n\n";
    $css .= <<<CSS
td.column-status scrm-dropdownenum-detail,
td.column-state scrm-dropdownenum-detail {
    padding: 4px 10px;
    border-radius: 12px;
    font-size: .85rem;
    font-weight: 600;
    display: inline-block;
}
CSS;
    // Status & State badge colors
    foreach ($colors as $type => $values) {
        if (!$enabled || ($type !== 'state' && $type !== 'status')) continue;
        foreach ($values as $label => $colorData) {
            $slug    = slugify($label);
            $bgColor = is_array($colorData) ? $colorData['bg']   : $colorData;
            $txColor = is_array($colorData) ? $colorData['text'] : '#ffffff';
            $css .= ".{$type}-{$slug} scrm-dropdownenum-detail {\n";
            $css .= "    background: {$bgColor};\n";
            $css .= "    color: {$txColor};\n";
            $css .= "}\n";
        }
    }
    // Navbar
    if (isset($colors['navbar'])) {
        $navBg   = $colors['navbar']['bg'] ?? '#534d64';
        $navText = $colors['navbar']['text'] ?? '#dddbe0';
        if($navBg != "#534d64" && $navText != "#dddbe0"){
        $css .= <<<CSS

/* Navigation Bar */
.navbar-nav a:not([href]):not([tabindex]):focus, .navbar-nav a:not([href]):not([tabindex]):hover, .global-links a:not([href]):not([tabindex]):focus, .global-links a:not([href]):not([tabindex]):hover, .top-panel.fixed-top,
.navbar, .navbar.mobile-nav-block.mobilenavbar {
    background-color: {$navBg} !important;
    color: {$navText} !important;
}
.top-nav-link,
.top-nav a,
.nav-link,
.primary-global-link,
.global-action-icon,
.action-link {
    color: {$navText} !important;
}
CSS;
    } }
    // Pagination
    if (isset($colors['pagination'])) {
        $paginationBg   = $colors['pagination']['bg'] ?? '#76858f';
        $paginationText = $colors['pagination']['text'] ?? '#ffffff';
        if($paginationBg != "#76858f" && $paginationText != "#ffffff"){
        $css .= <<<CSS
/* Pagination */
.list-view-tableactions > div {
    background-color: {$paginationBg} !important;
}
.pagination-count, .pagination-button, .bulk-action-button {
    color: {$paginationText} !important;
}

CSS;
    } }
    // List View Header
    if (isset($colors['header'])) {
        $headerBg   = $colors['header']['bg'] ?? '#93a4b3';
        $headerText = $colors['header']['text'] ?? '#ffffff';
        if($headerBg != "#93a4b3" && $headerText != "#ffffff"){
        $css .= <<<CSS
/* List View Header */
.cdk-header-row,
.primary-table-header {
    background-color: {$headerBg} !important;
    color: {$headerText} !important;
}
.cdk-header-cell scrm-label,
.primary-table-header scrm-label {
    color: {$headerText} !important;
}
CSS;
    } }
    // Homepage Background
    if (isset($colors['homepage_bg'])) { 
        $homepageBg = $colors['homepage_bg']['bg'] ?? '#f5f5f5';
        $homepageText = $colors['homepage_bg']['text'] ?? '#777777';
        if($homepageBg != "#f5f5f5" && $homepageText != "#777777"){
        $css .= <<<CSS
/* Homepage Background */
body,
.admin-view,
.list-view,
.list-view-header,
.record-view,
.record-view-header,
.footer {
    background-color: {$homepageBg} !important;
}
.striped-table tbody tr:nth-of-type(even) {
    background-color: #fff;
}
.dynamic-label, .list-view-title, .module-title-text, .header-module-title, .pagecontent{
    color: {$homepageText} !important;
}
CSS;
    } }

    // Dropdown
    if (isset($colors['dropdown'])) {
        $dropdownBg   = $colors['dropdown']['bg'] ?? '#666176';
        $dropdownText = $colors['dropdown']['text'] ?? '#ffffff';
        if($dropdownBg != "#666176" && $dropdownText != "#ffffff"){
        $css .= <<<CSS
/* Dropdown */
.dropdown-submenu,
.nav-link:not(.primary-global-link) {
    background-color: {$dropdownBg} !important;
    color: {$dropdownText} !important;
}
scrm-image g{ 
    fill: {$paginationText} !important; 
}
.navbar scrm-image g path, .navbar scrm-image g polygon, .navbar scrm-image g{
    fill: {$navText} !important;
}
.sub-nav-link scrm-image, .sub-nav-link scrm-image g, .sub-nav-link scrm-image g path, .sub-nav-link scrm-image g polygon{
    fill: {$navBg} !important;
}
CSS;
    } }
    return $css;
}

/* ══════════════════════════════════════════════════════
   POST HANDLER
══════════════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $configurator = new Configurator();
    $configurator->loadConfig();
    if (isset($_POST['fynqol_submit'])) {
        if($licenseValid != 1){
            echo "Please validate license";
            exit;
        }
        $enabled         = isset($_POST['fynqol_enabled'])     ? 1 : 0;
        $listbg_enabled  = isset($_POST['fynqol_listbg'])      ? 1 : 0;
        $listbg_color    = isset($_POST['fynqol_listbg_color']) ? $_POST['fynqol_listbg_color'] : '#FADBB3';

        // Decode the colours JSON sent from JS hidden field
        $colours_raw = isset($_POST['fynqol_colours']) ? $_POST['fynqol_colours'] : '';
        $colours     = [];

        if (!empty($colours_raw)) {
            $colours_raw = html_entity_decode($colours_raw);
            $colours_raw = stripslashes($colours_raw);
            $decoded = json_decode($colours_raw, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                $colours = $decoded;
            } else {
                echo json_last_error_msg();
                exit;
            }
            if (is_array($decoded)) {
                $colours = $decoded;
            }
        }
        // --- Build $savedColors in the shape generateCss() expects ---
        // colours from JS: { state: [{label,bg,text},...], status: [{label,bg,text},...] }
        // CSS generator expects: { state: { 'Label' => ['bg'=>..,'text'=>..] }, ... }
        $savedColors = [];
        foreach (['state', 'status'] as $type) {
            if (!empty($colours[$type]) && is_array($colours[$type])) {
                foreach ($colours[$type] as $item) {
                    $label = $item['label'];
                    $savedColors[$type][$label] = [
                        'bg'   => $item['bg'],
                        'text' => $item['text'],
                    ];
                }
            }
        }

        // Navbar, pagination, header from simple pickers
        if (!empty($colours['navbar'])) {
            $savedColors['navbar'] = $colours['navbar'];
        } else {
            // fall back to individual hidden fields if you prefer
            if (!empty($_POST['cf_navbar_bg'])) {
                $savedColors['navbar'] = [
                    'bg'   => $_POST['cf_navbar_bg'] ?? '#534d64',
                    'text' => $_POST['cf_navbar_text'] ?? '#dddbe0',
                ];
            }
        }
        if (!empty($colours['pagination'])) {
            $savedColors['pagination'] = $colours['pagination'];
        } else {
            if (!empty($_POST['cf_pag_bg'])) {
                $savedColors['pagination'] = [
                    'bg'   => $_POST['cf_pag_bg'] ?? '#76858f',
                    'text' => $_POST['cf_pag_text'] ?? '#ffffff',
                ];
            }
        }
        if (!empty($colours['header'])) {
            $savedColors['header'] = $colours['header'];
        } else {
            if (!empty($_POST['cf_header_bg'])) {
                $savedColors['header'] = [
                    'bg'   => $_POST['cf_header_bg'] ?? '#93a4b3',
                    'text' => $_POST['cf_header_text'] ?? '#ffffff',
                ];
            }
        }

        // Homepage Background
        if (!empty($colours['homepage_bg'])) {
            $savedColors['homepage_bg'] = $colours['homepage_bg'];
        } else {
            if (!empty($_POST['cf_homepage_bg'])) {
                $savedColors['homepage_bg'] = [
                    'bg' => $_POST['cf_homepage_bg'] ?? '#F5F5F5',
                    'text' => $_POST['cf_homepage_text'] ?? '#777777',
                ];
            }
        }

        // Dropdown
        if (!empty($colours['dropdown'])) {
            $savedColors['dropdown'] = $colours['dropdown'];
        } else {
            if (!empty($_POST['cf_dropdown_bg'])) {
                $savedColors['dropdown'] = [
                    'bg'   => $_POST['cf_dropdown_bg'] ?? '#666176',
                    'text' => $_POST['cf_dropdown_text'] ?? '#FFFFFF',
                ];
            }
        }

        // --- Generate JS & CSS from the just-posted values (not from sugar_config) ---
        $dir = dirname($jsFile);
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $hasHomepageBg = !empty($savedColors['homepage_bg']);
        $homepageBg = $savedColors['homepage_bg']['bg'] ?? '#f5f5f5';
        $homepagetext = $savedColors['homepage_bg']['text'] ?? '#777777';
        $navText = $savedColors['navbar']['text'] ?? '#dddbe0';
        file_put_contents($jsFile,  generateJs($listbg_enabled, $listbg_color, $hasHomepageBg, $homepageBg, $homepagetext, $navText));
        // print_r($savedColors);exit;
        file_put_contents($cssFile, generateCss($enabled, $savedColors));

        // --- Persist to config_override.php ---
        $configurator->config['fyn_qol_enabled']      = $enabled;
        $configurator->config['fyn_qol_listbg']        = $listbg_enabled;
        $configurator->config['fyn_qol_listbg_color']  = $listbg_color;
        $configurator->config['fyn_qol_colors']        = serialize($savedColors);
    } elseif (isset($_POST['fynqol_reset'])) {

        // Reset to defaults
        file_put_contents($jsFile,  generateJs(0, '#FADBB3', false, '#f5f5f5', '#777777', '#dddbe0'));
        file_put_contents($cssFile, generateCss(0, []));

        $configurator->config['fyn_qol_colors']       = '';
        $configurator->config['fyn_qol_enabled']      = 0;
        $configurator->config['fyn_qol_listbg']       = 0;
        $configurator->config['fyn_qol_listbg_color'] = '#FADBB3';
    }

    $configurator->saveConfig();
    header('Location: ' . $_SERVER['REQUEST_URI']);
    exit;
}

/* ══════════════════════════════════════════════════════
   LOAD SAVED CONFIG FOR FORM PRE-FILL
══════════════════════════════════════════════════════ */
$saved_enabled        = isset($sugar_config['fyn_qol_enabled'])     ? (int)$sugar_config['fyn_qol_enabled']     : 0;
$saved_listbg         = isset($sugar_config['fyn_qol_listbg'])       ? (int)$sugar_config['fyn_qol_listbg']       : 0;
$saved_listbg_color   = isset($sugar_config['fyn_qol_listbg_color']) ? $sugar_config['fyn_qol_listbg_color']     : '#fadbb3';
$saved_colors_raw     = isset($sugar_config['fyn_qol_colors'])        ? $sugar_config['fyn_qol_colors']           : '';
$saved_colors         = [];
if (!empty($saved_colors_raw)) {
    $unserialized = @unserialize($saved_colors_raw);
    if (is_array($unserialized)) $saved_colors = $unserialized;
}

// Build JS-friendly color arrays for pre-filling the pickers
// Shape needed by JS: { state:[{label,bg,text}], status:[{label,bg,text}], navbar:{bg,text}, ... }
$js_saved_config = [
    'enabled'      => (bool)$saved_enabled,
    'listbg'       => (bool)$saved_listbg,
    'listbg_color' => $saved_listbg_color,
    'colors'       => [
        'state'      => [],
        'status'     => [],
        'navbar'     => $saved_colors['navbar']     ?? ['bg' => '#534d64', 'text' => '#dddbe0'],
        'pagination' => $saved_colors['pagination'] ?? ['bg' => '#76858f', 'text' => '#ffffff'],
        'header'     => $saved_colors['header']     ?? ['bg' => '#93a4b3', 'text' => '#ffffff'],
    ],
    'homepage_bg' => $saved_colors['homepage_bg'] ?? ['bg' => '#f5f5f5', 'text'=> '#777777'],
    'dropdown'    => $saved_colors['dropdown']    ?? ['bg' => '#666176', 'text' => '#ffffff'],
];
foreach (['state', 'status'] as $type) {
    if (!empty($saved_colors[$type])) {
        foreach ($saved_colors[$type] as $label => $cd) {
            $js_saved_config['colors'][$type][] = [
                'label' => $label,
                'bg'    => is_array($cd) ? $cd['bg']   : $cd,
                'text'  => is_array($cd) ? $cd['text'] : '#ffffff',
            ];
        }
    }
}
?>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Fynsis QoL Config</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg: #0f1117;
  --surface: #181c27;
  --surface2: #1e2333;
  --border: #2a3048;
  --border-light: #323a56;
  --text: #e2e8f0;
  --text-muted: #6b7ea8;
  --accent: #4f8fff;
  --accent-glow: rgba(79,143,255,0.15);
  --accent2: #7c5cff;
  --success: #22d3a8;
  --panel-left: 430px;
  --radius: 8px;
  --radius-sm: 5px;
}

html, body { height: 100%; overflow: hidden; }
body {
  font-family: 'Syne', sans-serif;
  background: var(--bg);
  color: var(--text);
  display: flex;
  flex-direction: column;
}

/* ── Topbar ── */
.topbar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 24px; height: 52px;
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}
.topbar-brand { display: flex; align-items: center; gap: 10px; }
.topbar-logo {
  width: 28px; height: 28px;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  border-radius: 6px;
  display: flex; align-items: center; justify-content: center;
  font-size: 14px;
}
.topbar-title { font-size: 15px; font-weight: 700; letter-spacing: -0.02em; }
.topbar-title span { color: var(--accent); }
.topbar-actions { display: flex; gap: 10px; }
.btn {
  padding: 7px 18px; border-radius: var(--radius-sm);
  font-family: 'Syne', sans-serif; font-size: 13px; font-weight: 600;
  border: none; cursor: pointer; transition: all 0.2s;
}
.btn-primary { background: var(--accent); color: #fff; }
.btn-primary:hover { background: #3a7aee; box-shadow: 0 0 20px var(--accent-glow); }
.btn-ghost { background: var(--surface2); color: var(--text-muted); border: 1px solid var(--border); }
.btn-ghost:hover { border-color: var(--border-light); color: var(--text); }

/* ── Layout ── */
.main { display: flex; flex: 1; overflow: hidden; }

/* ── Left Panel ── */
.config-panel {
  width: var(--panel-left); flex-shrink: 0;
  background: var(--surface);
  border-right: 1px solid var(--border);
  display: flex; flex-direction: column; overflow: hidden;
}
.config-panel-inner {
  overflow-y: auto; padding: 20px; flex: 1;
  scrollbar-width: thin; scrollbar-color: var(--border) transparent;
}
.config-panel-inner::-webkit-scrollbar { width: 4px; }
.config-panel-inner::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }

/* ── Sections ── */
.config-section { margin-bottom: 24px; }
.section-header { display: flex; align-items: center; gap: 10px; margin-bottom: 14px; }
.section-icon {
  width: 28px; height: 28px; border-radius: 6px;
  display: flex; align-items: center; justify-content: center;
  font-size: 13px; flex-shrink: 0;
}
.section-title {
  font-size: 12px; font-weight: 700;
  text-transform: uppercase; letter-spacing: 0.08em;
  color: var(--text-muted);
}

/* ── Toggle ── */
.toggle-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 14px;
  background: var(--surface2); border: 1px solid var(--border); border-radius: var(--radius);
  margin-bottom: 14px;
}
.toggle-label { font-size: 13px; font-weight: 600; color: var(--text); }
.toggle-desc { font-size: 11px; color: var(--text-muted); margin-top: 2px; }
.toggle-switch { position: relative; width: 40px; height: 22px; flex-shrink: 0; }
.toggle-switch input { opacity: 0; width: 0; height: 0; }
.toggle-slider {
  position: absolute; cursor: pointer; inset: 0;
  background: var(--border); border-radius: 22px; transition: 0.3s;
}
.toggle-slider::before {
  content: ''; position: absolute;
  width: 16px; height: 16px; left: 3px; bottom: 3px;
  background: white; border-radius: 50%; transition: 0.3s;
}
.toggle-switch input:checked + .toggle-slider { background: var(--accent); }
.toggle-switch input:checked + .toggle-slider::before { transform: translateX(18px); }

/* ── Color Table ── */
.color-table { width: 100%; border-collapse: collapse; font-size: 12px; }
.color-table thead th {
  padding: 7px 10px; text-align: left;
  color: var(--text-muted); font-weight: 600; font-size: 10px;
  text-transform: uppercase; letter-spacing: 0.06em;
  border-bottom: 1px solid var(--border);
}
.color-table tbody tr { border-bottom: 1px solid var(--border); transition: background 0.15s; }
.color-table tbody tr:hover { background: rgba(79,143,255,0.04); }
.color-table tbody tr:last-child { border-bottom: none; }
.color-table td { padding: 8px 10px; vertical-align: middle; }
.value-label {
  font-size: 12px; font-weight: 600;
  font-family: 'DM Mono', monospace; color: var(--text);
}

.cp-wrap { display: flex; align-items: center; gap: 8px; }
.cp-trigger-wrap {
  position: relative; width: 32px; height: 26px; flex-shrink: 0;
  border-radius: 5px; border: 2px solid var(--border-light);
  cursor: pointer; overflow: hidden; transition: border-color 0.15s;
}
.cp-trigger-wrap:hover { border-color: var(--accent); }
.cp-swatch { width: 100%; height: 100%; display: block; pointer-events: none; }
.cp-input-hidden {
  position: absolute; top: -4px; left: -4px;
  width: calc(100% + 8px); height: calc(100% + 8px);
  opacity: 0; cursor: pointer; border: none; padding: 0; margin: 0;
}
.cp-hex {
  width: 74px; padding: 5px 8px; background: #0d1117;
  border: 1px solid var(--border-light); border-radius: 4px;
  color: #c9d1d9; font-family: 'DM Mono', monospace;
  font-size: 11px; letter-spacing: 0.04em;
}
.cp-hex:focus { outline: none; border-color: var(--accent); }

/* ── Badge preview ── */
.badge-preview {
  display: inline-block; padding: 2px 9px;
  border-radius: 10px; font-size: 10px; font-weight: 700;
  font-family: 'DM Mono', monospace; white-space: nowrap;
}

/* ── Color Row ── */
.color-row {
  display: flex; align-items: center; gap: 12px; padding: 12px 14px;
  background: var(--surface2); border: 1px solid var(--border); border-radius: var(--radius);
  margin-bottom: 10px; flex-wrap: wrap;
}
.color-row-label { font-size: 12px; font-weight: 600; color: var(--text-muted); min-width: 80px; }
.color-field { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 150px; }
.color-field-label { font-size: 11px; color: var(--text-muted); white-space: nowrap; }

/* ── Scrollable list ── */
.color-list-wrap {
  background: var(--surface2); border: 1px solid var(--border); border-radius: var(--radius);
  overflow: hidden; max-height: 260px; overflow-y: auto;
  scrollbar-width: thin; scrollbar-color: var(--border) transparent;
  margin-bottom: 12px;
}
.color-list-wrap::-webkit-scrollbar { width: 4px; }
.color-list-wrap::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }

/* ── Theme Selector ── */
.theme-selector-wrap {
  padding: 16px 20px;
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}
.theme-selector-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;
}
.theme-cards-container {
  display: flex;
  gap: 14px;
  overflow-x: auto;
  overflow-y: hidden;
  padding: 2px;
  scrollbar-width: thin;
  scrollbar-color: var(--border) transparent;
}
.theme-cards-container::-webkit-scrollbar { height: 6px; }
.theme-cards-container::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }

.theme-card {
  flex-shrink: 0;
  width: 280px;
  height: 200px;
  border-radius: var(--radius);
  overflow: hidden;
  border: 2px solid var(--border);
  background: var(--surface2);
  display: flex;
  flex-direction: column;
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
}
.theme-card:hover {
  border-color: var(--accent);
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0,0,0,0.3);
}
.theme-card.selected {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px rgba(79,143,255,0.2);
}
.theme-card-radio {
  position: absolute;
  top: 10px;
  right: 10px;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  border: 2px solid var(--border-light);
  background: var(--surface2);
  z-index: 10;
  transition: all 0.2s;
}
.theme-card.selected .theme-card-radio {
  border-color: var(--accent);
  background: var(--accent);
  box-shadow: inset 0 0 0 4px var(--surface2);
}
.theme-title {
  padding: 8px 12px;
  font-size: 12px;
  font-weight: 700;
  background: rgba(0,0,0,0.3);
  color: var(--text);
  border-bottom: 1px solid var(--border);
  text-transform: uppercase;
  letter-spacing: 0.06em;
}
.theme-preview {
  flex: 1;
  overflow: hidden;
  position: relative;
  background: #f0f2f7;
}
.theme-preview-inner {
  transform: scale(0.55);
  transform-origin: top left;
  width: 182%;
  height: 182%;
  pointer-events: none;
}

/* ── Preview Panel ── */
.preview-panel {
  flex: 1; display: flex; flex-direction: column; overflow: hidden;
  background: #f0f2f7;
}
.preview-label-bar {
  display: flex; align-items: center; gap: 8px; padding: 8px 16px;
  background: var(--surface2); border-bottom: 1px solid var(--border); flex-shrink: 0;
}
.preview-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--success); animation: pulse 2s infinite; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
.preview-label-text { font-size: 11px; color: var(--text-muted); font-weight: 600; text-transform: uppercase; letter-spacing: .06em; }

/* ── SCRM Preview ── */
.scrm-wrap { flex: 1; overflow: hidden; display: flex; flex-direction: column; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 14px; }
.preview-navbar {
  padding: 0 20px; display: flex; align-items: center; gap: 4px;
  height: 48px; flex-shrink: 0; transition: background-color .3s, color .3s;
}
.nav-logo { font-weight: 700; font-size: 16px; margin-right: 16px; }
.nav-item { padding: 6px 12px; border-radius: 4px; font-size: 13px; cursor: pointer; opacity: .9; transition: opacity .2s, background .2s; }
.nav-item:hover { opacity: 1; background: rgba(255,255,255,.1); }
.nav-item.active { opacity: 1; font-weight: 600; }
.nav-spacer { flex: 1; }
.nav-icon { width: 32px; height: 32px; border-radius: 50%; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 14px; cursor: pointer; }
.scrm-content { flex: 1; overflow: hidden; display: flex; flex-direction: column; padding: 16px 20px; background: #f0f2f7; }
.page-title { font-size: 20px; font-weight: 700; color: #333; margin-bottom: 12px; letter-spacing: -.01em; }
.preview-pagination {
  display: flex; align-items: center; justify-content: space-between;
  padding: 8px 14px; border-radius: 6px 6px 0 0;
  border: 1px solid #dde2ea; border-bottom: none;
  transition: background-color .3s, color .3s;
}
.pag-left { display: flex; align-items: center; gap: 8px; }
.pag-btn { padding: 4px 8px; border: 1px solid #ccc; background: rgba(255,255,255,.6); border-radius: 4px; font-size: 13px; cursor: pointer; }
.pag-count { font-size: 13px; font-weight: 500; }
.bulk-btn { padding: 5px 12px; border: 1px solid #ccc; border-radius: 4px; background: rgba(255,255,255,.6); font-size: 12px; cursor: pointer; display: flex; align-items: center; gap: 6px; }
.list-table-wrap { border: 1px solid #dde2ea; border-radius: 0 0 6px 6px; overflow: hidden; flex: 1; overflow-y: auto; background: #fff; }
.list-table { width: 100%; border-collapse: collapse; }
.preview-header th {
  padding: 10px 12px; text-align: left; font-size: 12px; font-weight: 700;
  letter-spacing: .03em; border-right: 1px solid rgba(0,0,0,.06);
  transition: background-color .3s, color .3s; cursor: pointer; white-space: nowrap;
}
.preview-header th:last-child { border-right: none; }
.sort-icon { opacity: .5; margin-left: 4px; font-size: 9px; }
.list-table tbody tr { border-bottom: 1px solid #f0f2f7; transition: background-color .2s; cursor: pointer; }
.list-table tbody tr:hover { background: #f7f9fc !important; }
.list-table td { padding: 9px 12px; font-size: 13px; color: #374151; vertical-align: middle; border-right: 1px solid #f0f2f7; }
.list-table td:last-child { border-right: none; }
.record-link { color: #1a56db; text-decoration: none; font-weight: 600; }
.record-link:hover { text-decoration: underline; }
.state-badge { display: inline-block; padding: 3px 10px; border-radius: 10px; font-size: 11px; font-weight: 700; white-space: nowrap; }
.status-badge { display: inline-block; padding: 3px 10px; border-radius: 10px; font-size: 11px; font-weight: 700; white-space: nowrap; }
.row-actions { display: flex; align-items: center; gap: 4px; }
.row-action-btn { width: 28px; height: 28px; border-radius: 4px; border: none; background: #f0f2f7; color: #6b7280; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 12px; }
.row-action-btn:hover { background: #e5e7eb; }
.cb-cell { width: 36px; }
.checkbox-fake { width: 14px; height: 14px; border: 2px solid #d1d5db; border-radius: 3px; display: inline-block; }
</style>
</head>
<body>

<form method="POST" action="" id="fynqol-form">
  <!-- Hidden fields populated by JS on submit -->
  <input type="hidden" name="fynqol_submit"      value="1">
  <input type="hidden" name="fynqol_colours"     id="h_fynqol_colours">
  <input type="hidden" name="fynqol_listbg_color" id="h_fynqol_listbg_color">

<div class="topbar">
  <div class="topbar-brand">
    <div class="topbar-logo">🎨</div>
    <div class="topbar-title">Fynsis <span>QoL</span> Config</div>
  </div>
  <div class="topbar-actions">
    <button type="submit" name="fynqol_reset" value="1" class="btn btn-ghost" onclick="return confirm('Reset all settings to defaults?')">Reset</button>
    <button type="submit" class="btn btn-primary" id="save-btn">Save Config</button>
  </div>
</div>

<!-- ══ THEME SELECTOR ══ -->
<div class="theme-selector-wrap">
  <div class="theme-selector-header">
    <div class="section-icon" style="background:rgba(124,92,255,.12);width:32px;height:32px;font-size:16px">🎨</div>
    <div style="flex:1">
      <div style="font-size:14px;font-weight:700;color:var(--text);letter-spacing:-0.01em">Quick Themes</div>
      <div style="font-size:11px;color:var(--text-muted);margin-top:2px">Select a pre-defined color scheme</div>
    </div>
  </div>
  <div class="theme-cards-container" id="theme-cards-container">
    <!-- Theme cards will be generated here by JavaScript -->
  </div>
</div>

<div class="main">

  <!-- ══ LEFT CONFIG PANEL ══ -->
  <div class="config-panel">
    <div class="config-panel-inner">

      <!-- 1. Colored Status -->
      <div class="config-section">
        <div class="section-header">
          <div class="section-icon" style="background:rgba(79,143,255,.15)">🏷️</div>
          <div class="section-title">Colored Status</div>
        </div>
        <div class="toggle-row">
          <div>
            <div class="toggle-label">Enable Colored Status</div>
            <div class="toggle-desc">Applies badge colors to Status &amp; State columns</div>
          </div>
          <label class="toggle-switch">
            <input type="checkbox" id="fynqol_enabled" name="fynqol_enabled" value="1" onchange="toggleColorSection()">
            <span class="toggle-slider"></span>
          </label>
        </div>
        <div id="color-section">
          <div style="font-size:11px;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">State</div>
          <div class="color-list-wrap">
            <table class="color-table">
              <thead><tr><th>Value</th><th>Background</th><th>Text</th><th>Preview</th></tr></thead>
              <tbody id="state-tbody"></tbody>
            </table>
          </div>
          <div style="font-size:11px;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">Status</div>
          <div class="color-list-wrap">
            <table class="color-table">
              <thead><tr><th>Value</th><th>Background</th><th>Text</th><th>Preview</th></tr></thead>
              <tbody id="status-tbody"></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- 2. Row Highlight -->
      <div class="config-section">
        <div class="section-header">
          <div class="section-icon" style="background:rgba(34,211,168,.12)">✨</div>
          <div class="section-title">Row Highlight</div>
        </div>
        <div class="toggle-row">
          <div>
            <div class="toggle-label">Highlight Selected Row</div>
            <div class="toggle-desc">Click any row in the preview to highlight it</div>
          </div>
          <label class="toggle-switch">
            <input type="checkbox" id="fynqol_listbg" name="fynqol_listbg" value="1" onchange="applyPreviewColors()">
            <span class="toggle-slider"></span>
          </label>
        </div>
        <div class="color-row">
          <div class="color-row-label">Highlight Color</div>
          <div class="color-field" id="cf_listbg"></div>
        </div>
      </div>

      <!-- 3. Navbar -->
      <div class="config-section">
        <div class="section-header">
          <div class="section-icon" style="background:rgba(124,92,255,.12)">🔝</div>
          <div class="section-title">Navigation Bar</div>
        </div>
        <div class="color-row">
          <div class="color-row-label">Colors</div>
          <div class="color-field">
            <span class="color-field-label">BG</span>
            <div id="cf_navbar_bg"></div>
          </div>
          <div class="color-field">
            <span class="color-field-label">Text</span>
            <div id="cf_navbar_text"></div>
          </div>
        </div>
      </div>

      <!-- 4. Pagination -->
      <div class="config-section">
        <div class="section-header">
          <div class="section-icon" style="background:rgba(251,146,60,.12)">📄</div>
          <div class="section-title">Pagination Bar</div>
        </div>
        <div class="color-row">
          <div class="color-row-label">Colors</div>
          <div class="color-field">
            <span class="color-field-label">BG</span>
            <div id="cf_pag_bg"></div>
          </div>
          <div class="color-field">
            <span class="color-field-label">Text</span>
            <div id="cf_pag_text"></div>
          </div>
        </div>
      </div>

      <!-- 5. List Header -->
      <div class="config-section">
        <div class="section-header">
          <div class="section-icon" style="background:rgba(34,211,168,.12)">📋</div>
          <div class="section-title">List View Header</div>
        </div>
        <div class="color-row">
          <div class="color-row-label">Colors</div>
          <div class="color-field">
            <span class="color-field-label">BG</span>
            <div id="cf_header_bg"></div>
          </div>
          <div class="color-field">
            <span class="color-field-label">Text</span>
            <div id="cf_header_text"></div>
          </div>
        </div>
      </div>

      <!-- 6. Homepage Background -->
        <div class="config-section">
          <div class="section-header">
            <div class="section-icon" style="background:rgba(251,146,60,.12)">🏠</div>
            <div class="section-title">Homepage Background</div>
          </div>
          <div class="color-row">
            <div class="color-row-label">Colors</div>
            <div class="color-field">
                <span class="color-field-label">BG</span>
                <div id="cf_homepage_bg"></div>
            </div>
            <div class="color-field">
                <span class="color-field-label">Text</span>
                <div id="cf_homepage_text"></div>
            </div>
          </div>
        </div>

      <!-- 7. Dropdown -->
        <div class="config-section">
          <div class="section-header">
            <div class="section-icon" style="background:rgba(124,92,255,.12)">⬇️</div>
            <div class="section-title">Dropdown</div>
          </div>
          <div class="color-row">
            <div class="color-row-label">Colors</div>
            <div class="color-field">
              <span class="color-field-label">BG</span>
              <div id="cf_dropdown_bg"></div>
            </div>
            <div class="color-field">
              <span class="color-field-label">Text</span>
              <div id="cf_dropdown_text"></div>
            </div>
          </div>
        </div>
    </div>
  </div>

  <!-- ══ RIGHT PREVIEW PANEL ══ -->
  <div class="preview-panel">
    <div class="preview-label-bar">
      <div class="preview-dot"></div>
      <span class="preview-label-text">Live Preview — SuiteCRM8 Leads List</span>
    </div>
    <div class="scrm-wrap">
      <div class="preview-navbar" id="preview-navbar">
        <div class="nav-logo">CRM</div>
        <div class="nav-item active">Leads</div>
        <div class="nav-item">Accounts</div>
        <div class="nav-item">Contacts</div>
        <div class="nav-item">Opportunities</div>
        <div class="nav-item">Cases</div>
        <div class="nav-spacer"></div>
        <div class="nav-icon">🔔</div>
        <div class="nav-icon" style="margin-left:6px">👤</div>
      </div>
      <div class="scrm-content">
        <div class="page-title">Leads</div>
        <div class="preview-pagination" id="preview-pagination">
          <div class="pag-left">
            <div class="bulk-btn">☑ Bulk Action ▾</div>
            <div class="bulk-btn">⊞ Columns</div>
          </div>
          <div style="display:flex;align-items:center;gap:6px">
            <button type="button" class="pag-btn">⟪</button>
            <button type="button" class="pag-btn">‹</button>
            <span class="pag-count" id="pag-count-text">(1 - 20 of 186)</span>
            <button type="button" class="pag-btn">›</button>
            <button type="button" class="pag-btn">⟫</button>
          </div>
        </div>
        <div class="list-table-wrap">
          <table class="list-table">
            <thead>
              <tr class="preview-header" id="preview-header">
                <th class="cb-cell"><span class="checkbox-fake"></span></th>
                <th>Name <span class="sort-icon">⇅</span></th>
                <th>State <span class="sort-icon">⇅</span></th>
                <th>Status <span class="sort-icon">⇅</span></th>
                <th>Account Name <span class="sort-icon">⇅</span></th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="preview-tbody"></tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

</div>
</form>
<script>
// PHP → JS: saved config for pre-filling pickers
const SERVER_CONFIG = <?php echo json_encode($js_saved_config); ?>;
</script>
<script>
'use strict';

/* ══════════════════════════════════════════════════════
   THEME DEFINITIONS
══════════════════════════════════════════════════════ */
const THEMES = [
  {
    id: 'dark',
    name: 'Dark Theme',
    colors: {
      navbar: { bg: '#131f2b', text: '#e5e5ff' },
      pagination: { bg: '#1f2c3a', text: '#e5e5ff' },
      header: { bg: '#22323f', text: '#e5e5ff' },
      homepage_bg: { bg: '#000000', text: '#e5e5ff' },
      dropdown: { bg: '#121b24', text: '#e5e5ff' }
    }
  },
  {
    id: 'light',
    name: 'Light Theme',
    colors: {
      navbar: { bg: '#2e3647', text: '#fdffff' },
      pagination: { bg: '#f6f7f9', text: '#2a354d' },
      header: { bg: '#eaedf2', text: '#474f59' },
      homepage_bg: { bg: '#f6f7f9', text: '#172a42' },
      dropdown: { bg: '#ffffff', text: '#4a4e54' }
    }
  },
  // Add more themes here as needed:
  // {
  //   id: 'light',
  //   name: 'Light Theme',
  //   colors: {
  //     navbar: { bg: '#ffffff', text: '#000000' },
  //     pagination: { bg: '#f8f9fa', text: '#212529' },
  //     header: { bg: '#e9ecef', text: '#212529' },
  //     homepage_bg: { bg: '#ffffff' },
  //     dropdown: { bg: '#ffffff', text: '#000000' }
  //   }
  // }
];

/* ══════════════════════════════════════════════════════
   GENERATE THEME CARDS
══════════════════════════════════════════════════════ */
function generateThemeCards() {
  const container = document.getElementById('theme-cards-container');
  
  THEMES.forEach(theme => {
    const card = document.createElement('div');
    card.className = 'theme-card';
    card.dataset.themeId = theme.id;
    
    card.innerHTML = `
      <div class="theme-card-radio"></div>
      <div class="theme-title">${theme.name}</div>
      <div class="theme-preview">
        <div class="theme-preview-inner">
          <div class="scrm-wrap">
            <div class="preview-navbar" style="background:${theme.colors.navbar.bg};color:${theme.colors.navbar.text}">
              <div class="nav-logo">CRM</div>
              <div class="nav-item active">Leads</div>
              <div class="nav-item">Accounts</div>
              <div class="nav-item">Contacts</div>
              <div class="nav-spacer"></div>
              <div class="nav-icon">🔔</div>
            </div>
            <div class="scrm-content" style="background:${theme.colors.homepage_bg.bg};color:${theme.colors.homepage_bg.text}">
              <div class="page-title" style="color:${theme.colors.homepage_bg.bg === '#000000' ? '#fff' : '#333'}">Leads</div>
              <div class="preview-pagination" style="background:${theme.colors.pagination.bg};color:${theme.colors.pagination.text}">
                <div class="pag-left">
                  <div class="bulk-btn" style="background:rgba(255,255,255,.3)">Bulk</div>
                </div>
                <span class="pag-count">(1 - 20)</span>
              </div>
              <div class="list-table-wrap" style="background:${theme.colors.homepage_bg.bg === '#000000' ? '#1a1a1a' : '#fff'}">
                <table class="list-table">
                  <thead>
                    <tr class="preview-header" style="background:${theme.colors.header.bg};color:${theme.colors.header.text}">
                      <th>Name</th>
                      <th>State</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr style="color:${theme.colors.homepage_bg.bg === '#000000' ? '#d6d6d6' : '#374151'}">
                      <td>John Doe</td>
                      <td><span class="state-badge" style="background:#0d6efd;color:#fff">Open</span></td>
                      <td><span class="status-badge" style="background:#0d6efd;color:#fff">New</span></td>
                    </tr>
                    <tr style="color:${theme.colors.homepage_bg.bg === '#000000' ? '#d6d6d6' : '#374151'}">
                      <td>Jane Smith</td>
                      <td><span class="state-badge" style="background:#198754;color:#fff">Closed</span></td>
                      <td><span class="status-badge" style="background:#0dcaf0;color:#000">Assigned</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    card.addEventListener('click', () => applyTheme(theme));
    container.appendChild(card);
  });
}

/* ══════════════════════════════════════════════════════
   APPLY THEME
══════════════════════════════════════════════════════ */
function applyTheme(theme) {
  // Update all theme card selections
  document.querySelectorAll('.theme-card').forEach(card => {
    card.classList.remove('selected');
  });
  document.querySelector(`[data-theme-id="${theme.id}"]`).classList.add('selected');
  
  // Apply theme colors to pickers
  simplePickers['cf_navbar_bg'].setValue(theme.colors.navbar.bg);
  simplePickers['cf_navbar_text'].setValue(theme.colors.navbar.text);
  simplePickers['cf_pag_bg'].setValue(theme.colors.pagination.bg);
  simplePickers['cf_pag_text'].setValue(theme.colors.pagination.text);
  simplePickers['cf_header_bg'].setValue(theme.colors.header.bg);
  simplePickers['cf_header_text'].setValue(theme.colors.header.text);
  simplePickers['cf_homepage_bg'].setValue(theme.colors.homepage_bg.bg);
  simplePickers['cf_homepage_text'].setValue(theme.colors.homepage_bg.text);
  simplePickers['cf_dropdown_bg'].setValue(theme.colors.dropdown.bg);
  simplePickers['cf_dropdown_text'].setValue(theme.colors.dropdown.text);
  
  // Apply to live preview
  applyPreviewColors();
}

/* ══════════════════════════════════════════════════════
   createColorPicker
══════════════════════════════════════════════════════ */
function createColorPicker(initialHex, onChangeFn) {
  function normalize(h) {
    if (!h) return '#000000';
    h = h.trim();
    if (!h.startsWith('#')) h = '#' + h;
    return h.toLowerCase();
  }
  let currentHex = normalize(initialHex);

  const wrap        = document.createElement('div');
  wrap.className    = 'cp-wrap';
  const triggerWrap = document.createElement('div');
  triggerWrap.className = 'cp-trigger-wrap';
  const swatch      = document.createElement('div');
  swatch.className  = 'cp-swatch';
  swatch.style.backgroundColor = currentHex;
  const nativeInput = document.createElement('input');
  nativeInput.type  = 'color';
  nativeInput.className = 'cp-input-hidden';
  nativeInput.value = currentHex;
  triggerWrap.appendChild(swatch);
  triggerWrap.appendChild(nativeInput);

  const hexField    = document.createElement('input');
  hexField.type     = 'text';
  hexField.className = 'cp-hex';
  hexField.value    = currentHex;
  hexField.maxLength = 7;
  hexField.placeholder = '#rrggbb';
  wrap.appendChild(triggerWrap);
  wrap.appendChild(hexField);

  function commit(hex) {
    hex = normalize(hex);
    if (!/^#[0-9a-f]{6}$/.test(hex)) return;
    currentHex = hex;
    swatch.style.backgroundColor = hex;
    nativeInput.value = hex;
    hexField.value    = hex;
    onChangeFn(hex);
  }

  nativeInput.addEventListener('input',  () => commit(nativeInput.value));
  nativeInput.addEventListener('change', () => commit(nativeInput.value));
  hexField.addEventListener('input', () => {
    let v = hexField.value.trim();
    if (!v.startsWith('#')) v = '#' + v;
    if (/^#[0-9a-fA-F]{6}$/.test(v)) {
      currentHex = v.toLowerCase();
      swatch.style.backgroundColor = currentHex;
      nativeInput.value = currentHex;
      onChangeFn(currentHex);
    }
  });
  hexField.addEventListener('blur', () => { hexField.value = currentHex; });

  wrap.getValue = () => currentHex;
  wrap.setValue = (hex) => commit(hex);
  return wrap;
}

/* ══════════════════════════════════════════
   DEFAULTS
══════════════════════════════════════════ */
const stateDefaults = [
  { label: 'Open',   bg: '#0d6efd', text: '#ffffff' },
  { label: 'Closed', bg: '#198754', text: '#ffffff' },
];
const statusDefaults = [
  { label: 'New',            bg: '#0d6efd', text: '#ffffff' },
  { label: 'Assigned',       bg: '#0dcaf0', text: '#000000' },
  { label: 'Pending Input',  bg: '#fd7e14', text: '#ffffff' },
  { label: 'Closed',         bg: '#198754', text: '#ffffff' },
  { label: 'Rejected',       bg: '#dc3545', text: '#ffffff' },
  { label: 'Duplicate',      bg: '#6f42c1', text: '#ffffff' },
  { label: 'Not Started',    bg: '#0d6efd', text: '#ffffff' },
  { label: 'In Progress',    bg: '#fd7e14', text: '#ffffff' },
  { label: 'Completed',      bg: '#28a745', text: '#ffffff' },
  { label: 'Closed Pending', bg: '#198754', text: '#ffffff' },
  { label: 'Deferred',       bg: '#6c757d', text: '#ffffff' },
  { label: 'In Process',     bg: '#fd7e14', text: '#ffffff' },
  { label: 'Recycled',       bg: '#0d6efd', text: '#ffffff' },
];

const sampleRows = [
  { name: 'Shahnawz Nawz',     state: 'Open', status: 'New'           },
  { name: 'Mr. Sawood',        state: 'Open', status: 'Assigned'      },
  { name: 'Mr. Shah Nawaz',    state: 'Open', status: 'New'           },
  { name: 'Abdullah Visitors', state: 'Open', status: 'In Progress'   },
  { name: 'Abdullah Visitor',  state: 'Open', status: 'Pending Input' },
  { name: 'Rahul Mehta',       state: 'Closed', status: 'Closed'      },
  { name: 'Abdulla Sawood',    state: 'Open', status: 'New'           },
  { name: 'Shilpa Bose',       state: 'Open', status: 'Recycled',     account: 'People First'   },
  { name: 'Rahul Jain',        state: 'Open', status: 'In Process',   account: 'EduServe India' },
  { name: 'Sawood',            state: 'Closed', status: 'Rejected'    },
  { name: 'Priya Sharma',      state: 'Closed', status: 'Completed',  account: 'TechCorp' },
  { name: 'Ankit Verma',       state: 'Open', status: 'Not Started',  account: 'Globex'   },
];

/* ══════════════════════════════════════════
   MERGE SAVED CONFIG OVER DEFAULTS
══════════════════════════════════════════ */
function mergeWithDefaults(defaults, saved) {
  if (!saved || !saved.length) return JSON.parse(JSON.stringify(defaults));
  return defaults.map(def => {
    const match = saved.find(s => s.label === def.label);
    return match ? { label: def.label, bg: match.bg, text: match.text } : { ...def };
  });
}

let colorData = {
  state:  mergeWithDefaults(stateDefaults,  SERVER_CONFIG.colors.state),
  status: mergeWithDefaults(statusDefaults, SERVER_CONFIG.colors.status),
};

const simplePickers = {};
let selectedRow = null;

/* ══════════════════════════════════════════
   BUILD COLOR TABLE ROWS
══════════════════════════════════════════ */
function buildColorRows(type, data, tbodyId) {
  const tbody = document.getElementById(tbodyId);
  tbody.innerHTML = '';
  data.forEach((item, i) => {
    const badge = document.createElement('span');
    badge.className = 'badge-preview';
    badge.textContent = item.label;
    badge.style.background = item.bg;
    badge.style.color = item.text;

    const bgPicker = createColorPicker(item.bg, (hex) => {
      colorData[type][i].bg = hex;
      badge.style.background = hex;
      updatePreviewBadges();
      applyPreviewColors();
    });
    const textPicker = createColorPicker(item.text, (hex) => {
      colorData[type][i].text = hex;
      badge.style.color = hex;
      updatePreviewBadges();
      applyPreviewColors();
    });

    const tr = document.createElement('tr');
    const tdLabel = document.createElement('td');
    const lbl = document.createElement('span');
    lbl.className = 'value-label';
    lbl.textContent = item.label;
    tdLabel.appendChild(lbl);
    const tdBg   = document.createElement('td'); tdBg.appendChild(bgPicker);
    const tdText = document.createElement('td'); tdText.appendChild(textPicker);
    const tdBadge = document.createElement('td'); tdBadge.appendChild(badge);
    tr.append(tdLabel, tdBg, tdText, tdBadge);
    tbody.appendChild(tr);
  });
}

/* ══════════════════════════════════════════
   BUILD SIMPLE PICKERS
══════════════════════════════════════════ */
function buildSimplePickers() {
  const sc = SERVER_CONFIG.colors;
  [
    { id: 'cf_navbar_bg',   init: sc.navbar.bg },
    { id: 'cf_navbar_text', init: sc.navbar.text },
    { id: 'cf_pag_bg',      init: sc.pagination.bg },
    { id: 'cf_pag_text',    init: sc.pagination.text },
    { id: 'cf_header_bg',   init: sc.header.bg },
    { id: 'cf_header_text', init: sc.header.text },
    { id: 'cf_listbg',      init: SERVER_CONFIG.listbg_color },
    { id: 'cf_homepage_bg', init: SERVER_CONFIG.homepage_bg.bg },
    { id: 'cf_homepage_text', init: SERVER_CONFIG.homepage_bg.text },
    { id: 'cf_dropdown_bg', init: SERVER_CONFIG.dropdown.bg },
    { id: 'cf_dropdown_text', init: SERVER_CONFIG.dropdown.text },
  ].forEach(({ id, init }) => {
    const container = document.getElementById(id);
    const picker = createColorPicker(init, () => applyPreviewColors());
    container.appendChild(picker);
    simplePickers[id] = picker;
  });
}

/* ══════════════════════════════════════════
   BUILD PREVIEW ROWS
══════════════════════════════════════════ */
function buildPreviewRows() {
  const tbody = document.getElementById('preview-tbody');
  tbody.innerHTML = '';
  sampleRows.forEach((row) => {
    const tr = document.createElement('tr');
    tr.innerHTML =
      '<td class="cb-cell"><span class="checkbox-fake"></span></td>' +
      '<td><a class="record-link" href="#">' + row.name + '</a></td>' +
      '<td><span class="state-badge" data-state="' + row.state + '">' + row.state + '</span></td>' +
      '<td><span class="status-badge" data-status="' + row.status + '">' + row.status + '</span></td>' +
      '<td>' + (row.account || '<span style="color:#adb5bd">—</span>') + '</td>' +
      '<td><div class="row-actions">' +
        '<button type="button" class="row-action-btn">📞</button>' +
        '<button type="button" class="row-action-btn">📅</button>' +
        '<button type="button" class="row-action-btn">✉️</button>' +
      '</div></td>';
    tr.addEventListener('click', () => selectRow(tr));
    tbody.appendChild(tr);
  });
}

/* ══════════════════════════════════════════
   APPLY PREVIEW COLORS
══════════════════════════════════════════ */
function applyPreviewColors() {
  const g = (id) => simplePickers[id].getValue();
  document.getElementById('preview-navbar').style.backgroundColor = g('cf_navbar_bg');
  document.getElementById('preview-navbar').style.color            = g('cf_navbar_text');
  document.getElementById('preview-pagination').style.backgroundColor = g('cf_pag_bg');
  document.getElementById('preview-pagination').style.color            = g('cf_pag_text');
  document.getElementById('pag-count-text').style.color               = g('cf_pag_text');
  document.querySelector(".preview-panel .scrm-content").style.backgroundColor = g('cf_homepage_bg');
  document.querySelector(".preview-panel .page-title").style.color = g('cf_homepage_text');
  document.querySelectorAll('#preview-header th').forEach(th => {
    th.style.backgroundColor = g('cf_header_bg');
    th.style.color            = g('cf_header_text');
  });
  if (selectedRow) {
    selectedRow.style.backgroundColor =
      document.getElementById('fynqol_listbg').checked ? g('cf_listbg') : '';
  }
  updatePreviewBadges();
}

function updatePreviewBadges() {
  const enabled = document.getElementById('fynqol_enabled').checked;
  
  // Update status badges
  document.querySelectorAll('.status-badge[data-status]').forEach(badge => {
    if (!enabled) { badge.removeAttribute('style'); return; }
    const match = colorData.status.find(
      x => x.label.toLowerCase() === badge.dataset.status.toLowerCase()
    );
    badge.style.background   = match ? match.bg   : '#6c757d';
    badge.style.color        = match ? match.text : '#ffffff';
    badge.style.padding      = '3px 10px';
    badge.style.borderRadius = '10px';
  });

  // Update state badges
  document.querySelectorAll('.state-badge[data-state]').forEach(badge => {
    if (!enabled) { badge.removeAttribute('style'); return; }
    const match = colorData.state.find(
      x => x.label.toLowerCase() === badge.dataset.state.toLowerCase()
    );
    badge.style.background   = match ? match.bg   : '#6c757d';
    badge.style.color        = match ? match.text : '#ffffff';
    badge.style.padding      = '3px 10px';
    badge.style.borderRadius = '10px';
  });
}

function toggleColorSection() {
  document.getElementById('color-section').style.display =
    document.getElementById('fynqol_enabled').checked ? '' : 'none';
  updatePreviewBadges();
}

function selectRow(tr) {
  if (!document.getElementById('fynqol_listbg').checked) return;
  const color = simplePickers['cf_listbg'].getValue();
  if (selectedRow && selectedRow !== tr) {
    selectedRow.style.backgroundColor = '';
    selectedRow.classList.remove('selected-row');
  }
  if (selectedRow === tr) {
    tr.style.backgroundColor = '';
    tr.classList.remove('selected-row');
    selectedRow = null;
  } else {
    tr.style.backgroundColor = color;
    tr.classList.add('selected-row');
    selectedRow = tr;
  }
}

/* ══════════════════════════════════════════
   FORM SUBMIT — populate hidden fields
══════════════════════════════════════════ */
document.getElementById('fynqol-form').addEventListener('submit', function(e) {
  // Don't intercept the Reset button
  if (document.activeElement && document.activeElement.name === 'fynqol_reset') return;
  // Build the full colours payload including navbar/pagination/header
  const payload = {
    state:  colorData.state,
    status: colorData.status,
    navbar: {
      bg:   simplePickers['cf_navbar_bg'].getValue(),
      text: simplePickers['cf_navbar_text'].getValue(),
    },
    pagination: {
      bg:   simplePickers['cf_pag_bg'].getValue(),
      text: simplePickers['cf_pag_text'].getValue(),
    },
    header: {
      bg:   simplePickers['cf_header_bg'].getValue(),
      text: simplePickers['cf_header_text'].getValue(),
    },
    homepage_bg: {
      bg:   simplePickers['cf_homepage_bg'].getValue(),
      text:   simplePickers['cf_homepage_text'].getValue(),
    },
    dropdown: {
      bg:   simplePickers['cf_dropdown_bg'].getValue(),
      text: simplePickers['cf_dropdown_text'].getValue(),
    },
  };

  document.getElementById('h_fynqol_colours').value     = JSON.stringify(payload);
  document.getElementById('h_fynqol_listbg_color').value = simplePickers['cf_listbg'].getValue();
});

/* ══════════════════════════════════════════
   INIT — pre-fill from SERVER_CONFIG
══════════════════════════════════════════ */
document.getElementById('fynqol_enabled').checked = SERVER_CONFIG.enabled;
document.getElementById('fynqol_listbg').checked  = SERVER_CONFIG.listbg;
generateThemeCards();
buildSimplePickers();
buildColorRows('state',  colorData.state,  'state-tbody');
buildColorRows('status', colorData.status, 'status-tbody');
buildPreviewRows();
toggleColorSection();
applyPreviewColors();
</script>
</body>
</html>