<?php
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
require_once('modules/Configurator/Configurator.php');

global $sugar_config, $db, $moduleList, $app_list_strings;
$validate_license = TRUE;
$removeModules = ['Home','Maps','jjwg_Maps','jjwg_Markers'];
$moduleList = array_diff($moduleList, $removeModules);
$fixedPrompt = "You are a senior SuiteCRM Database Architect and MySQL expert.

    Your responsibility:
    - Generate logically correct and performance-aware MySQL queries.
    - Use ONLY the provided database schema.
    - Never assume fields or relationships that are not present in schema.
    - Never hallucinate tables or columns.

    Before answering you must critically evaluate:
    1. Does the query EXACTLY answer the user's question?
    2. Is any business meaning misinterpreted?
    3. Does the query use shortcuts that change semantics?
    4. Does the query assume business logic incorrectly?
    5. Would this query return results that contradict the question intent?

    CRM Semantic Rules:
    - \"Contacted\" means at least one related activity exists (Calls, Meetings, Emails, Completed Tasks).
    - Do NOT infer contact status from phone/email fields alone.
    - Activity may exist via relationship tables or parent_type/parent_id linking.
    - Always consider both relationship tables and direct parent references when checking related records.

    Query Rules:
    - For aggregation queries, do not use LIMIT and prefer GROUP BY for categorized result set by parameters mentioned in the question.
    - For row retrieval queries, always USE LIMIT 20.
    - Prefer ordering by date_modified DESC or date_entered DESC when relevant.

    Output Rules:
    - Return ONLY valid JSON.
    - Do NOT include explanations.
    - JSON must follow this format:

    {
      \"action\": \"sql\",
      \"query\": \"<valid_mysql_query>\"
    }";

$apiKey     = isset($sugar_config['fyn_rahbar_api_key']) ? $sugar_config['fyn_rahbar_api_key'] : '';
$prompt     = isset($sugar_config['fyn_rahbar_prompt']) ? $sugar_config['fyn_rahbar_prompt'] : '';
$allowedModules = isset($sugar_config['fyn_rahbar_modules']) ? unserialize($sugar_config['fyn_rahbar_modules']) : [];
?>
<style>
    .checklist {
        border: 1px solid #ccc;
        border-radius: 6px;
        padding: 15px;
        background: #fff;
        margin-bottom: 20px;
    }
    .check-item {
        display: flex;
        align-items: center;
        margin-bottom: 8px;
    }
    .check-item span {
        margin-left: 8px;
    }
    .ok { color: #2ecc71; font-weight: bold; }
    .fail { color: #e74c3c; font-weight: bold; }
    .note { color: #f39c12; font-weight: bold; }

    /* container tweaks: keep columns top-aligned to avoid vertical shifts */
    .container-wrapper {
        display: flex;
        gap: 20px;
        margin-top: 20px;
        align-items: flex-start; /* <-- important */
    }
    .container {
        flex: 1;
        border: 1px solid #ccc;
        border-radius: 6px;
        padding: 10px;
        min-height: 250px;
        background: #f9f9f9;
        box-sizing: border-box;
    }
    .container h3 {
        text-align: center;
        font-size: 16px;
        margin-bottom: 10px;
    }
    /* ensure each item keeps full width and consistent box sizing */
    .table-item {
        padding: 6px 10px;
        margin: 4px 0;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 4px;
        cursor: grab;
        display: block;
        width: 100%;             /* keep consistent width for clones */
        box-sizing: border-box;  /* avoid size jumps */
        -webkit-user-select: none;
        user-select: none;
    }
    .table-item:active { cursor: grabbing; }
    .disabled .table-item {
        background: #eee;
        color: #888;
        cursor: not-allowed;
    }
    .sortable-ghost {
        opacity: 0.85 !important;
        pointer-events: none;
        box-shadow: 0 6px 18px rgba(0,0,0,0.12);
        z-index: 9999;
    }
    .sortable-chosen {
        opacity: 0.6;
    }
    .table-container {
      min-height: 200px;
      max-height: 400px;
      overflow-y: auto;
      border: 1px solid #ccc;
      border-radius: 6px;
      padding: 10px;
      background: #fafafa;
    }
    .table-container .sortable-item {
      padding: 6px 10px;
      margin: 4px 0;
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 4px;
      cursor: grab;
    }
    .table-container .sortable-item.sortable-chosen {
      background: #e6f7ff;
      border-color: #91d5ff;
      cursor: grabbing;
    }
    .table-container .sortable-item.sortable-ghost {
      opacity: 0.5;
    }
    .fix-link {
        margin-left: 10px;
        font-size: 12px;
    }
    .fix-link a {
        color: #2980b9;
        text-decoration: none;
        font-weight: bold;
    }
    .fix-link a:hover {
        text-decoration: underline;
    }
    td{
        padding:10px;
    }
    input[type='text']{
        width:80%;
    }
</style>
<div class="checklist">
    <h3>Setup Checklist</h3>
    <table width="100%" cellpadding="8" cellspacing="0" style="border-collapse:collapse;">
        <thead>
            <tr style="background:#f1f1f1;">
                <th align="left" style="border:1px solid #ccc;">Sl No</th>
                <th align="left" style="border:1px solid #ccc;">Status</th>
                <th align="left" style="border:1px solid #ccc;">Name</th>
                <th align="left" style="border:1px solid #ccc;">Action</th>
            </tr>
        </thead>
        <tbody>

            <!-- 1. License -->
            <tr>
                <td style="border:1px solid #ccc;">1</td>
                <td style="border:1px solid #ccc;">
                    <?= $validate_license ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>' ?>
                </td>
                <td style="border:1px solid #ccc;">License Validated</td>
                <td style="border:1px solid #ccc;">
                    <?php if (!$validate_license): ?>
                        <a href="index.php?module=RahbarInsights&action=license">Fix it</a>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </td>
            </tr>

            <!-- 2. API Key -->
            <tr>
                <td style="border:1px solid #ccc;">2</td>
                <td style="border:1px solid #ccc;">
                    <?= $apiKey ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>' ?>
                </td>
                <td style="border:1px solid #ccc;">
                    OpenAi API key
                </td>
                <td style="border:1px solid #ccc;">
                    <form method="POST" action="">
                        <!-- <label>API Key:</label><br/> -->
                        <input type="text" id="display_api_key" name="display_api_key" value="<?php echo htmlspecialchars($apiKey); ?>" size="50"/>
                    </form>
                </td>
            </tr>

            <!-- 3. Select Module -->
            <tr>
                <td style="border:1px solid #ccc;">3</td>
                <td style="border:1px solid #ccc;">
                    <?= $allowedModules ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>' ?>
                </td>
                <td style="border:1px solid #ccc;">
                    Select Modules that you use from down below
                </td>
                <td style="border:1px solid #ccc;">
                        —
                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php
// Handle Save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $apiKey = $_POST['api_key'];
    $prompt = $_POST['prompt'];
    $allowedModules = isset($_POST['modules']) ? $_POST['modules'] : [];
    $overrideFile = 'config_override.php';
    // require_once 'modules/Administration/QuickRepairAndRebuild.php';
    // require_once 'include/utils.php';

    // Update config values
    $cfg = new Configurator();
    $cfg->config['fyn_rahbar_api_key'] = $apiKey;
    $cfg->config['fyn_rahbar_prompt'] = $prompt;
    $cfg->config['fyn_rahbar_modules'] = serialize($allowedModules);
    $cfg->handleOverride();
    header("Location: " . $_SERVER['REQUEST_URI']);
    echo '<div style="color: green; font-weight: bold;">Settings saved successfully!</div>';
}
echo '<html><style>textarea{width:100%;height:200px;}</style><body style="margin: 20px;">';
echo '<h2>FynRahbar Insights Configuration</h2>';
echo '<form method="POST" action="">';

echo '<input type="hidden" id="api_key" name="api_key" value="'. htmlspecialchars($apiKey) .'">';

// Prompt
echo '<label>System Prompt:</label><br/>';
echo '<textarea readonly="true" disabled="true">' . htmlspecialchars($fixedPrompt) . '</textarea><br/><br/>';
echo '<label>Your Prompt:</label><br/>';
echo '<textarea id="prompt" name="prompt">' . htmlspecialchars($prompt) . '</textarea><br/><br/>';

// Table list with checkboxes
echo '<label>Select Tables to include in db_structure_str:</label><br/>';
echo '<input type="checkbox" id="select_all" /> <label for="select_all"><strong>Select/Unselect All</strong></label><br><br>';
echo '<div class="module-grid">';
foreach ($moduleList as $module) {
	$moduleLabel = translate($module, $module);
    $checked = in_array($module, $allowedModules ?? []) ? 'checked' : '';
    $safeModule = htmlspecialchars($module);
    echo '<div class="module-item">';
    echo '<input class="table-checkbox" type="checkbox" name="modules[]" id="' . $safeModule . '" value="' . $safeModule . '" ' . $checked . '> ';
    echo '<label for="' . $safeModule . '">' . $moduleLabel . '</label><br/>';
    echo '</div>';
}
echo '</div>';


echo '<br/><input type="submit" value="Save Settings" />';
echo '</form></body>';
echo <<<EOD
    <script>
    document.getElementById('select_all').addEventListener('change', function(e) {
        console.log("event triggered")
        var checkboxes = document.querySelectorAll('.table-checkbox');
        for (var i = 0; i < checkboxes.length; i++) {
            checkboxes[i].checked = e.target.checked;
        }
    });
    const displayApiKey = document.querySelector("#display_api_key");
    const apiKey = document.querySelector("#api_key");
    displayApiKey.addEventListener("input", function () {
      apiKey.value = displayApiKey.value;
    });
    </script>
EOD;
echo '
<style>
.module-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 6px 20px;
}
.module-item {
    white-space: nowrap;
}
</style>
';
echo '</html>';