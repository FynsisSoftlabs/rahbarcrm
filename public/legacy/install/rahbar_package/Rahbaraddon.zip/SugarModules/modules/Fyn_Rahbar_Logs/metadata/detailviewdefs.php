<?php
$module_name = 'Fyn_Rahbar_Logs';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_DETAILVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'response',
            'label' => 'LBL_RESPONSE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'input_tokens',
            'label' => 'LBL_INPUT_TOKENS',
          ),
          1 => 
          array (
            'name' => 'output_tokens',
            'label' => 'LBL_OUTPUT_TOKENS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'time_taken',
            'label' => 'LBL_TIME_TAKEN',
          ),
          1 => 
          array (
            'name' => 'approx_charge',
            'label' => 'LBL_APPROX_CHARGE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'generated_query',
            'studio' => 'visible',
            'label' => 'LBL_GENERATED_QUERY',
          ),
          1 => 
          array (
            'name' => 'is_correct',
            'label' => 'LBL_IS_CORRECT',
          ),
        ),
      ),
      'lbl_detailview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'created_by_name',
            'label' => 'LBL_CREATED',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'date_modified',
            'comment' => 'Date record last modified',
            'label' => 'LBL_DATE_MODIFIED',
          ),
          1 => 
          array (
            'name' => 'modified_by_name',
            'label' => 'LBL_MODIFIED_NAME',
          ),
        ),
      ),
    ),
  ),
);
