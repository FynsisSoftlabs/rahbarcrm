<?php
$module_name = 'Fyn_Rahbar_Logs';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'RESPONSE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_RESPONSE',
    'width' => '10%',
    'default' => true,
  ),
  'APPROX_CHARGE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_APPROX_CHARGE',
    'width' => '10%',
    'default' => true,
  ),
  'GENERATED_QUERY' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_GENERATED_QUERY',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'IS_CORRECT' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_IS_CORRECT',
    'width' => '10%',
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
  'PAYLOAD_INPUT' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PAYLOAD_INPUT',
    'width' => '10%',
    'default' => false,
  ),
  'INPUT_TOKENS' => 
  array (
    'type' => 'int',
    'label' => 'LBL_INPUT_TOKENS',
    'width' => '10%',
    'default' => false,
  ),
  'OUTPUT_TOKENS' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_OUTPUT_TOKENS',
    'width' => '10%',
    'default' => false,
  ),
  'TIME_TAKEN' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_TIME_TAKEN',
    'width' => '10%',
    'default' => false,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
