<?php
$module_name = 'Fyn_Rahbar_Logs';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'response',
            'label' => 'LBL_RESPONSE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'input_tokens',
            'label' => 'LBL_INPUT_TOKENS',
          ),
          1 => 
          array (
            'name' => 'output_tokens',
            'label' => 'LBL_OUTPUT_TOKENS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'approx_charge',
            'label' => 'LBL_APPROX_CHARGE',
          ),
          1 => 
          array (
            'name' => 'time_taken',
            'label' => 'LBL_TIME_TAKEN',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'generated_query',
            'studio' => 'visible',
            'label' => 'LBL_GENERATED_QUERY',
          ),
          1 => 
          array (
            'name' => 'is_correct',
            'label' => 'LBL_IS_CORRECT',
          ),
        ),
      ),
    ),
  ),
);
