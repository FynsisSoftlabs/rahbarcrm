<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2018 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */
$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_SECURITYGROUPS' => 'Security Groups',
  'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => 'Security Groups',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_LIST_NAME' => 'Name',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_REMOVE' => 'Remove',
  'LBL_ASCENDING' => 'Ascending',
  'LBL_DESCENDING' => 'Descending',
  'LBL_OPT_IN' => 'Opt In',
  'LBL_OPT_IN_PENDING_EMAIL_NOT_SENT' => 'Pending Confirm opt in, Confirm opt in not sent',
  'LBL_OPT_IN_PENDING_EMAIL_SENT' => 'Pending Confirm opt in, Confirm opt in sent',
  'LBL_OPT_IN_CONFIRMED' => 'Opted in',
  'LBL_LIST_FORM_TITLE' => 'Rahbar Logs List',
  'LBL_MODULE_NAME' => 'Rahbar Logs',
  'LBL_MODULE_TITLE' => 'Rahbar Logs',
  'LBL_HOMEPAGE_TITLE' => 'My Rahbar Logs',
  'LNK_NEW_RECORD' => 'Create Rahbar Logs',
  'LNK_LIST' => 'View Rahbar Logs',
  'LNK_IMPORT_FYN_REHBAR_LOGS' => 'Import Rahbar Logs',
  'LBL_SEARCH_FORM_TITLE' => 'Search Rahbar Logs',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_FYN_REHBAR_LOGS_SUBPANEL_TITLE' => 'Rahbar Logs',
  'LBL_NEW_FORM_TITLE' => 'New Rahbar Logs',
  'LBL_PAYLOAD_INPUT' => 'payload input',
  'LBL_RESPONSE' => 'Response',
  'LBL_INPUT_TOKENS' => 'input tokens',
  'LBL_OUTPUT_TOKENS' => 'output tokens',
  'LBL_APPROX_CHARGE' => 'approx charge',
  'LBL_REQUEST_BY_USER_ID' => 'request by (related User ID)',
  'LBL_REQUEST_BY' => 'request by',
  'LBL_TIME_TAKEN' => 'time taken',
  'LBL_EXTRA1' => 'extra1',
  'LBL_EXTRA2' => 'extra2',
  'LBL_EXTRA3' => 'extra3',
  'LBL_EXTRA4' => 'extra4',
  'LBL_EXTRA5' => 'extra5',
  'LBL_DETAILVIEW_PANEL1' => 'New Panel 1',
  'LBL_DETAILVIEW_PANEL2' => 'Audit',
  'LBL_GENERATED_QUERY' => 'Generated query',
  'LNK_IMPORT_FYN_RAHBAR_LOGS' => 'Import Rahbar Logs',
  'LBL_FYN_RAHBAR_LOGS_SUBPANEL_TITLE' => 'Rahbar Logs',
  'LBL_USERID' => 'User ID',
  'LBL_IS_CORRECT' => 'Correct?',
);