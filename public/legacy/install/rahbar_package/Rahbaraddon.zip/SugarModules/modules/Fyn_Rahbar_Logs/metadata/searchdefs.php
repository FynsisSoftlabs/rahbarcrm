<?php
$module_name = 'Fyn_Rahbar_Logs';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'response' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_RESPONSE',
        'width' => '10%',
        'default' => true,
        'name' => 'response',
      ),
      'input_tokens' => 
      array (
        'type' => 'int',
        'label' => 'LBL_INPUT_TOKENS',
        'width' => '10%',
        'default' => true,
        'name' => 'input_tokens',
      ),
      'output_tokens' => 
      array (
        'type' => 'decimal',
        'label' => 'LBL_OUTPUT_TOKENS',
        'width' => '10%',
        'default' => true,
        'name' => 'output_tokens',
      ),
      'approx_charge' => 
      array (
        'type' => 'decimal',
        'label' => 'LBL_APPROX_CHARGE',
        'width' => '10%',
        'default' => true,
        'name' => 'approx_charge',
      ),
      'time_taken' => 
      array (
        'type' => 'decimal',
        'label' => 'LBL_TIME_TAKEN',
        'width' => '10%',
        'default' => true,
        'name' => 'time_taken',
      ),
      'generated_query' => 
      array (
        'type' => 'text',
        'studio' => 'visible',
        'label' => 'LBL_GENERATED_QUERY',
        'sortable' => false,
        'width' => '10%',
        'default' => true,
        'name' => 'generated_query',
      ),
      'is_correct' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_IS_CORRECT',
        'width' => '10%',
        'name' => 'is_correct',
      ),
      'current_user_only' => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
        'default' => true,
        'width' => '10%',
      ),
    ),
    'advanced_search' => 
    array (
      0 => 'name',
      1 => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
