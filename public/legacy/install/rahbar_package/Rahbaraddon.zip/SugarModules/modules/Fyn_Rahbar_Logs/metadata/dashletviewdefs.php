<?php
$dashletData['Fyn_Rahbar_LogsDashlet']['searchFields'] = array (
  'name' => 
  array (
    'default' => '',
  ),
  'input_tokens' => 
  array (
    'default' => '',
  ),
  'output_tokens' => 
  array (
    'default' => '',
  ),
  'date_entered' => 
  array (
    'default' => '',
  ),
  'generated_query' => 
  array (
    'default' => '',
  ),
  'is_correct' => 
  array (
    'default' => '',
  ),
  'payload_input' => 
  array (
    'default' => '',
  ),
  'response' => 
  array (
    'default' => '',
  ),
  'approx_charge' => 
  array (
    'default' => '',
  ),
  'time_taken' => 
  array (
    'default' => '',
  ),
  'request_by' => 
  array (
    'default' => '',
  ),
  'date_modified' => 
  array (
    'default' => '',
  ),
);
$dashletData['Fyn_Rahbar_LogsDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'response' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_RESPONSE',
    'width' => '10%',
    'default' => true,
    'name' => 'response',
  ),
  'approx_charge' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_APPROX_CHARGE',
    'width' => '10%',
    'default' => true,
    'name' => 'approx_charge',
  ),
  'time_taken' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_TIME_TAKEN',
    'width' => '10%',
    'default' => true,
    'name' => 'time_taken',
  ),
  'generated_query' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_GENERATED_QUERY',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
    'name' => 'generated_query',
  ),
  'is_correct' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_IS_CORRECT',
    'width' => '10%',
    'name' => 'is_correct',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'output_tokens' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_OUTPUT_TOKENS',
    'width' => '10%',
    'default' => false,
  ),
  'input_tokens' => 
  array (
    'type' => 'int',
    'label' => 'LBL_INPUT_TOKENS',
    'width' => '10%',
    'default' => false,
  ),
  'created_by_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => false,
    'name' => 'created_by_name',
  ),
  'modified_by_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
    'name' => 'modified_by_name',
  ),
  'payload_input' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PAYLOAD_INPUT',
    'width' => '10%',
    'default' => false,
    'name' => 'payload_input',
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
    'name' => 'date_entered',
  ),
);
