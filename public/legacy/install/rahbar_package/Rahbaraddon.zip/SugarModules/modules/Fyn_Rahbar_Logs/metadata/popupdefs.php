<?php
$popupMeta = array (
    'moduleMain' => 'Fyn_Rehbar_Logs',
    'varName' => 'Fyn_Rehbar_Logs',
    'orderBy' => 'fyn_rehbar_logs.name',
    'whereClauses' => array (
  'name' => 'fyn_rehbar_logs.name',
  'payload_input' => 'fyn_rehbar_logs.payload_input',
  'response' => 'fyn_rehbar_logs.response',
  'approx_charge' => 'fyn_rehbar_logs.approx_charge',
  'request_by' => 'fyn_rehbar_logs.request_by',
  'assigned_user_id' => 'fyn_rehbar_logs.assigned_user_id',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'payload_input',
  5 => 'response',
  6 => 'approx_charge',
  7 => 'request_by',
  8 => 'assigned_user_id',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
  'payload_input' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PAYLOAD_INPUT',
    'width' => '10%',
    'name' => 'payload_input',
  ),
  'response' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_RESPONSE',
    'width' => '10%',
    'name' => 'response',
  ),
  'approx_charge' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_APPROX_CHARGE',
    'width' => '10%',
    'name' => 'approx_charge',
  ),
  'request_by' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_REQUEST_BY',
    'id' => 'USER_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'request_by',
  ),
  'assigned_user_id' => 
  array (
    'name' => 'assigned_user_id',
    'label' => 'LBL_ASSIGNED_TO',
    'type' => 'enum',
    'function' => 
    array (
      'name' => 'get_user_array',
      'params' => 
      array (
        0 => false,
      ),
    ),
    'width' => '10%',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
    'name' => 'name',
  ),
  'PAYLOAD_INPUT' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PAYLOAD_INPUT',
    'width' => '10%',
    'default' => true,
    'name' => 'payload_input',
  ),
  'RESPONSE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_RESPONSE',
    'width' => '10%',
    'default' => true,
    'name' => 'response',
  ),
  'APPROX_CHARGE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_APPROX_CHARGE',
    'width' => '10%',
    'default' => true,
    'name' => 'approx_charge',
  ),
  'GENERATED_QUERY' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_GENERATED_QUERY',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
    'name' => 'generated_query',
  ),
  'IS_CORRECT' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_IS_CORRECT',
    'width' => '10%',
    'name' => 'is_correct',
  ),
  'REQUEST_BY' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_REQUEST_BY',
    'id' => 'USER_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'request_by',
  ),
  'TIME_TAKEN' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_TIME_TAKEN',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
    'name' => 'assigned_user_name',
  ),
),
);
