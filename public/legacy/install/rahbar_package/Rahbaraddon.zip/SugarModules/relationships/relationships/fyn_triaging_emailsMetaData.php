<?php
// created: 2026-01-17 22:48:43
$dictionary["fyn_triaging_emails"] = array (
  'true_relationship_type' => 'one-to-one',
  'relationships' => 
  array (
    'fyn_triaging_emails' => 
    array (
      'lhs_module' => 'Fyn_Triaging',
      'lhs_table' => 'fyn_triaging',
      'lhs_key' => 'id',
      'rhs_module' => 'Emails',
      'rhs_table' => 'emails',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'fyn_triaging_emails_c',
      'join_key_lhs' => 'fyn_triaging_emailsfyn_triaging_ida',
      'join_key_rhs' => 'fyn_triaging_emailsemails_idb',
    ),
  ),
  'table' => 'fyn_triaging_emails_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'fyn_triaging_emailsfyn_triaging_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'fyn_triaging_emailsemails_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'fyn_triaging_emailsspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'fyn_triaging_emails_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'fyn_triaging_emailsfyn_triaging_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'fyn_triaging_emails_idb2',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'fyn_triaging_emailsemails_idb',
      ),
    ),
  ),
);