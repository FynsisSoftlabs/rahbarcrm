<?php
// created: 2026-01-17 22:48:43
$dictionary["fyn_triaging_cases"] = array (
  'true_relationship_type' => 'one-to-one',
  'relationships' => 
  array (
    'fyn_triaging_cases' => 
    array (
      'lhs_module' => 'Fyn_Triaging',
      'lhs_table' => 'fyn_triaging',
      'lhs_key' => 'id',
      'rhs_module' => 'Cases',
      'rhs_table' => 'cases',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'fyn_triaging_cases_c',
      'join_key_lhs' => 'fyn_triaging_casesfyn_triaging_ida',
      'join_key_rhs' => 'fyn_triaging_casescases_idb',
    ),
  ),
  'table' => 'fyn_triaging_cases_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'fyn_triaging_casesfyn_triaging_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'fyn_triaging_casescases_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'fyn_triaging_casesspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'fyn_triaging_cases_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'fyn_triaging_casesfyn_triaging_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'fyn_triaging_cases_idb2',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'fyn_triaging_casescases_idb',
      ),
    ),
  ),
);