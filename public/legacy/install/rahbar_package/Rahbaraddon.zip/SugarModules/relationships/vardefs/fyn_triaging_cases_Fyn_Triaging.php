<?php
// created: 2026-01-17 22:48:43
$dictionary["Fyn_Triaging"]["fields"]["fyn_triaging_cases"] = array (
  'name' => 'fyn_triaging_cases',
  'type' => 'link',
  'relationship' => 'fyn_triaging_cases',
  'source' => 'non-db',
  'module' => 'Cases',
  'bean_name' => 'Case',
  'vname' => 'LBL_FYN_TRIAGING_CASES_FROM_CASES_TITLE',
  'id_name' => 'fyn_triaging_casescases_idb',
);
$dictionary["Fyn_Triaging"]["fields"]["fyn_triaging_cases_name"] = array (
  'name' => 'fyn_triaging_cases_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_FYN_TRIAGING_CASES_FROM_CASES_TITLE',
  'save' => true,
  'id_name' => 'fyn_triaging_casescases_idb',
  'link' => 'fyn_triaging_cases',
  'table' => 'cases',
  'module' => 'Cases',
  'rname' => 'name',
);
$dictionary["Fyn_Triaging"]["fields"]["fyn_triaging_casescases_idb"] = array (
  'name' => 'fyn_triaging_casescases_idb',
  'type' => 'link',
  'relationship' => 'fyn_triaging_cases',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_FYN_TRIAGING_CASES_FROM_CASES_TITLE',
);
