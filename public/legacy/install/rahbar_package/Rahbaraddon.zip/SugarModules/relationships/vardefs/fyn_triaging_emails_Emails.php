<?php
// created: 2026-01-17 22:48:43
$dictionary["Email"]["fields"]["fyn_triaging_emails"] = array (
  'name' => 'fyn_triaging_emails',
  'type' => 'link',
  'relationship' => 'fyn_triaging_emails',
  'source' => 'non-db',
  'module' => 'Fyn_Triaging',
  'bean_name' => 'Fyn_Triaging',
  'vname' => 'LBL_FYN_TRIAGING_EMAILS_FROM_FYN_TRIAGING_TITLE',
  'id_name' => 'fyn_triaging_emailsfyn_triaging_ida',
);
$dictionary["Email"]["fields"]["fyn_triaging_emails_name"] = array (
  'name' => 'fyn_triaging_emails_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_FYN_TRIAGING_EMAILS_FROM_FYN_TRIAGING_TITLE',
  'save' => true,
  'id_name' => 'fyn_triaging_emailsfyn_triaging_ida',
  'link' => 'fyn_triaging_emails',
  'table' => 'fyn_triaging',
  'module' => 'Fyn_Triaging',
  'rname' => 'name',
);
$dictionary["Email"]["fields"]["fyn_triaging_emailsfyn_triaging_ida"] = array (
  'name' => 'fyn_triaging_emailsfyn_triaging_ida',
  'type' => 'link',
  'relationship' => 'fyn_triaging_emails',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_FYN_TRIAGING_EMAILS_FROM_FYN_TRIAGING_TITLE',
);
