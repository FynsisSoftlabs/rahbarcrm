<?php
// created: 2026-01-17 22:48:43
$dictionary["Fyn_Triaging"]["fields"]["fyn_triaging_emails"] = array (
  'name' => 'fyn_triaging_emails',
  'type' => 'link',
  'relationship' => 'fyn_triaging_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_FYN_TRIAGING_EMAILS_FROM_EMAILS_TITLE',
  'id_name' => 'fyn_triaging_emailsemails_idb',
);
$dictionary["Fyn_Triaging"]["fields"]["fyn_triaging_emails_name"] = array (
  'name' => 'fyn_triaging_emails_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_FYN_TRIAGING_EMAILS_FROM_EMAILS_TITLE',
  'save' => true,
  'id_name' => 'fyn_triaging_emailsemails_idb',
  'link' => 'fyn_triaging_emails',
  'table' => 'emails',
  'module' => 'Emails',
  'rname' => 'name',
);
$dictionary["Fyn_Triaging"]["fields"]["fyn_triaging_emailsemails_idb"] = array (
  'name' => 'fyn_triaging_emailsemails_idb',
  'type' => 'link',
  'relationship' => 'fyn_triaging_emails',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_FYN_TRIAGING_EMAILS_FROM_EMAILS_TITLE',
);
