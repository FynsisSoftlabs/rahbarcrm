<?php
// created: 2026-01-17 22:48:43
$dictionary["Lead"]["fields"]["fyn_triaging_leads"] = array (
  'name' => 'fyn_triaging_leads',
  'type' => 'link',
  'relationship' => 'fyn_triaging_leads',
  'source' => 'non-db',
  'module' => 'Fyn_Triaging',
  'bean_name' => 'Fyn_Triaging',
  'vname' => 'LBL_FYN_TRIAGING_LEADS_FROM_FYN_TRIAGING_TITLE',
  'id_name' => 'fyn_triaging_leadsfyn_triaging_ida',
);
$dictionary["Lead"]["fields"]["fyn_triaging_leads_name"] = array (
  'name' => 'fyn_triaging_leads_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_FYN_TRIAGING_LEADS_FROM_FYN_TRIAGING_TITLE',
  'save' => true,
  'id_name' => 'fyn_triaging_leadsfyn_triaging_ida',
  'link' => 'fyn_triaging_leads',
  'table' => 'fyn_triaging',
  'module' => 'Fyn_Triaging',
  'rname' => 'name',
);
$dictionary["Lead"]["fields"]["fyn_triaging_leadsfyn_triaging_ida"] = array (
  'name' => 'fyn_triaging_leadsfyn_triaging_ida',
  'type' => 'link',
  'relationship' => 'fyn_triaging_leads',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_FYN_TRIAGING_LEADS_FROM_FYN_TRIAGING_TITLE',
);
