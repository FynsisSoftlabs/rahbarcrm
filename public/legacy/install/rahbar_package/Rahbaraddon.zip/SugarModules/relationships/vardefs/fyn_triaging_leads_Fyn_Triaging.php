<?php
// created: 2026-01-17 22:48:43
$dictionary["Fyn_Triaging"]["fields"]["fyn_triaging_leads"] = array (
  'name' => 'fyn_triaging_leads',
  'type' => 'link',
  'relationship' => 'fyn_triaging_leads',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'vname' => 'LBL_FYN_TRIAGING_LEADS_FROM_LEADS_TITLE',
  'id_name' => 'fyn_triaging_leadsleads_idb',
);
$dictionary["Fyn_Triaging"]["fields"]["fyn_triaging_leads_name"] = array (
  'name' => 'fyn_triaging_leads_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_FYN_TRIAGING_LEADS_FROM_LEADS_TITLE',
  'save' => true,
  'id_name' => 'fyn_triaging_leadsleads_idb',
  'link' => 'fyn_triaging_leads',
  'table' => 'leads',
  'module' => 'Leads',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["Fyn_Triaging"]["fields"]["fyn_triaging_leadsleads_idb"] = array (
  'name' => 'fyn_triaging_leadsleads_idb',
  'type' => 'link',
  'relationship' => 'fyn_triaging_leads',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_FYN_TRIAGING_LEADS_FROM_LEADS_TITLE',
);
