<?php
// created: 2026-01-17 22:48:43
$dictionary["Case"]["fields"]["fyn_triaging_cases"] = array (
  'name' => 'fyn_triaging_cases',
  'type' => 'link',
  'relationship' => 'fyn_triaging_cases',
  'source' => 'non-db',
  'module' => 'Fyn_Triaging',
  'bean_name' => 'Fyn_Triaging',
  'vname' => 'LBL_FYN_TRIAGING_CASES_FROM_FYN_TRIAGING_TITLE',
  'id_name' => 'fyn_triaging_casesfyn_triaging_ida',
);
$dictionary["Case"]["fields"]["fyn_triaging_cases_name"] = array (
  'name' => 'fyn_triaging_cases_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_FYN_TRIAGING_CASES_FROM_FYN_TRIAGING_TITLE',
  'save' => true,
  'id_name' => 'fyn_triaging_casesfyn_triaging_ida',
  'link' => 'fyn_triaging_cases',
  'table' => 'fyn_triaging',
  'module' => 'Fyn_Triaging',
  'rname' => 'name',
);
$dictionary["Case"]["fields"]["fyn_triaging_casesfyn_triaging_ida"] = array (
  'name' => 'fyn_triaging_casesfyn_triaging_ida',
  'type' => 'link',
  'relationship' => 'fyn_triaging_cases',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_FYN_TRIAGING_CASES_FROM_FYN_TRIAGING_TITLE',
);
