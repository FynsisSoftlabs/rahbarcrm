<?php

$mod_strings['LBL_TRIAGING'] = 'Rahbar Configurations';
// $mod_strings['LBL_TRIAGING_LICENSE_TITLE'] = 'License Configuration';
// $mod_strings['LBL_TRIAGING_LICENSE'] = 'Manage and configure the license for this add-on';
$mod_strings['LBL_FYNTRIAGING_CONFIG'] = 'FynTriaging Settings';
$mod_strings['LBL_FYNTRIAGING_CONFIG_DESC'] = 'Configure FynTriaging to automate email sense';
$mod_strings['LBL_FYNTRIAGING_CONFIG_TITLE'] = 'FynTriaging Configuration';
$mod_strings['LBL_RAHBARCONFIG_TITLE'] = 'FynRehbar Insight Settings';
$mod_strings['LBL_RAHBARCONFIG'] = 'Manage and configure FynRahbar Insight add-on';
$mod_strings['LBL_FYNQOL_CONFIG'] = 'FynQOL(Theme) Settings';
$mod_strings['LBL_FYNQOL_CONFIG_DESC'] = 'Configure FynQOL to set your theme';
$mod_strings['LBL_FYNQOL_CONFIG_TITLE'] = 'FynQOL Configuration';
$mod_strings['LBL_LIVEHELPERCHAT_CONFIG_TITLE'] = 'FynRehbar LHC Configuration';
$mod_strings['LBL_LIVEHELPERCHAT_CONFIG'] = 'Manage and configure the settings for FynRehbar LHC';