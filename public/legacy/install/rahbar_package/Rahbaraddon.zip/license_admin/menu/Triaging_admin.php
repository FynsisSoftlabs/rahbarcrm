<?php

global $sugar_version;

$admin_option_defs=array();

if(preg_match( "/^6.*/", $sugar_version) ) {
    // $admin_option_defs['Administration']['triaging_info']= array('helpInline','LBL_TRIAGING_LICENSE_TITLE','LBL_TRIAGING_LICENSE','./index.php?module=Triaging&action=license');
    $admin_option_defs['Administration']['triaging_config'] = array('Administration', 'LBL_FYNTRIAGING_CONFIG', 'LBL_FYNTRIAGING_CONFIG_DESC', './index.php?module=Administration&action=triagingconfig');
    $admin_option_defs['Administration']['Rahbarconfig_info']= array('helpInline','LBL_RAHBARCONFIG_TITLE','LBL_RAHBARCONFIG','./index.php?module=Administration&action=fynrahbarinsightconfig');
    $admin_option_defs['Administration']['qol_info'] = array('Administration', 'LBL_FYNQOL_CONFIG', 'LBL_FYNQOL_CONFIG_DESC', './index.php?module=Administration&action=fynqolconfig');
    $admin_option_defs['Administration']['livehelperchat_config']= array('helpInline','LBL_LIVEHELPERCHAT_CONFIG_TITLE','LBL_LIVEHELPERCHAT_CONFIG','./index.php?module=Administration&action=lhcconfig');
} else {
    // $admin_option_defs['Administration']['triaging_info']= array('helpInline','LBL_TRIAGING_LICENSE_TITLE','LBL_TRIAGING_LICENSE','javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=Triaging&action=license", {trigger: true});');
    $admin_option_defs['Administration']['triaging_config'] = array('Administration', 'LBL_FYNTRIAGING_CONFIG', 'LBL_FYNTRIAGING_CONFIG_DESC', 'javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=Administration&action=triagingconfig", {trigger: true});');
    $admin_option_defs['Administration']['Rahbarconfig_info']= array('helpInline','LBL_RAHBARCONFIG_TITLE','LBL_RAHBARCONFIG','javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=Administration&action=fynrahbarinsightconfig", {trigger: true});');
    $admin_option_defs['Administration']['qol_info'] = array('Administration', 'LBL_FYNQOL_CONFIG', 'LBL_FYNQOL_CONFIG_DESC', 'javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=Administration&action=fynqolconfig", {trigger: true});');
    $admin_option_defs['Administration']['livehelperchat_config']= array('helpInline','LBL_LIVEHELPERCHAT_CONFIG_TITLE','LBL_LIVEHELPERCHAT_CONFIG','javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=Administration&action=lhcconfig", {trigger: true});');
}

$admin_group_header[]= array('LBL_TRIAGING','',false,$admin_option_defs, '');
