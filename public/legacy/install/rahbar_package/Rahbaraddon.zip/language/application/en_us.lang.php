<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/


$app_list_strings['moduleList']['FYN_Taxrates'] = 'Xero TaxRate';
$app_list_strings['moduleList']['FYN_Xero'] = 'Xero';
$app_list_strings['moduleList']['FYN_XeroCreditNote'] = 'Xero Credit Note';
$app_list_strings['moduleList']['FYN_Xeropayment'] = 'Xero Payment';


$app_list_strings['xero_modified_date_list']=array (
  0 => 'Today',
  1 => 'Yesterday',
  5 => 'Last 5 Days',
  10 => 'Last 10 Days',
  15 => 'Last 15 Days',
  30 => 'Last 30 Days',
);
$app_list_strings['xero_duedatedropdown_list']=array (
  'OFFOLLOWINGMONTH' => 'of the following month',
  'DAYSAFTERBILLDATE' => 'day(s) after the bill date',
  'DAYSAFTERBILLMONTH' => 'day(s) after the end of the bill month',
  'OFCURRENTMONTH' => 'of the current month',
);
$app_list_strings['xero_lineamounttypes_list']=array (
  'NoTax' => 'No Tax',
  'Exclusive' => 'Tax Exclusive',
  'Inclusive' => 'Tax Inclusive',
);
$app_list_strings['xero_paymenttype_list']=array (
  'ACCRECPAYMENT' => 'Accounts Receivable Payment',
  'ACCPAYPAYMENT' => 'Accounts Payable Payment',
  'ARCREDITPAYMENT' => 'Accounts Receivable Credit Payment',
  'APCREDITPAYMENT' => 'Accounts Payable Credit Payment',
);
$app_list_strings['xero_type_list']=array (
  '' => 'Please select type',
  'ACCREC' => 'Sales',
  'ACCPAY' => 'Purchase',
);
$app_list_strings['xero_taxrate_list']=array (
  'TAX001' => 'Sales(20%)',
  'GSTONIMPORTS' => 'Sales Tax on Imports(0%)',
  'NONE' => 'Tax Exempt(0%)',
  'INPUT' => 'Tax on Purchases(0%)',
  'OUTPUT' => 'Tax on Sales(0%)',
);
$app_list_strings['xero_taxrate_list']=array (
  'TAX001' => 'Sales Tax 20%(20%)',
  'GSTONIMPORTS' => 'Sales Tax on Imports(0%)',
  'NONE' => 'Tax Exempt(0%)',
  'INPUT' => 'Tax on Purchases(0%)',
  'OUTPUT' => 'Tax on Sales(0%)',
);
$app_list_strings['xero_status_list']=array (
  '' => 'Select Xero Status',
  'DRAFT' => 'Draft',
  'SUBMITTED' => 'Awaiting Approval',
  'AUTHORISED' => 'Approved',
  'PAID' => 'Paid',
  'VOIDED' => 'Voided',
  'DELETED' => 'Deleted',
);
$app_list_strings['xero_taxrate_list']=array (
  'GSTONIMPORTS' => 'Sales Tax on Imports(0%)',
  'NONE' => 'Tax Exempt(0%)',
  'OUTPUT' => 'Tax on Consulting(8%)',
  'TAX001' => 'Tax on Goods(8%)',
  'INPUT' => 'Tax on Purchases(8%)',
);
$app_list_strings['xero_taxrate_list']=array (
  'GSTONIMPORTS' => 'Sales Tax on Imports(0%)',
  'NONE' => 'Tax Exempt(0%)',
  'OUTPUT' => 'Tax on Consulting(8%)',
  'TAX001' => 'Tax on Goods(8%)',
  'INPUT' => 'Tax on Purchases(8%)',
);
$app_list_strings['xero_taxrate_list']=array (
  'GSTONIMPORTS' => 'Sales Tax on Imports(0%)',
  'NONE' => 'Tax Exempt(0%)',
  'OUTPUT' => 'Tax on Consulting(8%)',
  'TAX001' => 'Tax on Goods(8%)',
  'INPUT' => 'Tax on Purchases(8%)',
);
$app_list_strings['xero_taxrate_list']=array (
  'GSTONIMPORTS' => 'Sales Tax on Imports(0%)',
  'NONE' => 'Tax Exempt(0%)',
  'OUTPUT' => 'Tax on Consulting(8%)',
  'TAX001' => 'Tax on Goods(8%)',
  'INPUT' => 'Tax on Purchases(8%)',
);
$app_list_strings['xero_accounting_list']=array (
  200 => '200 - Sales',
  260 => '260 - Other Revenue',
  270 => '270 - Interest Income',
  960 => '960 - Retained Earnings',
  970 => '970 - Owner A Share Capital',
  800 => '800 - Accounts Payable',
  801 => '801 - Unpaid Expense Claims',
  820 => '820 - Sales Tax',
  825 => '825 - Employee Tax Payable',
  826 => '826 - Superannuation Payable',
  830 => '830 - Income Tax Payable',
  835 => '835 - Revenue Received in Advance',
  840 => '840 - Historical Adjustment',
  850 => '850 - Suspense',
  855 => '855 - Clearing Account',
  860 => '860 - Rounding',
  877 => '877 - Tracking Transfers',
  880 => '880 - Owner A Drawings',
  881 => '881 - Owner A Funds Introduced',
  900 => '900 - Loan',
  '090' => '090 - Business Bank Account',
  '091' => '091 - Business Savings Account',
  610 => '610 - Accounts Receivable',
  620 => '620 - Prepayments',
  630 => '630 - Inventory',
  710 => '710 - Office Equipment',
  711 => '711 - Less Accumulated Depreciation on Office Equipment',
  720 => '720 - Computer Equipment',
  721 => '721 - Less Accumulated Depreciation on Computer Equipment',
  300 => '300 - Purchases',
  310 => '310 - Cost of Goods Sold',
  400 => '400 - Advertising',
  404 => '404 - Bank Fees',
  408 => '408 - Cleaning',
  412 => '412 - Consulting & Accounting',
  416 => '416 - Depreciation',
  420 => '420 - Entertainment',
  425 => '425 - Freight & Courier',
  429 => '429 - General Expenses',
  433 => '433 - Insurance',
  437 => '437 - Interest Expense',
  441 => '441 - Legal expenses',
  445 => '445 - Light, Power, Heating',
  449 => '449 - Motor Vehicle Expenses',
  453 => '453 - Office Expenses',
  461 => '461 - Printing & Stationery',
  469 => '469 - Rent',
  473 => '473 - Repairs and Maintenance',
  477 => '477 - Wages and Salaries',
  478 => '478 - Superannuation',
  485 => '485 - Subscriptions',
  489 => '489 - Telephone & Internet',
  493 => '493 - Travel - National',
  494 => '494 - Travel - International',
  497 => '497 - Bank Revaluations',
  498 => '498 - Unrealised Currency Gains',
  499 => '499 - Realised Currency Gains',
  505 => '505 - Income Tax Expense',
);
$app_list_strings['xero_accounting_pur_list']=array (
  300 => '300 - Purchases',
  310 => '310 - Cost of Goods Sold',
  400 => '400 - Advertising',
  404 => '404 - Bank Fees',
  408 => '408 - Cleaning',
  412 => '412 - Consulting & Accounting',
  416 => '416 - Depreciation',
  420 => '420 - Entertainment',
  425 => '425 - Freight & Courier',
  429 => '429 - General Expenses',
  433 => '433 - Insurance',
  437 => '437 - Interest Expense',
  441 => '441 - Legal expenses',
  445 => '445 - Light, Power, Heating',
  449 => '449 - Motor Vehicle Expenses',
  453 => '453 - Office Expenses',
  461 => '461 - Printing & Stationery',
  469 => '469 - Rent',
  473 => '473 - Repairs and Maintenance',
  477 => '477 - Wages and Salaries',
  478 => '478 - Superannuation',
  485 => '485 - Subscriptions',
  489 => '489 - Telephone & Internet',
  493 => '493 - Travel - National',
  494 => '494 - Travel - International',
  497 => '497 - Bank Revaluations',
  498 => '498 - Unrealised Currency Gains',
  499 => '499 - Realised Currency Gains',
  505 => '505 - Income Tax Expense',
  '090' => '090 - Business Bank Account',
  '091' => '091 - Business Savings Account',
  610 => '610 - Accounts Receivable',
  620 => '620 - Prepayments',
  630 => '630 - Inventory',
  710 => '710 - Office Equipment',
  711 => '711 - Less Accumulated Depreciation on Office Equipment',
  720 => '720 - Computer Equipment',
  721 => '721 - Less Accumulated Depreciation on Computer Equipment',
  800 => '800 - Accounts Payable',
  801 => '801 - Unpaid Expense Claims',
  820 => '820 - Sales Tax',
  825 => '825 - Employee Tax Payable',
  826 => '826 - Superannuation Payable',
  830 => '830 - Income Tax Payable',
  835 => '835 - Revenue Received in Advance',
  840 => '840 - Historical Adjustment',
  850 => '850 - Suspense',
  855 => '855 - Clearing Account',
  860 => '860 - Rounding',
  877 => '877 - Tracking Transfers',
  880 => '880 - Owner A Drawings',
  881 => '881 - Owner A Funds Introduced',
  900 => '900 - Loan',
  960 => '960 - Retained Earnings',
  970 => '970 - Owner A Share Capital',
  200 => '200 - Sales',
  260 => '260 - Other Revenue',
  270 => '270 - Interest Income',
);
$app_list_strings['xero_accounting_pay_list']=array (
  '562555f2-8cde-4ce9-8203-0363922537a4' => '090 - Business Bank Account',
  '72f1dcfe-5d7d-4239-bf9d-e12469309716' => '091 - Business Savings Account',
  'ea0e787d-67c5-4379-8ba7-d671a9522e1f' => '855 - Clearing Account',
  '50cad88d-0716-4e9a-b436-e0e903805207' => '880 - Owner A Drawings',
  '680e946e-67d9-4c5d-a4ac-a70a0d3cef78' => '881 - Owner A Funds Introduced',
  'f26bf6e9-42e1-438f-9db9-3b2f228de8be' => '970 - Owner A Share Capital',
);
$app_list_strings['xero_currencies_list']=array (
  '' => 'None',
  'U' => 'U',
);
$app_list_strings['xero_taxrate_list']=array (
  'GSTONIMPORTS' => 'Sales Tax on Imports(0%)',
  'NONE' => 'Tax Exempt(0%)',
  'OUTPUT' => 'Tax on Consulting(8%)',
  'TAX001' => 'Tax on Goods(8%)',
  'INPUT' => 'Tax on Purchases(8%)',
);
