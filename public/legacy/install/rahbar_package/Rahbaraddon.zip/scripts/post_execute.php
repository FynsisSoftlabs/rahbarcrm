<?php
if (! defined('sugarEntry') || ! sugarEntry) die('Not A Valid Entry Point');

function post_install() 
{
    global $sugar_version, $db, $dictionary, $current_user;
 
    require_once('include/utils.php');
    require_once('include/utils/file_utils.php');
    require_once('config.php');
    require_once('include/MVC/Controller/SugarController.php');
    require_once('modules/ModuleBuilder/controller.php');
    require_once('modules/ModuleBuilder/parsers/ParserFactory.php');
 
    //define fields to add to the UI
    $contact_lists = array(
        'fyn_enable_portal_c' => array(
            'name' => 'fyn_enable_portal_c',
            'label' => 'LBL_FYN_ENABLE_PORTAL',
        ),
        'fyn_username_c' => array(
            'name' => 'fyn_username_c',
            'label' => 'LBL_FYN_USERNAME',
        ),
         'fyn_password_c' => array(
            'name' => 'fyn_password_c',
            'label' => 'LBL_FYN_PASSWORD',
        ),
    );
 
    $layoutFields = array();
    foreach ($contact_lists as $key => $field) {
        $layoutFields[$key] = $field;
    }
    
    if(preg_match( "/^6.*/", $sugar_version)) 
    {
        addField2View('Contacts', $layoutFields, 'detailview');
        addField2View('Contacts', $layoutFields, 'editview');
    }
    else
    {
        addField2View('Contacts', $layoutFields, 'recordview');
    }
    //add to database as we are using Vardefs Ext instead of custom_fields in manifest due to: https://community.sugarcrm.com/sugarcrm/topics/custom_utils_in_sugarcrm_7_1_5_not_loading
   
    
}


function addField2View ($module, $layoutFields, $view) {
    echo "<br /><b> Updating module $module view $view with custom fields.</b><br />";   
 
    $parser = ParserFactory::getParser($view, $module);
    if (!$parser) {
        $GLOBALS['log']->fatal("No parser found for $module | $view");
    }
    
    $row = $column = 0;
    foreach ($layoutFields as $field => $field_def) {
        $parser->_viewdefs['panels']['LBL_SUGARCHIMP'][$row][$column] = $field_def;
        echo ("<strong>$field</strong> field added to $module $view View.<br />");
        $column = ($column > 0) ? 0 : 1;
        if($column === 0) $row++;
    }
 
    $parser->handleSave(false);
}