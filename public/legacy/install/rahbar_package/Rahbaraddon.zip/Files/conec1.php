<?php

  $cust = $_POST['cust']; 
  $crmusername = $_POST['crmusername']; 
  $crmuserpass = $_POST['crmuserpass']; 
  $companyname = $_POST['companyname']; 

define('sugarEntry', TRUE); 
ini_set('max_execution_time', 0);
error_reporting(E_ERROR);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
include_once('include/entryPoint.php');
require_once('data/BeanFactory.php');  
  if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

  global $db;  

   
      $update_conx=" UPDATE fynportalcon 
                                    SET portallink='".$cust."',crmname='".$crmusername."',crmpass='".$crmuserpass."',crmcompany='".$companyname."'";
                      $res_updatex = $db->query($update_conx);

                      if($res_updatex)
                      {
                      	echo "done";
                      }
                      else
                      {
                      	echo "not done";
                      }
  
?>