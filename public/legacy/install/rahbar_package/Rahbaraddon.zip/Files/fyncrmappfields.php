<?php
define('sugarEntry', TRUE);
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('include/entryPoint.php');
global $sugar_config;
$module_name_drop = $_REQUEST['dropmoduleName'];
//print_r($data);
$module_list = array_intersect($GLOBALS['moduleList'],array_keys($GLOBALS['beanList']));
$res_details_fields = explode(",",$sugar_config['mobile_detailview_fields'][$module_name_drop]);
$res_list = explode(",",$sugar_config['mobile_listview_fields'][$module_name_drop]);
$res_search = explode(",",$sugar_config['mobile_searchview_fields'][$module_name_drop]);

$dis_array = array('id'=>'id','modified_user_id'=>'modified_user_id','deleted'=>'deleted','phone_alternate'=>'phone_alternate','ownership'=>'ownership','ticker_symbol'=>'ticker_symbol','sic_code'=>'sic_code','created_by_link'=>'created_by_link','modified_user_link'=>'modified_user_link','rating'=>'rating','assigned_user_link'=>'assigned_user_link','contact_created_by'=>'contact_created_by','parent_id'=>'parent_id','email_opt_out'=>'email_opt_out','invalid_email'=>'invalid_email','campaign_id'=>'campaign_id','jjwg_maps_address_c'=>'jjwg_maps_address_c','jjwg_maps_geocode_status_c'=>'jjwg_maps_geocode_status_c','jjwg_maps_lat_c'=>'jjwg_maps_lat_c','jjwg_maps_lng_c'=>'jjwg_maps_lng_c','assigned_user_id'=>'assigned_user_id','opportunity_role_id'=>'opportunity_role_id','reports_to_id'=>'reports_to_id','accept_status_id'=>'accept_status_id','event_invite_id'=>'event_invite_id','event_status_id'=>'event_status_id','cases'=>'cases','email'=>'email','tasks'=>'tasks','notes'=>'notes','meetings'=>'meetings','calls'=>'calls','emails'=>'emails','documents'=>'documents','bugs'=>'bugs','contacts'=>'contacts','opportunities'=>'opportunities','project'=>'project','leads'=>'leads','campaigns'=>'campaigns','campaign_accounts'=>'campaign_accounts','prospect_lists'=>'prospect_lists','aos_invoices'=>'aos_invoices','aos_quotes'=>'aos_quotes','aos_contracts'=>'aos_contracts','members'=>'members','member_of'=>'member_of','campaign_name'=>'campaign_name','fyn_username_c'=>'fyn_username_c','fyn_id_c'=>'fyn_id_c');

$arr1 = [];

//  foreach ($res_details_fields as $key=>$value)
// {
// 	# code...
//
// 	$arr1[]= '<tr><td style="border:1px solid #000;width: 242px;cursor:pointer">'.$value.'</td></tr>';
// }

//print_r($arr1);
    // print_r($res);
    //echo '<tr> <td>'.$res.'</td></tr>';
foreach($module_list as $module_name)
{
     $bean = BeanFactory::getBean($module_name_drop);
     $field_defs[$module_name] = $bean->getFieldDefinitions();
}

 foreach ($field_defs[$module_name] as $key => $value)
     {
       # code...

       if(in_array($key, $res_details_fields))
         {
            $value = $key." - (".translate($value['vname'], $module_name_drop).")";
         	$arr1[]= '<tr><td style="border:1px solid #000;width: 242px;cursor:pointer">'.$value.'</td></tr>';
         }

       else
       {
        if(in_array($key, $dis_array))
          {
             $key = $key." - (".translate($value['vname'], $module_name_drop).")";
             $arr7[] = '<tr> <td style="border:1px solid #000;width: 242px;cursor:pointer">'.$key.'</td></tr>';
         }
          else
             {
                 $key = $key." - (".translate($value['vname'], $module_name_drop).")";
                 $arr2[] = '<tr> <td style="border:1px solid #000;width: 242px;cursor:pointer">'.$key.'</td></tr>';
             }
          //echo '<tr> <td>'.$key.'</td></tr>';

       }

     }

     /* foreach ($res_list as $key=>$value)
      {
  # code...
    }*/


foreach ($field_defs[$module_name] as $key => $value)
     {
       # code...

       if(in_array($key, $res_list))
         {
              $key = $key." - (".translate($value['vname'], $module_name_drop).")";
              $arr3[]= '<tr><td style="border:1px solid #000;width: 242px;cursor:pointer">'.$key.'</td></tr>';
         }

       else
       {
        if(in_array($key, $dis_array))
          {
             $key = $key." - (".translate($value['vname'], $module_name_drop).")";
           $arr8[] = '<tr> <td style="border:1px solid #000;width: 242px;cursor:pointer">'.$key.'</td></tr>';
          }
          else
             {
                    $key = $key." - (".translate($value['vname'], $module_name_drop).")";
                    $arr4[] = '<tr> <td style="border:1px solid #000;width: 242px;cursor:pointer">'.$key.'</td></tr>';
             }
          //echo '<tr> <td>'.$key.'</td></tr>';

       }




     }

  //     foreach ($res_search as $key=>$value)
  //     {
  // # code...
  //       $key = $key." - (".translate($value['vname'], $module_name_drop).")";
  //       $arr5[]= '<tr><td style="border:1px solid #000;width: 242px;cursor:pointer">'.$value.'</td></tr>';
  //     }

  $arr5 = [];

foreach ($field_defs[$module_name] as $key => $value)
     {
       # code...

       if(in_array($key, $res_search))
         {
            $value = $key." - (".translate($value['vname'], $module_name_drop).")";
            $arr5[]= '<tr><td style="border:1px solid #000;width: 242px;cursor:pointer">'.$value.'</td></tr>';

         }

       else
       {
        if(in_array($key, $dis_array))
          {
             $key = $key." - (".translate($value['vname'], $module_name_drop).")";
           $arr9[] = '<tr> <td style="border:1px solid #000;width: 242px;cursor:pointer">'.$key.'</td></tr>';
         }
          else
             {
                   $key = $key." - (".translate($value['vname'], $module_name_drop).")";
                   $arr6[] = '<tr> <td style="border:1px solid #000;width: 242px;cursor:pointer">'.$key.'</td></tr>';
             }
          //echo '<tr> <td>'.$key.'</td></tr>';

       }




     }

     echo json_encode(array('detailFields'=>$arr1,'result2'=>$arr2,'result3'=>$arr3,'result4'=>$arr4,'result5'=>$arr5,'result6'=>$arr6,'result7'=>$arr7,'result8'=>$arr8,'result9'=>$arr9));

      //
     //));




?>
