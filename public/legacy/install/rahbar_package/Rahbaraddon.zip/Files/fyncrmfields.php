<?php
define('sugarEntry', TRUE);
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('include/entryPoint.php');
require_once('modules/Configurator/Configurator.php');

$sel_mod = $_REQUEST['selModuleDrop'];
$disp_mod_detailfields = $_REQUEST['disp_mod_fields'];


array_splice($sel_mod, 0, 1);
array_splice($disp_mod_detailfields, 0, 1);

$data = [];

foreach($disp_mod_detailfields as $val)
{
   $val =  trim(explode("-",$val)[0]);
   array_push($data, $val);
}



$cfg = new Configurator();
if($disp_mod_detailfields!=''&&$sel_mod!='')
 {
 	$cfg->config['mobile_detailview_fields'][$sel_mod] = implode(",", $data);

 }


 $cfg->saveConfig();

?>
