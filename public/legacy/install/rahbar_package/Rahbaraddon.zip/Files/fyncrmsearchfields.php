<?php
define('sugarEntry', TRUE);
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('include/entryPoint.php');
require_once('modules/Configurator/Configurator.php');
 
$sel_mod = $_REQUEST['selModuleDrop'];

$disp_mod_searchfields = $_REQUEST['disp_search_fields'];


array_splice($sel_mod, 0, 1);

array_splice($disp_mod_searchfields, 0, 1);


$cfg = new Configurator();
if($disp_mod_searchfields!=''&&$sel_mod!='')
 {
 
    $cfg->config['mobile_searchview_fields'][$sel_mod] = implode(",",$disp_mod_searchfields);
 }
 
 
 $cfg->saveConfig();

?>