<?php
define('sugarEntry', TRUE);
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('include/entryPoint.php');
require_once('modules/Configurator/Configurator.php');

require_once('modules/Users/User.php');
global $user;
global $sugar_config;         

    

$disp_mod =array("Opportunities","Leads","Calls","Meetings","Tasks","Cases");
//$GLOBALS['log']->fatal('TESTNEWW BY SYEDUU 666678oopsmkee => '.print_r($disp_mod,true));
$set_detailview_contacts =array("last_name","phone_mobile","email1","account_name","primary_address_postalcode","primary_address_country","primary_address_state","primary_address_city","assigned_user_name");
$set_detailview_accounts =array("name","phone_office","email1","billing_address_country","billing_address_postalcode","billing_address_state","billing_address_city","website","assigned_user_name");
$set_detailview_opportunities =array("name","account_name","opportunity_type","sales_stage","date_closed","next_step","probability","amount","lead_source","assigned_user_name");
$set_detailview_calls =array("name","status","date_start","date_end","parent_type","parent_name","direction","assigned_user_name");
$set_detailview_leads =array("name","status","account_name","email1","phone_mobile","website","lead_source","primary_address_country","primary_address_postalcode","primary_address_state","primary_address_city","assigned_user_name","date_entered","created_by");
$set_detailview_meetings =array("name","status","date_start","date_end","location","parent_type","parent_name","description","assigned_user_name");
$set_detailview_tasks =array("name","status","priority","assigned_user_name");
$set_detailview_cases =array("name","case_number","type","state","status","priority","account_name");
$set_searchview_all = array("name","status","date_entered");

//$set_users_all=  explode(",",$set_users[]);



$mod_disp_res = explode(",",$sugar_config['mobile_users_modules']);
$get_contacts_detailview = explode(",",$sugar_config['mobile_detailview_fields']['Contacts']);
$get_accounts_detailview = explode(",",$sugar_config['mobile_detailview_fields']['Accounts']);
$get_opportunities_detailview = explode(",",$sugar_config['mobile_detailview_fields']['Opportunities']);
$get_calls_detailview = explode(",",$sugar_config['mobile_detailview_fields']['Calls']);
$get_leads_detailview = explode(",",$sugar_config['mobile_detailview_fields']['Leads']);
$get_meetings_detailview = explode(",",$sugar_config['mobile_detailview_fields']['Meetings']);
$get_tasks_detailview = explode(",",$sugar_config['mobile_detailview_fields']['Tasks']);
$get_cases_detailview = explode(",",$sugar_config['mobile_detailview_fields']['Cases']);
$getUsers = explode(",",$sugar_config['mobile_users']);
//$getUsers = explode(",",$sugar_config['mobile_users']);


//$GLOBALS['log']->fatal('TESTNEWW BY SYEDUU   =>   '.count($mod_disp_res));



$mod_count = count($mod_disp_res);
$contacts_detailview_count = count($get_contacts_detailview);
$accounts_detailview_count = count($get_accounts_detailview);
$opportunities_detailview_count = count($get_opportunities_detailview);
$calls_detailview_count = count($get_calls_detailview);
$leads_detailview_count = count($get_leads_detailview);
$meetings_detailview_count = count($get_meetings_detailview);
$tasks_detailview_count = count($get_tasks_detailview);
$cases_detailview_count = count($get_cases_detailview);
 $users_count = count($getUsers); 

 

 $cfg = new Configurator();
if($mod_count == 1)
{
         $GLOBALS['log']->fatal('Count is one');        
         $cfg->config['mobile_users_modules'] = implode(",",$disp_mod);
         $cfg->saveConfig();
}
else
{
    $GLOBALS['log']->fatal('Module Count is more then one');
}
if($contacts_detailview_count == 1)
{
        $cfg->config['mobile_detailview_fields']['Contacts'] = implode(",",$set_detailview_contacts);
        $cfg->config['mobile_listview_fields']['Contacts'] = implode(",",$set_detailview_contacts);
        $cfg->config['mobile_searchview_fields']['Contacts'] = implode(",",$set_searchview_all);
         $cfg->saveConfig();
}
else
{
    $GLOBALS['log']->fatal('Contact Count is more then one');
}

if($accounts_detailview_count == 1)
{
        $cfg->config['mobile_detailview_fields']['Accounts'] = implode(",",$set_detailview_accounts);
        $cfg->config['mobile_listview_fields']['Accounts'] = implode(",",$set_detailview_accounts);
        $cfg->config['mobile_searchview_fields']['Accounts'] = implode(",",$set_searchview_all);
         $cfg->saveConfig();
}

else
{
    $GLOBALS['log']->fatal('Accounts count is more then one');
}

if($opportunities_detailview_count == 1)
{
        $cfg->config['mobile_detailview_fields']['Opportunities'] = implode(",",$set_detailview_opportunities);
        $cfg->config['mobile_listview_fields']['Opportunities'] = implode(",",$set_detailview_opportunities);
        $cfg->config['mobile_searchview_fields']['Opportunities'] = implode(",",$set_searchview_all);
         $cfg->saveConfig();
}

else
{
    $GLOBALS['log']->fatal('Accounts count is more then one');
}

if($calls_detailview_count == 1)
{
        $cfg->config['mobile_detailview_fields']['Calls'] = implode(",",$set_detailview_calls);
        $cfg->config['mobile_listview_fields']['Calls'] = implode(",",$set_detailview_calls);
        $cfg->config['mobile_searchview_fields']['Calls'] = implode(",",$set_searchview_all);
         $cfg->saveConfig();
}

else
{
    $GLOBALS['log']->fatal('Calls count is more then one');
}

if($leads_detailview_count == 1)
{
        $cfg->config['mobile_detailview_fields']['Leads'] = implode(",",$set_detailview_leads);
        $cfg->config['mobile_listview_fields']['Leads'] = implode(",",$set_detailview_leads);
        $cfg->config['mobile_searchview_fields']['Leads'] = implode(",",$set_searchview_all);
         $cfg->saveConfig();
}

else
{
    $GLOBALS['log']->fatal('Calls count is more then one');
}

if($meetings_detailview_count == 1)
{
        $cfg->config['mobile_detailview_fields']['Meetings'] = implode(",",$set_detailview_meetings);
        $cfg->config['mobile_listview_fields']['Meetings'] = implode(",",$set_detailview_meetings);
        $cfg->config['mobile_searchview_fields']['Meetings'] = implode(",",$set_searchview_all);
         $cfg->saveConfig();
}

else
{
    $GLOBALS['log']->fatal('Calls count is more then one');
}

if($tasks_detailview_count == 1)
{
        $cfg->config['mobile_detailview_fields']['Tasks'] = implode(",",$set_detailview_tasks);
        $cfg->config['mobile_listview_fields']['Tasks'] = implode(",",$set_detailview_tasks);
        $cfg->config['mobile_searchview_fields']['Tasks'] = implode(",",$set_searchview_all);
         $cfg->saveConfig();
}

else
{
    $GLOBALS['log']->fatal('Calls count is more then one');
}


if($cases_detailview_count == 1)
{
        $cfg->config['mobile_detailview_fields']['Cases'] = implode(",",$set_detailview_cases);
        $cfg->config['mobile_listview_fields']['Cases'] = implode(",",$set_detailview_cases);
        $cfg->config['mobile_searchview_fields']['Cases'] = implode(",",$set_searchview_all); 
         $cfg->saveConfig();
}

else
{
    $GLOBALS['log']->fatal('Calls count is more then one');
}
 
 
if($users_count == 1)
{
    
 //$GLOBALS['log']->fatal('Users count is one))))000'); 
      
       

 $ContactBean = new User();
     $ListOfContactBeans=$ContactBean->get_full_list("", "", true);
      foreach ($ListOfContactBeans as $SingleContactBean) 
     {
        
       // $GLOBALS['log']->fatal('********************************');
      
        $setusers[]=$SingleContactBean->user_name; 
        $cfg->config['mobile_users'] = implode(",",$setusers);
         $cfg->saveConfig();
       
     }
     }
else
{
   
}

?>