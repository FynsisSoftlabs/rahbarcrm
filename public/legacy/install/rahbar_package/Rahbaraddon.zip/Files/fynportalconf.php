<?php

echo "hi";

echo $name = $_POST['crmname'];// = "junaid";
$pass = $_POST['crmpas'];// = "junaid123";
$url  =  $_POST['crmurl'];// = "localhost/zam";
$cus  =  $_POST['custom'];// = "localhost/fyncustomportal" ;
$companyname  =  $_POST['companyname'];

define('sugarEntry', TRUE); 
ini_set('max_execution_time', 0);
error_reporting(E_ERROR);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
include_once('include/entryPoint.php');
require_once('data/BeanFactory.php'); 
require_once('include/entryPoint.php');
if (!defined('sugarEntry') || !sugarEntry)die('Not A Valid Entry Point');

   require_once 'modules/Emails/Email.php';
          require_once 'include/SugarPHPMailer.php';

  global $db; 
//  $sq1w = "INSERT INTO fynportalcon (crmname, crmpass, portallink, crmcompany)
// VALUES ('Cardinal', 'Tom B. Erichsen', 'Skagen 21', 'Stavanger', '4006', 'Norway');";
//     $resw = $db->query($sq1w);

  ?>