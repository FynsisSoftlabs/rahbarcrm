<?php
define('sugarEntry', TRUE);
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('include/entryPoint.php');
require_once('modules/Configurator/Configurator.php');

$disp_mod = $_REQUEST['displayModules'];//  

array_splice($disp_mod, 0, 1);


$cfg = new Configurator();

if($disp_mod!='')
{
$cfg->config['mobile_users_modules'] = implode(",",$disp_mod); 
}
 
 $cfg->saveConfig();

?>