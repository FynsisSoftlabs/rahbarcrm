<?php
define('sugarEntry', TRUE);
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('include/entryPoint.php');
require_once('modules/Configurator/Configurator.php');

$disp_users_list = $_REQUEST['users_list'];

array_splice($disp_users_list, 0, 1);

$cfg = new Configurator();

 if($disp_users_list!='')
 {
   $cfg->config['mobile_users'] = implode(",",$disp_users_list);
 }
 
 $cfg->saveConfig();

?>