<?php 

    $email = $_POST['em']; 
   echo $fname1 = $_POST['finame']; 
   echo " ";
   echo $laname = $_POST['laname']; 
   $id = $_POST['id']; 
 
define('sugarEntry', TRUE); 
ini_set('max_execution_time', 0);
error_reporting(E_ERROR);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
include_once('include/entryPoint.php');
require_once('data/BeanFactory.php');  
  if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

  global $db;  

      $sql12 = "SELECT * FROM `fynportalcon`";
      $res12 = $db->query($sql12);
      $row12 = $res12->fetch_assoc(); 
      $portallink = $row12['portallink'];

// $servername = "localhost";
// $username = "crm";
// $password = "M4myY6Bs2rNUxmGG";
// $dbname = "crm_dev";

// $db = mysqli_connect($servername, $username, $password ,$dbname);

        $fname= $email;
        
     $fourdigitrandom = rand(1000,9999); 
               $fourdigitrandom; 
            $fyn_password_c=$fourdigitrandom;
  
       $sql="update contacts_cstm set fyn_username_c='".$fname."',fyn_password_c='".$fyn_password_c."',fyn_enable_portal_c='1' where id_c='".$id."'";
                
        $tem=$db->query($sql);
       
         if($tem)
         {
         	echo "";
            echo "";
               echo " a account has been created Sucessfully ";

               // Echo ""
               // echo "<script>alert('i');</script>";
                                    
                            require_once 'modules/Emails/Email.php';
                            require_once 'include/SugarPHPMailer.php';
 
  $bd = 'Hello '.$fname1 ." ".$laname.'<br><br>Your account has been created on Customer Portal,  <a href="'.$portallink.'">Click Here</a> for Login <br><br>Please use Email ID as Username '.$fname.' and Password     '.$fyn_password_c.'<br><br>Note: You can change your system generated password from portal.<br><br><br>Regards,<br>Fynsis Support Team.<br>';

                                $emailObj = new Email();  
                                $body .= $bd;
                                $defaults = $emailObj->getSystemDefaultEmail();  
                                $mail = new SugarPHPMailer();  
                                $mail->setMailerForSystem();  
                                $mail->From = $defaults['email'];  
                                $mail->FromName = $defaults['name'];  
                                $mail->Subject = 'Customer Portal Enabled';
                                $mail->Body = wordwrap($body,900);
                                $mail->isHTML(true);    
                                $mail->prepForOutbound();
                                $mail->AddAddress($email); 
                                 @$mail->Send();  
 

         }
          else

          {
               echo "Not Created";
          }  

          ?>