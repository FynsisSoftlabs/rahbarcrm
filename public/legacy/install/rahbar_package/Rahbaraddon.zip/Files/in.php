<?php
  
    $item_name = $_POST["col12"]; 
    $item_ab = $_POST["ab"];
  

define('sugarEntry', TRUE); 
ini_set('max_execution_time', 0);
error_reporting(E_ERROR);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
include_once('include/entryPoint.php');
require_once('data/BeanFactory.php'); 
require_once('include/entryPoint.php');
if (!defined('sugarEntry') || !sugarEntry)die('Not A Valid Entry Point');

   require_once 'modules/Emails/Email.php';
          require_once 'include/SugarPHPMailer.php';

  global $db; 


 $sq1w = "select (contacts.id)as idd,(contacts.first_name)as fa,(contacts.last_name) as la  from contacts_cases,contacts,cases where contacts.id=contact_id and cases.id=case_id and cases.id='".$item_ab ."'";
    $resw = $db->query($sq1w);
      $roww = $resw->fetch_assoc(); 
 echo        $conid = $roww['idd'];



exit;
   
 $db = mysqli_connect($servername, $username, $password ,$dbname);
 
 $date = date('Y/m/d/ H:i:s',strtotime("-0 minutes"));
 
 

 $userid='306d0d30-09d8-31e2-92fe-5e2ef82709c6';

     $sql="INSERT into aop_case_updates(id,date_entered,date_modified,created_by,modified_user_id,description,assigned_user_id,case_id,internal)select uuid(),'".$date."','".$date."','306d0d30-09d8-31e2-92fe-5e2ef82709c6','306d0d30-09d8-31e2-92fe-5e2ef82709c6','".$item_name."','306d0d30-09d8-31e2-92fe-5e2ef82709c6','".$item_ab."',0";  

//  echo $sql="insert into aop_case_updates(id,name,date_modified,case_id)select uuid(),'$item_name',' $date','$item_ab'"; 
   
     $up=$db->query($sql);
if($up)
{
	echo "update";
     
      $sql12 = "SELECT case_number,name FROM cases,cases_cstm where id='".$item_ab."' and id=id_c";
      $res12 = $db->query($sql12);
      $row12 = $res12->fetch_assoc(); 
      $number = $row12['case_number'];
      $sunam = $row12['name'];


 $sq1w = "select (contacts.id)as idd,(contacts.first_name)as fa,(contacts.last_name) as la  from contacts_cases,contacts,cases where contacts.id=contact_id and cases.id=case_id and cases.id='".$item_ab ."'";
    $resw = $db->query($sq1w);
      $roww = $resw->fetch_assoc(); 
        $conid = $roww['idd'];

    $fa=$roww['fa'];
	     $la=$roww['la'];

	  $name=$fa."".$la;   

     
                                $emailObj = new Email();  
                                $body .= $item_name;
                                $defaults = $emailObj->getSystemDefaultEmail();  
                                $mail = new SugarPHPMailer();  
                                $mail->setMailerForSystem();  
                                $mail->From = $defaults['email'];  
                                $mail->FromName = $defaults['name'];  
                                $mail->Subject = 'Re: '.$sunam.' [CASE:'.$number.']';
                                $mail->Body = wordwrap($body,900);
                                $mail->isHTML(true);    
                                $mail->prepForOutbound();
                               $mail->AddAddress('devsupport@paradisosolutions.com'); 

          $sqlem = "SELECT email_address FROM email_addr_bean_rel,email_addresses  where email_addr_bean_rel.bean_id='".$conid."' AND  email_addr_bean_rel.email_address_id=email_addresses.id and email_addresses.deleted=0 AND email_addr_bean_rel.deleted=0";
               $resem = $db->query($sqlem);
                   $rowem = $resem->fetch_assoc(); 
                    $emailidq = $rowem['email_address'];
 
                                $mail->AddAddress($emailidq); 

 
                                 @$mail->Send();  

}
else
{
	echo "not update";
}
   
  
?>