<?php
if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');

class Recordid {
	function funRecordid($bean, $event, $arguments) {

		$id=$bean->id;

		global $db;

		$sql="update contacts_cstm set fyn_id_c='".$id."' where id_c='".$id."' ";
		$db->query($sql);

		

		// $bean->fyn_id_c = $id;

		// $bean->save();


	}
}

?>