<?php

/**
 * The file used to add custom portal logic for portal.
 *
 * LICENSE: The contents of this file are subject to the license agreement ("License") which is included
 * in the installation package (LICENSE.txt). By installing or using this file, you have unconditionally
 * agreed to the terms and conditions of the License, and you may not use this file except in compliance
 * with the License.
 *
 * @author     Biztech Consultancy
 */
class custom_Portallogic {

   
    function includeJSFile($bean, $event) {
       
        global $sugar_version, $current_user;
        // check sugar version and include js file if required
        // $re_sugar_version = '/(6\.4\.[0-9])/';
        // if (preg_match($re_sugar_version, $sugar_version)) {
        //     echo '<script type="text/javascript" src="custom/biz/js/jquery/jquery-1.11.0.min.js"></script>';
        // }
        // if ($_REQUEST['action'] == 'EditView') {
        //     echo "<script type='text/javascript' src='custom/modules/Contacts/js/portal_custom.js'></script>";
        // }
        // $current_theme = $current_user->getPreference('user_theme');
        // echo "<div><input type='hidden' id='current_theme' name='current_theme' value='{$current_theme}'></div>";
        // echo "<script type='text/javascript' src='custom/biz/js/check_validation.js'></script>";
        // echo "<script type='text/javascript'>
        //          $(document).ready(function(){
        //             alert('');
        //          var beanID = $('input[name=record]').val();
        //          var userNameVal = $('#fyn_username_c').val();
                    
        //                 $('#fyn_username_c').prop('readonly','readonly');
        //                 $('#fyn_password_c').val('saif7');
        //                 $('#fyn_enable_portal_c').prop('readonly','readonly');
        //                 $('#SAVE').trigger('click');


        //         });
        //         </script>";

  
                     if ($GLOBALS['action'] == 'detail' || $GLOBALS['action'] == 'DetailView') 
                     {
?>
               <script type='text/javascript'>
                 $(document).ready(function(){
        
                   $('#fyn_id_c').attr('readonly',true);

                  var id=  $('#fyn_id_c').text();
                  var name=  $('#fyn_username_c').text();
            
                  if(id!="" && name!="")
                  {
                    
                    $.ajax({ 
                    url: 'validate.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {id: id,name:name},
                    success:function(response)
                    {
                        if(response==0)
                        {
                            //$('#fyn_id_c').val();
                        }

                        else
                        {
                            alert('Username already exist! Please Re-enter Username and Password.');
                            window.location.reload(true);
                        }


                    }

                    });//end of ajax

                  } // end if



                 });


              </script>

<?php


                       } // end if


// Editview



                     if ($GLOBALS['action'] == 'edit' || $GLOBALS['action'] == 'EditView') 
                     {
?>
               <script type='text/javascript'>
                 $(document).ready(function(){
        
                  //  $('#fyn_id_c').attr('readonly',true);
                   $('#fyn_username_c').attr('readonly',true);
    $('#fyn_password_c').attr('readonly',true);
    $('#fyn_id_c').hide();
                $('#fyn_enable_portal_c').on("click",function(){
              
                       var em=$('#Contacts0emailAddress0').val();
                       var finame=$('#first_name').val();
                         var laname=$('#last_name').val();
                          // var id="<?php echo $bean->id;?>";
                         id = $('input[name=record]').val();
                          var fyn_username_c = $('#fyn_username_c').val();
                         console.log(id+"ji");
                          if(fyn_username_c==""){

$.ajax({
url:"val.php",   
method:"POST",
data:{em:em,finame:finame,laname:laname,id:id},
success:function(data){
alert(data);
// $(".submit-btn").html("Accepted"); 
$("#user").html('User Created Sucessfully');
location.reload();
}
});

                          }

                });
                  var id=  $('#fyn_id_c').val();
                  var name=  $('#fyn_username_c').val();
            
                  if(id!="" && name!="")
                  {
                    
                    $.ajax({ 
                    url: 'validate.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {id: id,name:name},
                    success:function(response)
                    {
                        if(response==0)
                        {
                            $('#fyn_id_c').attr('readonly',true);
                            $('#fyn_username_c').attr('readonly',true);
                        }

                        else
                        {
                            alert('Username already exist! Please re enter User data.')
                        }


                    }

                    });//end of ajax

                  } // end if



                 });


              </script>

<?php


                       } // end if



    }

}