<?php

define('sugarEntry', TRUE); 
ini_set('max_execution_time', 0);
ini_set('memory_limit', '-1');
error_reporting(E_ALL); 
ini_set('display_errors', 1);
require_once('include/entryPoint.php');
global $db;

$id=$_REQUEST['id'];
$name=$_REQUEST['name'];
$check=0;


$sql="select * from contacts c,contacts_cstm cstm where cstm.fyn_username_c ='".$name."' and c.id=cstm.id_c and c.deleted=0 ";
$res=$db->query($sql);

if($res->num_rows > 1)
{

   $sql1="update contacts_cstm set fyn_username_c= '' , fyn_password_c='' where id_c='".$id."' ";
   $db->query($sql1);
   $check=1;

}




 echo $check;

// echo json_encode($id."name".$name);








?>