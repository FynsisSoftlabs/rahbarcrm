<?php

    $mod_strings['LBL_LINK_USER'] = 'Select Users';
    $mod_strings['LBL_LINK_USER_DESCRIPTION'] = 'Select Users';

    $mod_strings['LBL_LINK_MODULES'] = 'Select Modules';
    $mod_strings['LBL_LINK_MODULES_DESCRIPTION'] = 'Select Modules';

    $mod_strings['LBL_LINK_VIEWS'] = 'Select Mobile Views and Search Fields';
    $mod_strings['LBL_LINK_VIEWS_DESCRIPTION'] = 'Select Views and Search Fields';


    $mod_strings['LBL_SECTION_HEADER'] = 'Fynsis Customer Portal Settings';
    $mod_strings['LBL_SECTION_DESCRIPTION'] = 'Portal Configurations';