<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings['LBL_FYN_ID'] = 'Fyn ID';
$mod_strings['LBL_FYN_USERNAME'] = 'Fyn Username';
$mod_strings['LBL_FYN_PASSWORD'] = 'Fyn Password';
$mod_strings['LBL_FYN_ENABLE_PORTAL'] = 'Fyn Enable Portal';
$mod_strings['LBL_SUGARCHIMP'] = 'User Info';
$mod_strings['LBL_FYN_FORGOT_PASSWORD'] = 'Forgot Password';
