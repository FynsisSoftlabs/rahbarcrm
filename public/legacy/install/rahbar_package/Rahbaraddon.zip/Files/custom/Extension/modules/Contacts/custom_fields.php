<?php
// if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
// $dictionary["Contact"]["fields"]['fyn_enable_portal_c'] = array(
// 	'name' => 'fyn_enable_portal_c',
// 	'vname' => 'LBL_FYN_ENABLE_PORTAL',
// 	'type' => 'bool',
// 	'len' => 50,
// 	//'default' => '0',
// );
// $dictionary["Contact"]["fields"]['fyn_username_c'] = array(
// 	'name' => 'fyn_username_c',
// 	'vname' => 'LBL_FYN_USERNAME',
// 	'type' => 'varchar',
// 	'len' => 255,
// );
// $dictionary["Contact"]["fields"]['fyn_password_c'] = array(
// 	'name' => 'fyn_password_c',
// 	'vname' => 'LBL_FYN_PASSWORD',
// 	'type' => 'varchar',
// 	'len' => 255,
// );
