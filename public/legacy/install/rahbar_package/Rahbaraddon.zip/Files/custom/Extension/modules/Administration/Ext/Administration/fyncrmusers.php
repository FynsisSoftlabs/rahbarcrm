<?php

$freeswitch_integration_admin_option_defs = array();

    $admin_option_defs = array();

    $admin_option_defs['Administration']['CustomerPortal'] = array('Administration', 'Customer Portal Configration', 'Configure your Customer Portal ', './index.php?module=Administration&action=fyncrmappcustomportal',);
    $admin_option_defs['Administration']['mobile_modules'] = array('Administration', 'LBL_LINK_MODULES', 'LBL_LINK_MODULES_DESCRIPTION', './index.php?module=Administration&action=fyncrmappmodules',);    
    $admin_option_defs['Administration']['mobile_views'] = array('Administration', 'LBL_LINK_VIEWS', 'LBL_LINK_VIEWS_DESCRIPTION', './index.php?module=Administration&action=fyncrmappviews',);
    $admin_group_header[] = array('LBL_SECTION_HEADER', '', false, $admin_option_defs,  'LBL_SECTION_DESCRIPTION');
?>