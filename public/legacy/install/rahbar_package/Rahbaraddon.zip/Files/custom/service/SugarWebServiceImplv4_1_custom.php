<?php

    if(!defined('sugarEntry'))define('sugarEntry', true);

    
    require_once('service/v4_1/SugarWebServiceImplv4_1.php');

    class SugarWebServiceImplv4_1_custom extends SugarWebServiceImplv4_1
    {
        /*
         * Returns the session id if authenticated
         *
         * @param string $session
         * @return string $session - false if invalid.
         *
         */
        function SugarRestService($session)
        {
            global $sugar_config;

        $GLOBALS['log']->info('Begin: FynsisWebServiceImpl->getModulesAndFields');
        global $app_list_strings,$current_user;
            $GLOBALS['log']->info('Begin: SugarWebServiceImplv4_1_custom->SugarRestService');
            $error = new SoapError();

            //authenticate
            if (!self::$helperObject->checkSessionAndModuleAccess($session, 'invalid_session', '', '', '',  $error))
            {
                $GLOBALS['log']->info('End: SugarWebServiceImplv4_1_custom->SugarRestService.');
                return false;
            }


//begin
//session_id($session);
        //session_start();
        $modules = array();
        $availModules = array_keys($_SESSION['avail_modules']);
        $modules = self::$helperObject->get_visible_modules($availModules);

        $items = array();
        $resusers = array();
         $resmod = explode(",",$sugar_config['mobile_users_modules']);
         $resusers = explode(",",$sugar_config['mobile_users']);
        // print_r(json_encode($resusers));
        // foreach($resusers as $key)
         {
             //echo $key;
             //json_encode($key);
         }
        
        foreach($modules as $module)
        {

            if(in_array($module["module_key"],$resmod))
            // || $module["module_key"] == "Leads" || $module["module_key"] == "Contacts" || $module["module_key"] == "Opportunities")
            {
                $mod=$module["module_key"];
                $item = array();
                $module_views = array();

                $item["name"] = $module["module_key"];
                $item["label"] = $module["module_label"];
                 $res = explode(",",$sugar_config['mobile_detailview_fields'][$mod]);
                 $res_listviewfields = explode(",",$sugar_config['mobile_listview_fields'][$mod]);
                 $res_searchviewfields = explode(",",$sugar_config['mobile_searchview_fields'][$mod]);


                $fields = self::get_module_fields($session, $module["module_key"]);
             
                $Userslang = $sugar_config['mobile_users_lang'];
               
                if($Userslang == "")
                {
                     $cfg = new Configurator();
                    $cfg->config['mobile_users_lang'] ='en_us';
                    $cfg->saveConfig();
                    $Userslang='en_us.lang.php';
                }

                else
                {
                     $Userslang.=".lang.php";
                //Get language array
                require_once('modules/'.$module["module_key"].'/language/'.$Userslang);
                $mod_lang = $mod_strings;
                unset($mod_strings);
                if(file_exists('custom/modules/'.$module["module_key"].'/language/'.$Userslang)){

                    require_once('custom/modules/'.$module["module_key"].'/language/'.$Userslang);
                    $custom_lang = $mod_strings;
                    unset($mod_strings);
                    $lang_strings = array_merge($mod_lang,$custom_lang);
                    
                }else{

                    $lang_strings = $mod_lang;

                }
            }

                if(file_exists('custom/modules/'.$module["module_key"].'/metadata/SearchFields.php')){

                    require_once('custom/modules/'.$module["module_key"].'/metadata/SearchFields.php');
                    
                
                }else{

                    require_once('modules/'.$module["module_key"].'/metadata/SearchFields.php');

                }

                 if(file_exists('custom/modules/'.$module["module_key"].'/metadata/searchdefs.php')){

                    require_once('custom/modules/'.$module["module_key"].'/metadata/searchdefs.php');
                                    
                }else{

                    require_once('modules/'.$module["module_key"].'/metadata/searchdefs.php');

                }


                $module_views["Edit"] = self::$helperObject->get_module_view_defs($module["module_key"], 'default', 'edit');
                $module_views["Detail"] = self::$helperObject->get_module_view_defs($module["module_key"], 'default', 'detail');
                $module_views["List"] = self::$helperObject->get_module_view_defs($module["module_key"], 'default', 'list');
                 
                $module_views["cstm_list"]= array_filter($res_listviewfields);
                $module_views["cstm_search"]= array_filter($res_searchviewfields);

                 foreach ($fields['module_fields'] as $key => $value)
                  {
                     # code...
                    if(in_array($key, $res))
                    {

                    }
                    else
                    {
                        unset($fields['module_fields'][$key]);
                    }
                    $GLOBALS['log']->fatal(saddunewkey2222.print_r($key,true));
        
                 }
                // $GLOBALS['log']->fatal(saddunew2222.print_r($fields,true));
                $item["fields"] = $fields;
                $item["views"] = $module_views;
                $item["SearchFields"] = $searchFields[$module["module_key"]];
                $item["SearchDefs"] = $searchdefs[$module["module_key"]];
                $item["Language"] = $lang_strings;
                $item["license"] =  $sugar_config['portal_license'];
                
                $items[] = $item;

                unset($item);
                unset($lang_strings);
                unset($module_views);
                unset($searchFields);
                unset($searchdefs);
                unset($fields);

            }


        }

        $outputList = array();
        $outputList["modules_and_fields"] =  $items;
        $outputList["modules_count"] = count($items);
        $outputList["cstm_users"] = array_filter($resusers);
        return json_encode($outputList);

        $fields = self::get_module_fields($session, 'Accounts');
        //$modules = self::$helperObject->get_user_module_list($current_user);
        //return json_encode($app_list_strings["moduleList"]);
        $viewdefs = self::$helperObject->get_module_view_defs('Accounts', 'default', 'edit');
        global $mod_strings;
        global  $beanList, $beanFiles;
        global $sugar_config,$current_language;
        
        return json_encode($viewdefs["panels"]);

        require_once('modules/Accounts/language/en_us.lang.php');
        $mod_lang = $mod_strings;
        unset($mod_strings);

        require_once('custom/modules/Accounts/language/en_us.lang.php');
        //$mod_strings = return_module_language($current_language, 'Accounts');
        $custom_lang = $mod_strings;

        unset($mod_strings);
        $lang_strings = array_merge($mod_lang,$custom_lang);

        return json_encode($lang_strings);
        $contact_fields = array();

        $contact_fields[0] = array('name' => 'first_name','type' => 'TextField', 'label' => 'First Name',"max_size" => 100, "required" => "no");
        $contact_fields[1] = array('name' => 'last_name','type' => 'TextField', 'label' => 'Last Name',"max_size" => 100, "required" => "yes");
        $contact_fields[2] = array('name' => 'phone_home','type' => 'Phone', 'label' => 'Home Phone',"max_size" => 100, "required" => "no");
        $contact_fields[3] = array('name' => 'phone_mobile','type' => 'Phone', 'label' => 'Mobile',"max_size" => 100, "required" => "no");

        $contact_views = array();

        $contact_dv_p1_rows = array();
        $contact_dv_p1_rows[0] = array("1" => "first_name");
        $contact_dv_p1_rows[1] = array("1" => "last_name");

        $contact_dv_p2_rows = array();
        $contact_dv_p2_rows[0] = array("1" => "phone_home", "2" => "phone_mobile");


        $contact_detailview_panels = array();
        $contact_detailview_panels[0] = array('name' => 'Overview' , 'rows' => $contact_dv_p1_rows);
        $contact_detailview_panels[1] = array('name' => 'More Information' , 'rows' => $contact_dv_p2_rows);

        $contact_views["DetailView"] = $contact_detailview_panels;
        $contact_views["EditView"] = array();
        $contact_views["ListView"] = array();
        $contact_views["BasicSearch"] = array();
        $contact_views["AdvancedSearch"] = array();

        

        $outputList = array();
        $modules_count = count($modules);

        $items = array();

        foreach($modules as $module)
        {
            if($module["module_key"] == "Home")
                continue;

            $item = array();
            $item["name"] = $module["module_key"];
            $item["label"] = $module["module_label"];
            $item["fields"] = $contact_fields;
            $item["views"] = $contact_views;
            $items[] = $item;
            unset($item);
        }

        //$modules = array();
        //$modules[0] = array("name" => "Contacts", "display_name" => "Contacts" , 'fields' => $contact_fields, 'views' => $contact_views);
        //$modules[1] = array("name" => "Accounts", "display_name" => "Accounts" , 'fields' => $contact_fields, 'views' => $contact_views);

      // $users = $resusers;

        $outputList["modules_and_fields"] =  $items;
        $outputList["modules_count"] = count($items);


        

        $GLOBALS['log']->info('End:  FynsisWebServiceImpl->getModulesAndFields');

        return json_encode($outputList);

//end















          //  return $session;
        }
    }

?>