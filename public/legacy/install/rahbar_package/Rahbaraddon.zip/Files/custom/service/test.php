<?php

   // $url = "http://localhost/crm78/custom/service/fynsis_rest.php";
   // $username = "admin";
  //  $password = "admin123";

    //function to make cURL request

global $sugar_config;
$username=$_REQUEST['username'];
$password =$_REQUEST['password'];
$urll=$_REQUEST['url'];

//$serviceUrl = 'http://localhost/mobilecrm/custom/service/fynsis_rest.php';
$serviceUrl1 = 'https://'.$urll.'/custom/service/fynsis_rest.php';
$serviceUrl2 = 'http://'.$urll.'/custom/service/fynsis_rest.php';
    function call($method, $parameters, $url)
    {
        ob_start();
        $curl_request = curl_init();

        curl_setopt($curl_request, CURLOPT_URL, $url);
        curl_setopt($curl_request, CURLOPT_POST, 1);
        curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        curl_setopt($curl_request, CURLOPT_HEADER, 1);
        curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);

        $jsonEncodedData = json_encode($parameters);

        $post = array(
             "method" => $method,
             "input_type" => "JSON",
             "response_type" => "JSON",
             "rest_data" => $jsonEncodedData
        );

        curl_setopt($curl_request, CURLOPT_POSTFIELDS, $post);
        $result = curl_exec($curl_request);
        curl_close($curl_request);

        $result = explode("\r\n\r\n", $result, 2);
        $response = json_decode($result[1]);
        ob_end_flush();

        return $response;
    }

    //login ------------------------------ 
    $login_parameters = array(
         "user_auth" => array(
              "user_name" => $username,
              "password" => md5($password),
              "version" => "1"
         ),
         "application_name" => "RestTest",
         "name_value_list" => array(),
    );

    $login_result = call("login", $login_parameters, $serviceUrl1);
    //print_r($login_result->id);
    if($login_result->id == ""){
        // echo "<pre>";
    //print_r($login_result);
   // echo "</pre>";

    //get session id
    $login_result = call("login", $login_parameters, $serviceUrl2);
    $session_id = $login_result->id;
    //echo "saddu testing from custom =>  ".$session_id;
    $login_result_call = call("SugarRestService", $session_id, $serviceUrl2);
    print_r($login_result_call);        
    }
    else
    {
      $session_id = $login_result->id;
    //echo "saddu testing from custom =>  ".$session_id;
    $login_result_call = call("SugarRestService", $session_id, $serviceUrl1);
    print_r($login_result_call);
}
?>