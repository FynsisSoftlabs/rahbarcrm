<?php
/**
**************	PLEASE DO NOT DELETE THIS FILE **********
	This file is written by http://specscale.com - a sugarcrm and suitecrm pluin developer company.

	Please contact us if you need more support : skype id : live:specscale 
* 		log user
*/
class LicenseValidate1
{
    function afterLogout($bean, $events, $args)
    {

        //$GLOBALS['log']->fatal('After login function');
        global $sugar_config;
        global $current_user;

      // print_r($current_user->id);exit; 

        require_once('modules/FynsisCustomerPortal/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('FynsisCustomerPortal',$current_user->id);
        if($validate_license !== true) 
        {
            // echo '< h2>< p class="error">FynsisCustomerPortal is no longer active</p></h2>< p class="error">'.$validate_license.'</p>';

    //functionality may be altered here in response to the key failing to validate
          // echo "License Expired";

           
                    $cfg = new Configurator();
                    $cfg->config['portal_license'] ='1';
                    $cfg->saveConfig();
               
                
            // return ("License Expired.");
        }
        else
        {
                    $cfg = new Configurator();
                    $cfg->config['portal_license'] ='0';
                    $cfg->saveConfig();
        }
    }

}