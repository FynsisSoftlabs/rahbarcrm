<?php
// Program to display URL of current page.
//echo "<pre>";
//print_r($_SERVER);
//exit;
//if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
//  $link = "https";
//else
//  $link = "http";

$link = $_SERVER['HTTP_X_FORWARDED_PROTO'];

// Here append the common URL characters.
$link .= "://";

// Append the host(domain name, ip) to the URL.
$link .= $_SERVER['HTTP_HOST'];

// Append the requested resource location to the URL
$link .= $_SERVER['REQUEST_URI'];

$string = $link;

$splitter = 'index';

$pieces = explode($splitter, $string);

$myurl = $pieces[0];

// $encodeddata = json_encode($pieces[0]);

define('sugarEntry', TRUE);
ini_set('max_execution_time', 0);
error_reporting(E_ERROR);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
include_once('include/entryPoint.php');
require_once('data/BeanFactory.php');
require_once('include/entryPoint.php');
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once 'modules/Emails/Email.php';
require_once 'include/SugarPHPMailer.php';

global $db;

$sq1w = "CREATE TABLE fynportalcon (crmname varchar(255),crmpass varchar(255),portallink varchar(255),crmcompany varchar(255));";
$resw = $db->query($sq1w);

if ($resw) {
  // echo "created";

} else {
  // echo "not created";
}


      $sql12 = "SELECT * FROM `fynportalcon`";
      $res12 = $db->query($sql12);
      $row12 = $res12->fetch_assoc(); 
      $portallink = $row12['portallink'];

      if($portallink=='')
      {

      $sql1 = "INSERT INTO fynportalcon(portallink)VALUES ('1')";

      if ($db->query($sql1) === TRUE) {
          echo "New record created successfully";
      } else {
          echo "Error: " . $sql1 . "<br>" . $db->error;
      }

      }

?>
<!DOCTYPE html>
<html>
<link href="css/bootstrap.css" rel="stylesheet" />

<script src="js/bootstrap.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>

<head>
</head>

<style>
  #colorlabel {
    position: absolute;
    margin-left: -700px;
    margin-top: 10px;
  }

  input[type=text],
  select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    border-radius: 25px;
  }

    input[type=password],
  select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    border-radius: 25px;
  }



  form {
    border-radius: 50px 20px;
    background-color: #f2f2f2;
    padding: 20px;
    float: left;
    width: 70%;
    height: 330px;

  }

  div.c {
    font-size: 110%;
    border-radius: 50px 20px;

  }
</style>

<body style="position: relative;">
  <img id="loading-image" src="https://media.giphy.com/media/y1ZBcOGOOtlpC/200.gif" style="margin-left: 25%; position:absolute;top:400px;z-index: 10;opacity: 0.5;display: none;">
  <div style="position:relative;">
    <div id="divFirst">
      <!--input type  ="submit" class="button" value="Save" name="save" -->
      <input type="button" class="button" value="Cancel" onclick="history.go(-1);">
      <input type="button" class="button" value="Admin" onclick="location.href ='index.php?module=Administration&action=index'"> <br /> <br />
      <h4><b>Set Default Language for all your Mobile Users</b></h4>
    </div>
    <!-- <div style="position:relative;border:1px solid #000; padding: 20px;"> -->
    <div class="container" style="border-right:1px solid #ccc;position:relative;border:1px solid #000; padding: 20px;background-color: #FDFEFE; height:800px;">
      <ul class="nav nav-tabs" role="tablist">

        <!--  <li class=""><a  href="index.php?module=Administration&action=fyncrmappusers">Users</a>
      </li> -->
        <li class="">
          <a href="index.php?module=Administration&action=fyncrmappmodules">Modules</a>
        </li>
        <li><a href="index.php?module=Administration&action=fyncrmappviews">Detail Fields </a>
        </li>
        <li class="">
          <a href="index.php?module=Administration&action=fyncrmapplistview">List Fields</a>
        </li>
        <!--  <li><a href="index.php?module=Administration&action=fyncrmappsearchview">Search Fields</a>
      </li> -->
        <li class="active">
          <a href="index.php?module=Administration&action=fyncrmappcustomportal">custom portal</a>
        </li>

      <!--   <li class=""><a href="index.php?module=Administration&action=fyncrmapplang">Select Language</a>
        </li> -->
      </ul>
      <br>


      <div class="alert" style="background-image: linear-gradient( 135deg, #f1746d 90%, #360940 100%); color:beige; width:70%; border-radius:20px;">
            For security reason the default CRM package will restrict certain modules and fields but that is not the show stopper. We can enable even those if you inform.<br><br>
            <strong>Reach them at: sales@fynsis.com.</strong>
          </div>

          <!-- <div class="alert" >
            <strong>Hello Admin,</strong><br><br>You can configer the fyn custom portal here<br><br>
          </div> -->

      <h4><b>CUSTOM PORTAL CONFIGRATION :</b></h4>
      <form style="height:560px;" onsubmit="configurePortal()" id="configuration" method="post" enctype="multipart/form-data">

        <div class="c">
          

          <label for="fname">CRM User Name</label>

          <input type="text" id="crmname" name="crmname" placeholder="YOUR  CRM USER NAME..." value="<?php echo $row12['crmname'];?>"  required>
          

          <label for="crmpas">CRM Password</label>
          <input type="password" id="crmpas" name="crmpas" placeholder="YOUR CRM PASSWORD.." value="<?php echo $row12['crmpass'];?>"  required>

          <label for="custom">Custom Portal URL</label>
          <input type="text" id="custom" name="custom" placeholder="YOUR custom portal URL.." value="<?php echo $row12['portallink'];?>" required>

          <input type="hidden" id="crm_url" name="crm_url" value="<?php echo $myurl; ?>">

          <label for="companyname">Company Name</label>
          <input type="text" id="companyname" name="companyname" placeholder="YOUR company name" value="<?php echo $row12['crmcompany'];?>"  required>

          <label for="logo">Logo</label>
          <input type="file" id="fileToUpload" name="fileToUpload" required>

          <br>

          <label for="color">Color</label>
          <select id='color' name='color' required>
            <option value='red' selected="selected">red</option>
            <option value='green'>green</option>
            <option value='blue'>blue</option>
            <option value='pink'>pink</option>
          </select>
          <label for="color" id="colorlabel">red</label>
          <!-- <input type="submit" style="border-radius: 25px;" value="save">  -->
          <div>
            <input id="submit" name="submit" type="submit" class="button" style="border-radius: 25px;" value="Save">
            <input type="button" class="button" style="border-radius: 25px;" value="Cancel" onclick="history.go(-1);">
          </div>
      </form>

    </div>
  </div>
  <footer>
    <script>
      function configurePortal() {
 
 var cust = document.getElementById("custom").value;

           var crmusername = $('#crmname').val();
          var crmuserpass = $('#crmpas').val();
          var companyname = $('#companyname').val();

 //alert(cust);
  $.ajax({
   url:"conec1.php",   
   method:"POST",
   data:{cust:cust,crmusername:crmusername,crmuserpass:crmuserpass,companyname:companyname},
   success:function(data){
  // alert(data);
   }
  });

        var portal_url = document.getElementById("custom").value + '/portal_configuration.php';
        var config_form = document.getElementById('configuration');
        config_form.action = portal_url;
      }
      $(document).ready(function() {
        $('#color').on('change', function() {
          $('#colorlabel').html($('#color').val());
        });

        $('#save').on("click", function() {
          //  console.log('hi');
          // Program to display URL of current page.

          // document.getElementById("demo").innerHTML = "<?php $link ?>";
          var crmusername = $('#crmname').val();
          var crmuserpass = $('#crmpas').val();
          var companyname = $('#companyname').val();
          var color = $('#color').val();
          var crmuserurl = '<?php echo $myurl; ?>';
          //var crmuserurl = $('#crmurl').val();
          //console.log(crmuserurl);
          var portalurl = $('#custom').val();
          var logo = $('#logo').val();
          //var lastchar = crmuserurl.substr(0,1);
          //         var str1 = crmuserurl;
          // var str2 = "/";
          // var res = str1.concat(str2);
          //   console.log('crmuserurl');

          $.ajax({
            url: portalurl + "/test1.php",
            data: {
              crmname: crmusername,
              crmpas: crmuserpass,
              crmurl: crmuserurl,
              custom: portalurl,
              companyname: companyname,
              color: color,
              logo: logo
            },
            type: "POST",
            beforeSend: function() {
              $("#loading-image").show();
            },
            // success: function(msg) {
            //    $("#"+div_id).html(divIdHtml + msg);
            //    $("#loading-image").hide();
            // }
            success: function(response) {
              $('#loading-image').hide();
              // you will get response from your php page (what you echo or print)
              alert(response);
            },
            error: function(jqXHR, textStatus, errorThrown) {
              alert(textStatus + " Try with http or https or without http and https");
              $('#loading-image').hide();
            }
          });


        });
      });
    </script>
  </footer>

</body>

</html>