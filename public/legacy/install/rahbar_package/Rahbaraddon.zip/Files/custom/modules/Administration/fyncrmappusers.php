<!DOCTYPE html>
<html>
<link href="css/bootstrap.css" rel="stylesheet" />
<script src="js/bootstrap.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<?php
require_once('modules/Users/User.php');
require_once ('modules/Configurator/Configurator.php');
global $sugar_config;
global $user;
global $app_language;
global $current_language, $mod_strings, $app_strings;

$resUsers = explode(",",$sugar_config['mobile_users']);
//$Userslang = $sugar_config['mobile_users_lang'];


//$the_languages = get_languages();
//print_r($the_languages);


?>
<head> 
</head>
<style type="text/css">
    table thead tr
    {
       display:block; 

    }
    table th
    {
        width: 250px;
        border-style: solid;
        border-width: 1px;
        display:block;
        height: 25px;
        font-size: 14px;
    }
   table  tbody
    {
      display:block;
      height:400px;
      border-style: solid;
      overflow:auto;//set tbody to auto
      font-size: 14px;
      border-collapse:separate;
      border-spacing:0.5px;
   }

   
    #table9 
    {
       
    }
 
    #table10 
    {
       
    }
     #divLast
    {
      margin-top: 0.5cm;
      clear: both;
    }

table {display:inline;float:left;}

​
</style>


<body >
<div style="position:relative;">
<div id="divFirst">
  <input type="button" class="button" value="Save" onclick=save();>
  <input type="button" class="button" value="Cancel" onclick="history.go(-1);">
  <input type="button" class="button" value="Admin" onclick="location.href ='index.php?module=Administration&action=index'">  <br/> <br/>
  
  
</div>
<div class="container" style="border-right:1px solid #ccc;position:relative;border:1px solid #000; padding: 20px;background-color: #FDFEFE;">
<div>
  <ul class="nav nav-tabs" role="tablist">
     
     <!--  <li class="active"><a  href="index.php?module=Administration&action=fyncrmappusers">Users</a>
      </li> -->
      <li class="">
        <a  href="index.php?module=Administration&action=fyncrmappmodules">Modules</a>
      </li>
      <li class=""><a href="index.php?module=Administration&action=fyncrmappviews">Detail Fields </a>
      </li>
      <li class="">
        <a  href="index.php?module=Administration&action=fyncrmapplistview" >List Fields</a>
      </li>
      <!--  <li><a href="index.php?module=Administration&action=fyncrmappsearchview">Search Fields</a>
      </li> -->
         <li class="">
        <a  href="index.php?module=Administration&action=fyncrmappcustomportal" >custom portal</a>
      </li>
       </li>
       <li><a href="index.php?module=Administration&action=fyncrmapplang">Select Language</a>
      </li>
      </ul>



</td>
</tr>
</div>

<br>
<br>
<br>
<br>
<h4><b>Select Users</b></h4> 
<div align="left">
<div class="table-responsive col-md-3">
<table id='table9'>
         <thead>
                 <tr>
                      <th bgcolor="#D3D3D3">Active Users</th>            
                 </tr>
         </thead>

      <tbody class="connectedSortable">
       
 <?php
     foreach ($resUsers as $value) 
     {
       # code...
       echo '<tr>
         <td style="border:1px solid #000;width: 242px;cursor:pointer">';
         echo $value;
         echo '</td>
         </tr>';

     }

     ?>
             

      </tbody>
 
   
</table>
</div>
<div class="table-responsive col-md-3.5">
<table id='table10'>
    <thead>
        <tr>
            <th bgcolor="#D3D3D3">Inactive Users</th>            
        </tr>
    </thead>
    <tbody class="connectedSortable" >
    <?php
     $ContactBean = new User();
     $ListOfContactBeans=$ContactBean->get_full_list("", "", true);
     /* foreach($ListOfContactBeans as $SingleContactBean)
      {
       echo $SingleContactBean->user_name."  ";
      }*/
     foreach ($ListOfContactBeans as $SingleContactBean) 
     {


      if(in_array($SingleContactBean->user_name, $resUsers))
         {
             
         }

       else
       { 
         echo '<tr>
         <td style="border:1px solid #000;width: 242px;cursor:pointer">';
         echo $SingleContactBean->user_name;
         echo '</td>
         </tr>';
       }
       # code...
      

     }

     ?>
     
</tbody>
 
   
</table>
</div>
</div>

<div id="divLast">
<input type="button" class="button" value="Save" onclick=save();>
<input type="button" class="button" value="Cancel" onclick="history.go(-1);">
</div>
</div>

</body>

<script type="text/javascript">
//alert('salam');


    var $tabs1 = $('#table9')
$("tbody.connectedSortable")
    .sortable({
        connectWith: ".connectedSortable",
        
        appendTo: $tabs1,
        helper: "clone",
        zIndex: 999990
    })
    .disableSelection();

var $tab_items1 = $(".nav-tabs > li", $tabs1).droppable({
    accept: ".connectedSortable tr",
    hoverClass: "ui-state-hover",
    drop: function (event, ui) {
        return false;
    }
});

var $tabs2 = $('#table10')
$("tbody.connectedSortable")
    .sortable({
        connectWith: ".connectedSortable",        
        appendTo: $tabs2,
        helper: "clone",
        zIndex: 999990
    })
    .disableSelection();

var $tab_items2 = $(".nav-tabs > li", $tabs2).droppable({
    accept: ".connectedSortable tr",
    hoverClass: "ui-state-hover",
    drop: function (event, ui) {
        return false;
    }
});
function save() 
{
 // alert('salam from button');
 
var userlang=$("#lang").val();
 

var tab9 = document.getElementById('table9');
  var users = [];
        for (var r = 0, n = tab9.rows.length; r < n; r++) 
        {
            for (var c = 0, m = tab9.rows[r].cells.length; c < m; c++) 
            {
               // alert(table.rows[r].cells[c].innerHTML);
               
               
              // arr = arr + table.rows[r].cells[c].innerHTML;
              users[r]=tab9.rows[r].cells[c].innerHTML;

             
            }
        }
      //  alert(users);
     $.ajax({
        type: 'POST',
        url: 'fyncrmusers.php',
       // dataType:'json',
        data: {
               users_list:users,
             },
        success: function(data)
        {      
           //window.location.reload();  
              history.go(0);                
        }
    });






}

</script>
</html>
