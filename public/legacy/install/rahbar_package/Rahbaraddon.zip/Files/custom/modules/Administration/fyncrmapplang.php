
<!DOCTYPE html>
<html>
<link href="css/bootstrap.css" rel="stylesheet" />

<script src="js/bootstrap.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>

<head> 
</head>
<style type="text/css">
    table thead tr
    {
       display:block; 
    }
    table th
    {
        width: 250px;
        border-style: solid;
        border-width: 1px;
        display:block;
        height: 25px;
        font-size: 14px;
    }
   table  tbody
    {
      display:block;
      height:400px;
      border-style: solid;
      overflow:auto;//set tbody to auto
      font-size: 14px;
      border-collapse:separate;
      border-spacing:0.5px;
   }

    
     #table3 
    {
       
    }
 
    #table4 
    {
     
    }
     #table5 
    {
      
    }
 
    #table6 
    {
      
    }

    #table7 
    {
       
    }
 
    #table8 
    {
       
    }
   .marginRow{
   margin-bottom:0px !important; 
   }
    #div_details_fields_list
    {
      overflow-y: scroll; 
       clear: both;


    }

    #mod_dropdown
    {
     
     clear: both;
     padding-top: 0.5cm;
    }
     #div_details_fields_list
    {
      margin-top: 0.3cm;
 clear: both;
      
    }
    #div_list_fields_list
    {
       clear: both;
      padding-top: 0.3cm;

      
    }
    #div_search_fields_list
    {
       clear: both;
      padding-top: 0.3cm;

      
    }
             





     #divLast
    {
      margin-top: 0.5cm;
      clear: both;
    }
table {display:inline;float:left;}

​
</style>


<body>
<div style="position:relative;">
<div id="divFirst">
  <input type="submit" class="button" value="Save" name="save" >
  <input type="button" class="button" value="Cancel" onclick="history.go(-1);"> 
  <input type="button" class="button" value="Admin" onclick="location.href ='index.php?module=Administration&action=index'">  <br/> <br/>
  <h4><b>Set Default Language for all your Mobile Users</b></h4>
</div>
<!-- <div style="position:relative;border:1px solid #000; padding: 20px;"> -->
  <div class="container" style="border-right:1px solid #ccc;position:relative;border:1px solid #000; padding: 20px;background-color: #FDFEFE;">
<div>
  <ul class="nav nav-tabs" role="tablist">
     
     <!--  <li class=""><a  href="index.php?module=Administration&action=fyncrmappusers">Users</a>
      </li> -->
      <li class="">
        <a  href="index.php?module=Administration&action=fyncrmappmodules">Modules</a>
      </li>
      <li ><a href="index.php?module=Administration&action=fyncrmappviews">Detail Fields </a>
      </li>
      <li class="">
        <a  href="index.php?module=Administration&action=fyncrmapplistview" >List Fields</a>
      </li>
      <!--  <li><a href="index.php?module=Administration&action=fyncrmappsearchview">Search Fields</a>
      </li> -->
        <li class="">
        <a  href="index.php?module=Administration&action=fyncrmappcustomportal" >custom portal</a>
      </li>
       </li>
       <li class="active"><a href="index.php?module=Administration&action=fyncrmapplang">Select Language</a>
      </li>
    </ul>
<br>
<br>
<br>
 <!--  <input type="button" class="btn btn-primary active" value="Users" onclick="location.href = 'index.php?module=Administration&action=fyncrmappusers'">
  <input type="button" class="btn btn-primary active" value="Modules" onclick="location.href = 'index.php?module=Administration&action=fyncrmappmodules'">  
  <input type="button" class="btn btn-primary active" value="Detail Fields" onclick="location.href = 'index.php?module=Administration&action=fyncrmappviews'"> 
  <input type="button" class="btn btn-primary active" value="List Fields" onclick="location.href = 'index.php?module=Administration&action=fyncrmapplistview'">
  <input type="button" class="btn btn-primary active" value="Search Fields" onclick="location.href = 'index.php?module=Administration&action=fyncrmappsearchview'">
  <br/> -->

<div id="mod_dropdown" style="text-align: center;position: relative;margin-right: 350px;border-right:1px solid #ccc;position:relative;border:1px solid #000;">
  <form method="post">
<p><b>Select Language :</b></p>

<select id="select_mod_drop" name="lang" >
<option selected disabled hidden style='display: none' value=""></option>

<?php 

require_once('modules/Users/User.php');
global $sugar_config;
global $user;

   $Userslang = $sugar_config['mobile_users_lang'];



$the_languages = get_languages();

  foreach ($the_languages as $ke=>$valu)      
{

?>
<option <?php if ($Userslang == $ke && $Userslang!="" ) echo "selected" ; ?> value= <?php echo $ke; ?> > <?php echo $valu; ?>  </option>

<?php

}

?>
</select>
<br>
<br>


</div>

<div class="alert" style="padding: 20px;width:20%;position: absolute; clear:both;
    margin-bottom: 15px;background-color: #f44336;color: white;float: right;margin-top: -103px;margin-bottom: 50%;margin-right: -2%;margin-left: 800px;">
    Note : If you wish to enable different language for different users reach us at:<br>
    <strong>sales@fynsis.com.</strong>
</div>




<div id="divLast">
<input type="submit" class="button" value="Save" name="save" ;>
<input type="button" class="button" value="Cancel" onclick="history.go(-1);">
</div>
</div>

</form>
</body>


</html>



<?php

if(isset($_POST['save']))
{

define('sugarEntry', TRUE);
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('include/entryPoint.php');
require_once('modules/Configurator/Configurator.php');

$lang = $_POST['lang'];



$cfg = new Configurator();


$cfg->config['mobile_users_lang'] = $lang;
 
 
$cfg->saveConfig();

 

}

?>

