<!DOCTYPE html>
<html>
<link href="css/bootstrap.css" rel="stylesheet" />

<script src="js/bootstrap.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<?php
require_once('modules/Users/User.php');
global $sugar_config;
global $user;
$mod_disp_res = explode(",", $sugar_config['mobile_users_modules']);
//$disabled_array= array();
/*$hidden_array= array();
$enabled_array= array("id"=>"id","name"=>"name");*/
/*foreach ($app_list_strings['moduleList'] as $key => $value)
        {
            if(in_array($value, $enabled_array))
             {
                //don't do anything as its enabled.
             }
            else
             {

                $disabled_array[$key]=$value;
             }

        } */


?>

<head>
</head>
<style type="text/css">
  table thead tr {
    display: block;
  }

  table th {
    width: 250px;
    border-style: solid;
    border-width: 1px;
    display: block;
    height: 25px;
    font-size: 14px;
  }

  table tbody {
    display: block;
    height: 400px;
    border-style: solid;
    overflow: auto; //set tbody to auto
    font-size: 14px;
    border-collapse: separate;
    border-spacing: 0.5px;
  }


  #table3 {}

  #table4 {}

  #table5 {}

  #table6 {}

  #table7 {}

  #table8 {}

  .marginRow {
    margin-bottom: 0px !important;
  }

  #div_details_fields_list {
    overflow-y: scroll;
    clear: both;


  }

  #mod_dropdown {

    clear: both;
    padding-top: 0.5cm;
  }

  #div_details_fields_list {
    margin-top: 0.3cm;
    clear: both;

  }

  #div_list_fields_list {
    clear: both;
    padding-top: 0.3cm;


  }

  #div_search_fields_list {
    clear: both;
    padding-top: 0.3cm;


  }






  #divLast {
    margin-top: 0.5cm;
    clear: both;
  }

  table {
    display: inline;
    float: left;
  }

  ​
</style>


<body>
  <div style="position:relative;">
    <div id="divFirst">
      <input type="button" class="button" value="Save" onclick=save();>
      <input type="button" class="button" value="Cancel" onclick="history.go(-1);">
      <input type="button" class="button" value="Admin" onclick="location.href ='index.php?module=Administration&action=index'"> <br /> <br />

    </div>
    <!-- <div style="position:relative;border:1px solid #000; padding: 20px;"> -->
    <div class="container" style="border-right:1px solid #ccc;position:relative;border:1px solid #000; padding: 20px;background-color: #FDFEFE;">
      <div>
        <ul class="nav nav-tabs" role="tablist">
          <!--
      <li class=""><a  href="index.php?module=Administration&action=fyncrmappusers">Users</a>
      </li> -->
          <li class="">
            <a href="index.php?module=Administration&action=fyncrmappmodules">Modules</a>
          </li>
          <li class="active"><a href="index.php?module=Administration&action=fyncrmappviews">Detail Fields </a>
          </li>
          <li class="">
            <a href="index.php?module=Administration&action=fyncrmapplistview">List Fields</a>
          </li>
          <!--  <li><a href="index.php?module=Administration&action=fyncrmappsearchview">Search Fields</a>
      </li> -->
          <li class="">
            <a href="index.php?module=Administration&action=fyncrmappcustomportal">custom portal</a>
          </li>
          <!-- </li>
          <li><a href="index.php?module=Administration&action=fyncrmapplang">Select Language</a>
          </li> -->
        </ul>
        <br>
        <div class="alert" style="background-image: linear-gradient( 135deg, #f1746d 90%, #360940 100%); color:beige; width:70%; border-radius:20px;">
          For security reason the default CRM package will restrict certain modules and fields but that is not the show stopper. We can enable even those if you inform.<br><br>
          <strong>Reach them at: sales@fynsis.com.</strong>
        </div>

        <!--  <input type="button" class="btn btn-primary active" value="Users" onclick="location.href = 'index.php?module=Administration&action=fyncrmappusers'">
  <input type="button" class="btn btn-primary active" value="Modules" onclick="location.href = 'index.php?module=Administration&action=fyncrmappmodules'">
  <input type="button" class="btn btn-primary active" value="Detail Fields" onclick="location.href = 'index.php?module=Administration&action=fyncrmappviews'">
  <input type="button" class="btn btn-primary active" value="List Fields" onclick="location.href = 'index.php?module=Administration&action=fyncrmapplistview'">
  <input type="button" class="btn btn-primary active" value="Search Fields" onclick="location.href = 'index.php?module=Administration&action=fyncrmappsearchview'">
  <br/> -->
        <h4><b>Select Your Modules and Fields</b></h4>
        <div id="mod_dropdown" style="text-align: center;position: relative;margin-right: 350px;border-right:1px solid #ccc;position:relative;border:1px solid #000;">
          <form>
            <p><b>Please Select the Module :</b></p>

            <select id="select_mod_drop" onchange="changeField(); return false;">
              <option selected disabled hidden style='display: none' value=""></option>
              <?php

              foreach ($mod_disp_res as $category => $value) {
                echo '<option value="' . $value . '">' . $value . '</option>';
              }
              ?>
            </select>
            <br>
            <br>
          </form>
        </div>

        <div class="tab-content">
          <div id="div_details_fields_list" id="1">
            <p><b>Please Select the DetailView Fields :</b></p>
            <div class="table-responsive col-md-3 tab-pane">
              <table id='table3'>
                <thead>
                  <tr>
                    <th bgcolor="#D3D3D3">Displayed DetailView Fields</th>
                  </tr>
                </thead>

                <tbody class="connectedSortable" id="bodydetailFieldsleft">

                  <?php
                  /* foreach ($enabled_array as $key=>$value)
      if(in_array($key, $mod_disp_res))
     {
       # code...
        echo '<tr>
         <td>';
         echo $key;
         echo '</td>
         </tr>';

     }
*/
                  ?>

                </tbody>


              </table>
            </div>

            <div class="table-responsive col-md-3 tab-pane">
              <table id='table4'>
                <thead>
                  <tr>
                    <th bgcolor="#D3D3D3">Hidden DetailView Fields</th>
                  </tr>
                </thead>
                <tbody class="connectedSortable" id="bodydetailFieldsright">

                  <?php
                  /* require_once('service/v4_1/SugarWebServiceImplv4_1.php');
        //foreach ($app_list_strings['moduleList'] as $key => $value)
		foreach ($hidden_array as $key => $value)
        {
            if(in_array($key, $mod_disp_res))
             {

             }

            else
             {
                echo '<tr><td>';
                echo $key;
                echo '</td></tr>';
             }

        }*/
                  ?>

                </tbody>


              </table>
            </div>

            <div class="table-responsive col-md-3 tab-pane">
              <table id='distable'>
                <thead>
                  <tr>
                    <th bgcolor="#D3D3D3">Disable DetailView Fields</th>
                  </tr>
                </thead>

                <tbody class="" id="bodydetailFieldsdisable">


                </tbody>


              </table>
            </div>
          </div>
        </div>



        <div id="divLast">
          <input type="button" class="button" value="Save" onclick=save();>
          <input type="button" class="button" value="Cancel" onclick="history.go(-1);">
        </div>
      </div>


</body>

<script type="text/javascript">
  function changeField() {
    var mod_sel = document.getElementById("select_mod_drop").value;


    $.ajax({
      type: 'POST',
      url: 'fyncrmappfields.php',
      // dataType:'json',
      data: {
        dropmoduleName: mod_sel
      },
      success: function(data) {
        //alert('done');
        //alert(data);
        // window.location.reload();
        //alert(data);

        var json = $.parseJSON(data);
        //alert(json['result1']);
        //alert(json['result2']);
        // $('#b1').empty();
        //$("#table-draggable3").find("tr:not(:nth-child(1))").remove();
        // $("#table-draggable4").find("tr:not(:nth-child(1))").remove();

        //  $('#b1').append(json['result2']);
        //alert('done loading');
        //window.location.reload();
        var detail_fields_res = json['detailFields'];

        var items2 = json['result2'];
        var items3 = json['result3'];
        var items4 = json['result4'];
        var items5 = json['result5'];
        var items6 = json['result6'];
        var items7 = json['result7'];

        $("#table3 tbody tr").remove();
        $("#distable tbody tr").remove();
        $("#table4 tbody tr").remove();

        $("#table3").find("tr:not(:nth-child(1))").remove();
        $.each(detail_fields_res, function() {
          //alert(this);
          //  alert(this)  '<tr> <td>'.$key.'</td></tr>'

          $('#bodydetailFieldsleft').append(this);
        })

        $("#table4").find("tr:not(:nth-child(1))").remove();
        $.each(items2, function() {

          //alert(this)  //'<tr> <td>'.$key.'</td></tr>'

          $('#bodydetailFieldsright').append(this);
        })
        //custom starts
        $("#distable").find("tr:not(:nth-child(1))").remove();
        $.each(items7, function() {

          //alert(this)  //'<tr> <td>'.$key.'</td></tr>'

          $('#bodydetailFieldsdisable').append(this);
        })
        //custom ends
        $("#table5").find("tr:not(:nth-child(1))").remove();
        $.each(items3, function() {
          // alert(this)  '<tr> <td>'.$key.'</td></tr>'

          $('#bodylistFieldsleft').append(this);
        })

        $("#table6").find("tr:not(:nth-child(1))").remove();
        $.each(items4, function() {
          // alert(this)  '<tr> <td>'.$key.'</td></tr>'

          $('#bodylistFieldsright').append(this);
        })

        $("#table7").find("tr:not(:nth-child(1))").remove();
        $.each(items5, function() {
          // alert(this)  '<tr> <td>'.$key.'</td></tr>'

          $('#bodysearchFieldsleft').append(this);
        })

        $("#table8").find("tr:not(:nth-child(1))").remove();
        $.each(items6, function() {
          // alert(this)  '<tr> <td>'.$key.'</td></tr>'

          $('#bodysearchFieldsright').append(this);
        })


      }
    });

  }

  var $tabs1 = $('#table3')
  $("tbody.connectedSortable")
    .sortable({
      connectWith: ".connectedSortable",

      appendTo: $tabs1,
      helper: "clone",
      zIndex: 999990
    })
    .disableSelection();

  var $tab_items1 = $(".nav-tabs > li", $tabs1).droppable({
    accept: ".connectedSortable tr",
    hoverClass: "ui-state-hover",
    drop: function(event, ui) {
      return false;
    }
  });

  var $tabs2 = $('#table4')
  $("tbody.connectedSortable")
    .sortable({
      connectWith: ".connectedSortable",
      appendTo: $tabs2,
      helper: "clone",
      zIndex: 999990
    })
    .disableSelection();

  var $tab_items2 = $(".nav-tabs > li", $tabs2).droppable({
    accept: ".connectedSortable tr",
    hoverClass: "ui-state-hover",
    drop: function(event, ui) {
      return false;
    }
  });

  function save() {
    //alert('salam from button');
    var mod_sel = document.getElementById("select_mod_drop").value;


    var tab3 = document.getElementById('table3');
    var disp_detailview_fields = [];
    for (var r = 0, n = tab3.rows.length; r < n; r++) {

      for (var c = 0, m = tab3.rows[r].cells.length; c < m; c++) {
        // alert(table.rows[r].cells[c].innerHTML);
        // arr = arr + table.rows[r].cells[c].innerHTML;
        disp_detailview_fields[r] = tab3.rows[r].cells[c].innerHTML;
      }


    }
    //alert(disp_detailview_fields);
    // alert(mod_sel);
    // alert('done');




    $.ajax({
      type: 'POST',
      url: 'fyncrmfields.php',
      // dataType:'json',
      data: {
        selModuleDrop: mod_sel,
        disp_mod_fields: disp_detailview_fields,


      },
      success: function(data) {
        // window.location.reload();
        history.go(0);

      }
    });





  }
</script>

</html>