
<!DOCTYPE html>
<html>
<link href="css/bootstrap.css" rel="stylesheet" />

<script src="js/bootstrap.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<?php
require_once('modules/Users/User.php');
global $sugar_config;
global $user;
$mod_disp_res = explode(",",$sugar_config['mobile_users_modules']);

//$disabled_array= array();
//$hidden_array= array();
//$enabled_array= array("id"=>"id","name"=>"name");
/*foreach ($app_list_strings['moduleList'] as $key => $value)
        {
          console.log($key);
            if(in_array($key ,$enabled_array))
             {
                //don't do anything as its enabled.
             }
            else
             {
             	console.log($key);
                $disabled_array[$key]=$value;
             }

        }*/


?>
<head>
</head>
<style type="text/css">
    table thead tr
    {
       display:block;
    }
    table th
    {
        width: 250px;
        border-style: solid;
        border-width: 1px;
        display:block;
        height: 25px;
        font-size: 14px;
    }
   table  tbody
    {
      display:block;
      height:400px;
      border-style: solid;
      overflow:auto;//set tbody to auto
      font-size: 14px;
      border-collapse:separate;
      border-spacing:0.5px;
   }


   .marginRow{
   margin-bottom:0px !important;
   }
    #div_details_fields_list
    {
      overflow-y: scroll;
       clear: both;


    }

    #mod_dropdown
    {

     clear: both;
     padding-top: 0.5cm;
    }
     #div_details_fields_list
    {
      margin-top: 0.3cm;
 clear: both;

    }
    #div_list_fields_list
    {
       clear: both;
      padding-top: 0.3cm;


    }
    #div_search_fields_list
    {
       clear: both;
      padding-top: 0.3cm;


    }






     #divLast
    {
      margin-top: 0.5cm;
      clear: both;
    }
table {display:inline;float:left;}

​
</style>


<body >
<div style="position:relative;">
<div id="divFirst">
  <input type="button" class="button" value="Save" onclick=save();>
  <input type="button" class="button" value="Cancel" onclick="history.go(-1);">
  <input type="button" class="button" value="Admin" onclick="location.href ='index.php?module=Administration&action=index'">  <br/> <br/>

</div>

<div class="container" style="border-right:1px solid #ccc;position:relative;border:1px solid #000; padding: 20px;background-color: #FDFEFE;">
<div>
  <ul class="nav nav-tabs" role="tablist">

     <!--  <li class=""><a  href="index.php?module=Administration&action=fyncrmappusers">Users</a>
      </li> -->
      <li class="">
        <a  href="index.php?module=Administration&action=fyncrmappmodules">Modules</a>
      </li>
      <li><a href="index.php?module=Administration&action=fyncrmappviews">Detail Fields </a>
      </li>
      <li class="active">
        <a  href="index.php?module=Administration&action=fyncrmapplistview" >List Fields</a>
      </li>
      <!--  <li><a href="index.php?module=Administration&action=fyncrmappsearchview">Search Fields</a>
      </li> -->
        <li class="">
        <a  href="index.php?module=Administration&action=fyncrmappcustomportal" >custom portal</a>
      </li>
       <!-- <li><a href="index.php?module=Administration&action=fyncrmapplang">Select Language</a>
      </li> -->
    </ul>
<br>
<div class="alert" style="background-image: linear-gradient( 135deg, #f1746d 90%, #360940 100%); color:beige; width:70%; border-radius:20px;">
            For security reason the default CRM package will restrict certain modules and fields but that is not the show stopper. We can enable even those if you inform.<br><br>
            <strong>Reach them at: sales@fynsis.com.</strong>
          </div>
 <h4><b>Select Your Modules and Fields</b></h4>
<div id="mod_dropdown" style="text-align: center;position: relative;margin-right: 350px;border-right:1px solid #ccc;position:relative;border:1px solid #000;">
  <form>
<p><b>Please Select the Module :</b></p>

<select id="select_mod_drop" onchange="changeField();return false;">
<option selected disabled hidden style='display: none' value=""></option>
<?php

    foreach($mod_disp_res as $category => $value)
    {
       echo '<option value="'.$value.'">'.$value.'</option>';
    }
?>
</select>
<br>
<br>

</form>
</div>


 <div id="div_list_fields_list" >
<p><b>Please Select the ListView Fields :</b></p>
<div class="table-responsive col-md-3">
<table id='table5'>
         <thead>
                 <tr>
                      <th bgcolor="#D3D3D3">Displayed ListView Fields</th>
                 </tr>
         </thead>

      <tbody class="connectedSortable" id="bodylistFieldsleft">


     <?php
     /*foreach ($enabled_array as $key=>$value)
      if(in_array($key, $mod_disp_res))
     {
       # code...
        echo '<tr>
         <td>';
         echo $key;
         echo '</td>
         </tr>';

     }
*/
     ?>


      </tbody>


</table>
</div>
<div class="table-responsive col-md-3">
<table id='table6'>
    <thead>
        <tr>
            <th bgcolor="#D3D3D3">Hidden ListView Fields</th>
        </tr>
    </thead>
    <tbody class="connectedSortable" id="bodylistFieldsright">

     <?php
       /* require_once('service/v4_1/SugarWebServiceImplv4_1.php');
        //foreach ($app_list_strings['moduleList'] as $key => $value)
    foreach ($hidden_array as $key => $value)
        {
            if(in_array($key, $mod_disp_res))
             {

             }

            else
             {
                echo '<tr><td>';
                echo $key;
                echo '</td></tr>';
             }

        }*/
?>
</tbody>


</table>
</div>
<div class="table-responsive col-md-3">
<table id='distable'>
         <thead>
                 <tr>
                      <th bgcolor="#D3D3D3">Disable ListView Fields</th>
                 </tr>
         </thead>

      <tbody class="" id="bodydetailFieldsdisable">

        <?php
        /*require_once('service/v4_1/SugarWebServiceImplv4_1.php');
        //foreach ($app_list_strings['moduleList'] as $key => $value)
         foreach ($hidden_array as $key => $value)
        {
            if(in_array($key, $mod_disp_res))
             {

             }

            else
             {
                echo '<tr><td>';
                echo $key;
                echo '</td></tr>';
             }

        }*/
      ?>

      </tbody>


</table>
</div>
</div>


<div id="divLast">
<input type="button" class="button" value="Save" onclick=save();>
<input type="button" class="button" value="Cancel" onclick="history.go(-1);">
</div>
</div>


</body>

<script type="text/javascript">

function changeField()
{
  var mod_sel = document.getElementById("select_mod_drop").value;


  $.ajax({
        type: 'POST',
        url: 'fyncrmappfields.php',
       // dataType:'json',
        data: { dropmoduleName: mod_sel },
        success: function(data)
        {
     //alert('done');
       //alert(data);
          // window.location.reload();
          //alert(data);

           var json = $.parseJSON(data);
          //alert(json['result1']);
          //alert(json['result2']);
         // $('#b1').empty();
         //$("#table-draggable3").find("tr:not(:nth-child(1))").remove();
         // $("#table-draggable4").find("tr:not(:nth-child(1))").remove();

         //  $('#b1').append(json['result2']);
           //alert('done loading');
          //window.location.reload();

           //var detail_fields_res = json['detailFields'];
          // var items2 = json['result2'];
            var items3 = json['result3'];
           var items4 = json['result4'];
            //var items5 = json['result5'];
           // var items6 = json['result6'];
            var items8 =json['result8'];

            $("#table6 tbody tr").remove();
$("#distable tbody tr").remove();
$("#table5 tbody tr").remove();

//custom starts
$("#distable").find("tr:not(:nth-child(1))").remove();
   $.each(items8, function()
   {

       //alert(this)  //'<tr> <td>'.$key.'</td></tr>'

         $('#bodydetailFieldsdisable').append(this);
    })
//custom ends
  $("#table6").find("tr:not(:nth-child(1))").remove();
  $.each(items4, function()    {
       // alert(this)  '<tr> <td>'.$key.'</td></tr>'

         $('#bodylistFieldsright').append(this);
    })


$("#table5").find("tr:not(:nth-child(1))").remove();
  $.each(items3, function()    {
       // alert(this)  '<tr> <td>'.$key.'</td></tr>'

         $('#bodylistFieldsleft').append(this);
    })



        }
    });

}

    var $tabs1 = $('#table5')
$("tbody.connectedSortable")
    .sortable({
        connectWith: ".connectedSortable",

        appendTo: $tabs1,
        helper: "clone",
        zIndex: 999990
    })
    .disableSelection();

var $tab_items1 = $(".nav-tabs > li", $tabs1).droppable({
    accept: ".connectedSortable tr",
    hoverClass: "ui-state-hover",
    drop: function (event, ui) {
        return false;
    }
});

var $tabs2 = $('#table6')
$("tbody.connectedSortable")
    .sortable({
        connectWith: ".connectedSortable",
        appendTo: $tabs2,
        helper: "clone",
        zIndex: 999990
    })
    .disableSelection();

var $tab_items2 = $(".nav-tabs > li", $tabs2).droppable({
    accept: ".connectedSortable tr",
    hoverClass: "ui-state-hover",
    drop: function (event, ui) {
        return false;
    }
});
function save()
{
  //alert('salam from button');
 var mod_sel = document.getElementById("select_mod_drop").value;




        var tab5 = document.getElementById('table5');
  var disp_listview_fields = [];
        for (var r = 0, n = tab5.rows.length; r < n; r++)
        {
            for (var c = 0, m = tab5.rows[r].cells.length; c < m; c++)
            {
               // alert(table.rows[r].cells[c].innerHTML);


              // arr = arr + table.rows[r].cells[c].innerHTML;
              disp_listview_fields[r]=tab5.rows[r].cells[c].innerHTML;


            }
        }
       /* console.log(disp_listview_fields);

       alert(disp_listview_fields); */

     $.ajax({
        type: 'POST',
        url: 'fyncrmlistfields.php',
       // dataType:'json',
        data: {
              selModuleDrop:mod_sel,
               disp_list_fields:disp_listview_fields,

             },
        success: function(data)
        {
          // window.location.reload();
          history.go(0);

        }
    });


}

</script>
</html>
