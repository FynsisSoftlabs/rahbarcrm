
<!DOCTYPE html>
<html>
<link href="css/bootstrap.css" rel="stylesheet" />
<script src="js/bootstrap.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript">
//var once = $("hiddenElement").val();

//alert(once); <div id="hiddenElement" value="true" style="display:none; visibility:hidden;"></div>


//if (once="true") var once = document.getElementById('hiddenElement').getAttribute('value');

  // var cookieValue = document.getElementById('hiddenElement').getAttribute('value');
  $(document).ready(function() 
  {  
   $.ajax({

        type: 'POST',
        url: 'fyncrmappautoconfig.php',
       // dataType:'json',
        
        success: function(data)
        {      
           //window.location.reload();  
            // alert('done'); 
            // alert(data); 
             //$("#hiddenElement").val("false"); 
           //  document.getElementById('hiddenElement').getAttribute('value')="false";

        }
    });  
 });
 // alert(once); 
 
</script>
<?php
require_once('modules/Users/User.php');
global $sugar_config;
global $user;
$mod_disp_res = explode(",",$sugar_config['mobile_users_modules']);
$disabled_array= array();
//$hidden_array=array("Home"=>"Home","AOS_Quotes"=>"Quotes","AOS_Invoices"=>"Invoices","AOS_Products"=>"Products","Documents"=>"Documents","AOW_WorkFlow"=>"WorkFlow","AOR_Reports"=>"Reports");
// $enabled_array= array("Accounts"=>"Accounts","Contacts"=>"Contacts","Cases"=>"Cases","Leads"=>"Leads","Opportunities"=>"Opportunities","Meetings"=>"Meetings","Calls"=>"Calls","AOS_Contracts"=>"Contracts","AOS_Quotes"=>"Quotes","AOS_Products"=>"Products","Documents"=>"Documents","AOR_Reports"=>"AOR_Reports","Targets"=>"Targets","AOS_Invoices"=>"AOS_Invoices","Project"=>"Project","FP_events"=>"FP_events","AOK_Knowledge_Base_Categories"=>"AOK_Knowledge_Base_Categories","Home"=>"Home","Bugs"=>"Bugs","Currencies"=>"Currencies","Activities"=>"Activities","Campaigns"=>"Campaigns","Users"=>"Users","AOK_KnowledgeBase"=>"AOK_KnowledgeBase","AOS_Contracts"=>"AOS_Contracts","Spots"=>"Spots","Leads"=>"Leads","Tasks"=>"Tasks");


$enabled_array= array("Cases"=>"Cases","Leads"=>"Leads","Opportunities"=>"Opportunities","Calls"=>"Calls","AOS_Contracts"=>"Contracts","AOS_Quotes"=>"Quotes","AOS_Products"=>"Products" ,"AOS_Invoices"=>"AOS_Invoices","Users"=>"Users","AOS_Contracts"=>"AOS_Contracts","Leads"=>"Leads");


foreach ($app_list_strings['moduleList'] as $key => $value) 
        {
            if(in_array($key, $enabled_array))
             {
                //don't do anything as its enabled.
             }
            else
             { 
                $disabled_array[$key]=$value;
             }
        }
?>
<head> 
</head>
<style type="text/css">
    table thead tr
    {
       display:block; 

    }
    table th
    {
        width: 250px;
        border-style: solid;
        border-width: 1px;
        display:block;
        height: 25px;
        font-size: 14px;
    }
   table  tbody
    {
      display:block;
      height:400px;
      border-style: solid;
      overflow:auto;//set tbody to auto
      font-size: 14px;
      border-collapse:separate;
      border-spacing:0.5px;
   }

    #table1 
    {
       
    }
 
    #table2 
    {
      
    }
    
    #div_Modules
    {
      overflow-y: scroll; 
       clear: both;


    }
    #divLast
    {
      margin-top: 0.5cm;
      clear: both;
    }
table {display:inline;float:left;}

​
</style>


<body >
<div style="position:relative;">
<div id="divFirst">
  <input type="button" class="button" value="Save" onclick=save();>
  <input type="button" class="button" value="Cancel" onclick="history.go(-1);"> 
  <input type="button" class="button" value="Admin" onclick="location.href ='index.php?module=Administration&action=index'">  <br/>
 
</div>
<div class="container" style="border-right:1px solid #ccc;position:relative;border:1px solid #000; padding: 20px;background-color: #FDFEFE;">
<div>
  <ul class="nav nav-tabs" role="tablist">
     
     <!--  <li class=""><a  href="index.php?module=Administration&action=fyncrmappusers">Users</a>
      </li> -->
      <li class="active">
        <a  href="index.php?module=Administration&action=fyncrmappmodules">Modules</a>
      </li>
      <li class=""><a href="index.php?module=Administration&action=fyncrmappviews">Detail Fields </a>
      </li>
      <li class="">
        <a  href="index.php?module=Administration&action=fyncrmapplistview" >List Fields</a>
      </li>
       <li class="">
        <a  href="index.php?module=Administration&action=fyncrmappcustomportal" >custom portal</a>
      </li>
     <!--   <li><a href="index.php?module=Administration&action=fyncrmappsearchview">Search Fields</a>
      </li> -->
       </li>
       <!--  <li><a href="index.php?module=Administration&action=fyncrmapplang">Select Language</a>
      </li> -->
    </ul>
    <br>
    <div class="alert" style="background-image: linear-gradient( 135deg, #f1746d 90%, #360940 100%); color:beige; width:70%; border-radius:20px;">
            For security reason the default CRM package will restrict certain modules and fields but that is not the show stopper. We can enable even those if you inform.<br><br>
            <strong>Reach them at: sales@fynsis.com.</strong>
          </div>
     <h4><b>Select Your Modules</b></h4>
<div id="div_Modules">
<div class="table-responsive col-md-3">
<table id='table1'>
         <thead>
                 <tr>
                      <th bgcolor="#D3D3D3">Displayed Modules</th>            
                 </tr>
         </thead>

      <tbody class="connectedSortable">
        <?php
     foreach ($enabled_array as $key=>$value) 
      if(in_array($key, $mod_disp_res))
     {
       # code...
        echo '<tr>
         <td style="border:1px solid #000;width: 242px;cursor:pointer">';
         echo $key;
         echo '</td>
         </tr>';

     }

     ?>
            

      </tbody>
 
   
</table>
</div>
<div class="table-responsive col-md-3">
<table id='table2'>
    <thead>
        <tr>
            <th bgcolor="#D3D3D3">Hidden Modules</th>            
        </tr>
    </thead>
    <tbody class="connectedSortable">
    
     <?php
        require_once('service/v4_1/SugarWebServiceImplv4_1.php');
        //foreach ($app_list_strings['moduleList'] as $key => $value) 
		foreach ($enabled_array as $key => $value)
        {
            if(in_array($key, $mod_disp_res))
             {

             }
            else
             { 
                echo '<tr><td style="border:1px solid #000;width: 242px;cursor:pointer">';
                echo $key;
                echo '</td></tr>';
             }
        
        }
?>
</tbody>
 
   
</table>
</div>

<div class="table-responsive col-md-3">
<table id='table3'>
         <thead>
                 <tr>
                      <th bgcolor="#D3D3D3">Disabled Modules</th>            
                 </tr>
         </thead>

      <tbody >
             <?php
     foreach ($disabled_array as $key=>$value) 
     {
      if(in_array($key, $mod_disp_res))
             {

             }
             else
             {
       # code...
          echo '<tr>
           <td style="border:1px solid #000;width: 242px;cursor:pointer">';
           echo $key;
           echo '</td>
           </tr>';
       }

     }

     ?>

      </tbody>
 
   
</table>
</div>
</div>







<div id="divLast">
<input type="button" class="button" value="Save" onclick=save();>
<input type="button" class="button" value="Cancel" onclick="history.go(-1);">
</div>
</div>


</body>

<script type="text/javascript">



    var $tabs1 = $('#table1')
$("tbody.connectedSortable")
    .sortable({
        connectWith: ".connectedSortable",
        
        appendTo: $tabs1,
        helper: "clone",
        zIndex: 999990
    })
    .disableSelection();

var $tab_items1 = $(".nav-tabs > li", $tabs1).droppable({
    accept: ".connectedSortable tr",
    hoverClass: "ui-state-hover",
    drop: function (event, ui) {
        return false;
    }
});

var $tabs2 = $('#table2')
$("tbody.connectedSortable")
    .sortable({
        connectWith: ".connectedSortable",        
        appendTo: $tabs2,
        helper: "clone",
        zIndex: 999990
    })
    .disableSelection();

var $tab_items2 = $(".nav-tabs > li", $tabs2).droppable({
    accept: ".connectedSortable tr",
    hoverClass: "ui-state-hover",
    drop: function (event, ui) {
        return false;
    }
});
function save() 
{
 // alert('salam from button');
 
  var tab1 = document.getElementById('table1');
  var disp_mod = [];
        for (var r = 0, n = tab1.rows.length; r < n; r++) 
        {
            for (var c = 0, m = tab1.rows[r].cells.length; c < m; c++) 
            {               
              disp_mod[r]=tab1.rows[r].cells[c].innerHTML;             
            }
        }
    
    
     $.ajax({
        type: 'POST',
        url: 'fyncrmmodules.php',
       // dataType:'json',
        data: {displayModules:disp_mod,
               
             },
        success: function(data)
        {      
           //window.location.reload();  
           history.go(0);
                              
        }
    });






}

</script>
</html>
