<?php

 echo "Thank You! Please Check Your Email.";
      $a = $_POST['a']; 
       $emailaddress = $_POST['b'];  

  define('sugarEntry', TRUE); 
ini_set('max_execution_time', 0);
error_reporting(E_ERROR);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);
include_once('include/entryPoint.php');
require_once('data/BeanFactory.php'); 
require_once('include/entryPoint.php');
if (!defined('sugarEntry') || !sugarEntry)die('Not A Valid Entry Point');

   require_once 'modules/Emails/Email.php';
          require_once 'include/SugarPHPMailer.php';

  global $db;  

// echo  $item_ab; 

// $servername = "localhost";
// $username = "crm";
// $password = "M4myY6Bs2rNUxmGG";
// $dbname = "crm_dev";


 // $db = mysqli_connect($servername, $username, $password ,$dbname);


   $sq1w = "select *  from contacts,contacts_cstm where id=id_c and id='".$a."'";
    $resw = $db->query($sq1w);
      $roww = $resw->fetch_assoc(); 
          $conid = $roww['fyn_password_c'];
           $fname1 = $roww['first_name'];
            $na = $roww['last_name'];

 
  $bd = 'Hello '.$fname1 ." ".$na.'<br><br>Your account Password  for portal is '.$conid.'<br><br>Note : You can change your system generated password from portal.<br><br>Regards,<br>Fynsis Support Team.<br>';


                                $emailObj = new Email();  
                                $body .= $bd;
                                $defaults = $emailObj->getSystemDefaultEmail();  
                                $mail = new SugarPHPMailer();  
                                $mail->setMailerForSystem();  
                                $mail->From = $defaults['email'];  
                                $mail->FromName = $defaults['name'];  
                                $mail->Subject = 'Your Password For portal';
                                $mail->Body = wordwrap($body,900);
                                $mail->isHTML(true);    
                                $mail->prepForOutbound();
                                // $mail->AddAddress('devsupport@paradisosolutions.com'); 
                                 $mail->AddAddress($emailaddress);  
                                 @$mail->Send();  

?>